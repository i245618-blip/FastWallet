#!/usr/bin/env bash
# Final demonstration (Week 14 rehearsal, Week 15 defence). Loads a fresh database, starts the mock rail and
# the API locally, runs infra/week14_demo.py (seven segments, see docs/demo/demo_script.md), stops both.
#   DATABASE_URL=postgresql://fw:fw@localhost:5432/fw FW_JWT_SECRET=... FW_RAIL_ACK_SECRET=... ./infra/run_demo.sh
# Fault injection is switched on for this run only (segment 3 needs it). The enquiry backoff is compressed
# so the recovery shows immediately instead of after 5 seconds.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?set DATABASE_URL}"
: "${FW_JWT_SECRET:?set FW_JWT_SECRET (32+ characters)}"
: "${FW_RAIL_ACK_SECRET:?set FW_RAIL_ACK_SECRET}"
export PGOPTIONS='-c client_min_messages=warning'
for f in src/db/01_tables.sql src/db/02_integrity.sql src/db/03_reconciliation.sql src/db/04_reference_data.sql \
         src/db/05_roles.sql src/db/06_week13.sql src/db/07_week14.sql data/seed_demo.sql data/demo_helpers.sql; do
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null
done
RUN_DIR="${FW_DEMO_RUN_DIR:-$(mktemp -d)}"
API_PORT="${FW_API_PORT:-8000}"; RAIL_PORT="${FW_RAIL_PORT:-8100}"
export PYTHONPATH=src FW_RAIL_URL=http://127.0.0.1:$RAIL_PORT FW_API_URL=http://127.0.0.1:$API_PORT \
       FW_ACK_URL=http://127.0.0.1:$API_PORT/internal/rail/acks RAIL_STATE_FILE="$RUN_DIR/rail.json" \
       RAIL_SLOW_SECONDS=7 FW_BACKOFF_SCALE=0 FW_LOG_FILE="$RUN_DIR/worker.log" FW_SERVICE_NAME=fw-worker
rm -f "$RAIL_STATE_FILE"
python -m uvicorn fastwallet.rail_mock:app --port "$RAIL_PORT" --log-level warning > "$RUN_DIR/rail.out" 2>&1 &
RAIL_PID=$!
FW_ENABLE_FAULT_INJECTION=1 FW_LOG_FILE="$RUN_DIR/api.log" FW_SERVICE_NAME=fw-api \
  python -m uvicorn fastwallet.api:app --port "$API_PORT" --log-level warning > "$RUN_DIR/api.out" 2>&1 &
API_PID=$!
trap 'kill $API_PID $RAIL_PID 2>/dev/null || true' EXIT
for i in $(seq 1 100); do curl -sf "http://127.0.0.1:$API_PORT/health/ready" >/dev/null && break; sleep 0.1; done
python infra/week14_demo.py
echo "Service logs (JSON): $RUN_DIR/api.log"
