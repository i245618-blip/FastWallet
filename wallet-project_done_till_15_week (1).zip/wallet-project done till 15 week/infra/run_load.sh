#!/usr/bin/env bash
# Load runs for the accept-latency SLI: 1, 5 and 20 concurrent requests from one wallet (worst case) and
# 20 and 50 spread over five customers. Fresh database, local mock rail. Output: <dir>/load_*.json
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-evidence/week14}"
export PGOPTIONS='-c client_min_messages=warning' PYTHONPATH=src FW_RAIL_URL=http://127.0.0.1:8100 \
       FW_ACK_URL=http://127.0.0.1:8000/internal/rail/acks RAIL_STATE_FILE=/tmp/fw_load_rail.json FW_LOG_FILE=/tmp/fw_load_api.log
for f in src/db/01_tables.sql src/db/02_integrity.sql src/db/03_reconciliation.sql src/db/04_reference_data.sql \
         src/db/05_roles.sql src/db/06_week13.sql src/db/07_week14.sql data/seed_demo.sql data/demo_helpers.sql; do
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null
done
rm -f "$RAIL_STATE_FILE"
python3 -m uvicorn fastwallet.rail_mock:app --port 8100 --log-level warning >/dev/null 2>&1 & R=$!
A=""
trap 'kill $A $R 2>/dev/null || true' EXIT
for spec in "1 150 one" "5 150 one" "20 300 one" "20 300 spread" "50 500 spread"; do
  set -- $spec
  # a fresh API process per run, so the server-side latency histogram covers this run only
  python3 -m uvicorn fastwallet.api:app --port 8000 --log-level warning >/dev/null 2>&1 & A=$!
  for i in $(seq 1 100); do curl -sf http://127.0.0.1:8000/health/ready >/dev/null && break; sleep 0.1; done
  python3 infra/load_test.py --concurrency $1 --requests $2 --wallets $3 --out "$OUT/load_c$1_$3.json" >/dev/null
  kill $A; wait $A 2>/dev/null || true
  echo "   c=$1 wallets=$3 done"
done
