#!/usr/bin/env bash
# Week 13 demonstration. Loads a fresh database, starts the mock rail and the API locally (fault injection
# on, for the partial-failure scenario only), runs infra/week13_demo.py, then stops both services.
# Example:
#   DATABASE_URL=postgresql://fw:fw@localhost:5432/fw FW_JWT_SECRET=$(python -c "import secrets;print(secrets.token_urlsafe(32))") \
#   FW_RAIL_ACK_SECRET=$(python -c "import secrets;print(secrets.token_urlsafe(32))") ./infra/run_week13_demo.sh
set -euo pipefail
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?set DATABASE_URL}"
: "${FW_JWT_SECRET:?set FW_JWT_SECRET (32+ characters)}"
: "${FW_RAIL_ACK_SECRET:?set FW_RAIL_ACK_SECRET}"
export PGOPTIONS='-c client_min_messages=warning'
for f in src/db/01_tables.sql src/db/02_integrity.sql src/db/03_reconciliation.sql src/db/04_reference_data.sql \
         src/db/05_roles.sql src/db/06_week13.sql src/db/07_week14.sql data/seed_demo.sql data/demo_helpers.sql; do
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null
done
RUN_DIR="${FW_DEMO_RUN_DIR:-$(mktemp -d)}"
export PYTHONPATH=src FW_RAIL_URL=http://127.0.0.1:8100 FW_API_URL=http://127.0.0.1:8000 \
       FW_ACK_URL=http://127.0.0.1:8000/internal/rail/acks RAIL_STATE_FILE="$RUN_DIR/rail.json" \
       RAIL_SLOW_SECONDS=7 FW_LOG_FILE="$RUN_DIR/worker.log" FW_SERVICE_NAME=fw-worker
rm -f "$RAIL_STATE_FILE"
python -m uvicorn fastwallet.rail_mock:app --port 8100 --log-level warning > "$RUN_DIR/rail.out" 2>&1 &
RAIL_PID=$!
FW_ENABLE_FAULT_INJECTION=1 FW_LOG_FILE="$RUN_DIR/api.log" FW_SERVICE_NAME=fw-api \
  python -m uvicorn fastwallet.api:app --port 8000 --log-level warning > "$RUN_DIR/api.out" 2>&1 &
API_PID=$!
trap 'kill $API_PID $RAIL_PID 2>/dev/null || true' EXIT
for i in $(seq 1 50); do curl -sf http://127.0.0.1:8000/health/ready >/dev/null && break; sleep 0.2; done
python infra/week13_demo.py
echo "Service logs (JSON): $RUN_DIR/api.log"
