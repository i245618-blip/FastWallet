"""Week 13 demonstration: normal path plus the failure and recovery scenarios, against the running services.

Started by infra/run_week13_demo.sh, which loads a fresh database and launches the mock rail and the API
(with fault injection enabled for the demo only). Prints one section per scenario.
"""
import datetime as dt
import json
import os
import subprocess
import sys
import time
import uuid

import httpx
import psycopg2
import psycopg2.extras

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from fastwallet import events, transfers  # noqa: E402
from fastwallet.security import issue_token  # noqa: E402

API = httpx.Client(base_url=os.environ.get("FW_API_URL", "http://127.0.0.1:8000"), timeout=20)
RAIL = httpx.Client(base_url=os.environ["FW_RAIL_URL"], timeout=20)
DSN = os.environ["DATABASE_URL"]
TODAY = dt.date.today().isoformat()


def q(sql, params=None):
    conn = psycopg2.connect(DSN)
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute("SET search_path = fw, public")
        cur.execute(sql, params)
        return cur.fetchall() if cur.description else []
    finally:
        conn.close()


def bal(code):
    r = q("SELECT balance_minor FROM account_balance JOIN ledger_account USING (account_id) WHERE code = %s", (code,))
    return r[0]["balance_minor"] if r else 0


def rs(minor):
    return f"Rs {minor / 100:,.2f}"


def tok_c(n, mfa=True):
    return issue_token(f"CUST-{n:04d}", ["customer"], "fw-app", mfa=mfa)


def tok_s(user, role):
    return issue_token(user, [role], "fw-backoffice", mfa=True)


OPS, FIN, CO = tok_s("ops.demo1", "ops_analyst"), tok_s("fin.demo1", "finance_controller"), tok_s("co.demo1", "compliance_officer")


def body(w, amount, ident="PK00FAKE0000000000000001", name="Synthetic Beneficiary"):
    return {"source_wallet_id": f"b0000000-0000-0000-0000-{w:012d}", "purpose": "FAMILY_SUPPORT",
            "amount": {"currency": "PKR", "minor_units": amount},
            "beneficiary": {"scheme": "IBAN", "identifier": ident, "name": name}}


def post(tok, b, key=None):
    return API.post("/v1/transfers", json=b, headers={"Authorization": f"Bearer {tok}",
                                                      "Idempotency-Key": key or "demo-" + uuid.uuid4().hex})


def h(title):
    print(f"\n=== {title}")


def show(r):
    j = r.json()
    extra = f" reason={j.get('status_reason') or j.get('code')}" if (j.get("status_reason") or j.get("code")) else ""
    print(f"    HTTP {r.status_code}  {j.get('transaction_reference', '')}  status={j.get('status', '-')}{extra}"
          f"{'  [Idempotent-Replayed]' if r.headers.get('Idempotent-Replayed') else ''}")
    return j


def lineage(ref):
    r = q("SELECT status, journals, state_changes, events FROM v_transfer_lineage WHERE transaction_reference = %s", (ref,))[0]
    print(f"    lineage: status={r['status']} journals=[{r['journals']}] state_changes={r['state_changes']} events={r['events']}")


def rail_log(tid):
    rows = q("SELECT operation, outcome FROM rail_message_log WHERE transfer_id = %s ORDER BY msg_id", (tid,))
    print("    rail log: " + " -> ".join(f"{r['operation']}:{r['outcome']}" for r in rows))


h("0. Starting position")
print(f"    float 1100 = {rs(bal('1100'))}, wallet CUST-0004 = {rs(bal('W-CUST-0004'))}, in transit 2200 = {rs(bal('2200'))}")

h("1. Normal success: initiate -> screen -> post -> rail -> settle")
t1 = show(post(tok_c(4), body(4, 150_000)))
lineage(t1["transaction_reference"])
print(f"    wallet CUST-0004 = {rs(bal('W-CUST-0004'))}, in transit = {rs(bal('2200'))}")

h("2. Client retry after timeout (rail pays but answers too late)")
RAIL.post("/_control/script", json={"modes": ["TIMEOUT_EXECUTED"]})
key = "demo-retry-" + uuid.uuid4().hex[:12]
w0 = bal("W-CUST-0004")
t2 = show(post(tok_c(4), body(4, 110_000, "PK00FAKE0000000000000002"), key))
show(post(tok_c(4), body(4, 110_000, "PK00FAKE0000000000000002"), key))
print(f"    wallet debited once: {rs(w0 - bal('W-CUST-0004'))}; rail submissions for this reference: "
      f"{RAIL.get('/_control/stats').json()['submit_counts'][t2['transaction_reference']]}")
r = post(tok_c(4), body(4, 999_00, "PK00FAKE0000000000000002"), key)
print(f"    same key, different amount -> HTTP {r.status_code} {r.json()['code']}")

h("3. Downstream timeout -> PENDING -> status enquiry (no blind replay)")
print(f"    before recovery: {q('SELECT status FROM transfer WHERE transfer_id = %s', (t2['transfer_id'],))[0]['status']}")
print(f"    recovery worker result: {transfers.recover_transfer(t2['transfer_id'], force=True)}")
rail_log(t2["transfer_id"])

h("4. Lost request -> enquiry says NOT_FOUND -> one safe resubmission")
RAIL.post("/_control/script", json={"modes": ["TIMEOUT_NOT_EXECUTED"]})
t4 = show(post(tok_c(1), body(1, 50_000)))
print(f"    recovery worker result: {transfers.recover_transfer(t4['transfer_id'], force=True)}")
rail_log(t4["transfer_id"])

h("5. Rail rejection -> compensating journal")
RAIL.post("/_control/script", json={"modes": ["REJECT"]})
t5 = show(post(tok_c(4), body(4, 160_000, "PK00FAKE0000000000000003")))
lineage(t5["transaction_reference"])

h("6. Duplicate rail acknowledgement")
RAIL.post("/_control/script", json={"modes": ["DUPLICATE_ACK"]})
t6 = show(post(tok_c(3), body(3, 120_000)))
time.sleep(1.5)
rail_log(t6["transfer_id"])
print(f"    settlement journals: {q('SELECT count(*) AS n FROM journal_entry WHERE transfer_id = %s AND journal_type = %s', (t6['transfer_id'], 'TRANSFER_SETTLE'))[0]['n']}")

h("7. Duplicate event at the notification consumer")
events.relay_once()
ev = q("SELECT payload FROM outbox_event WHERE aggregate_id = %s ORDER BY sequence DESC LIMIT 1", (t1["transfer_id"],))[0]["payload"]
print(f"    redelivered SETTLED event -> {events.notify(ev)}")
print(f"    notifications for {t1['transaction_reference']}: " +
      ", ".join(f"{r['status']}:{r['outcome']}" for r in q("SELECT status, outcome FROM notification_log WHERE transfer_id = %s ORDER BY sequence", (t1['transfer_id'],))))

h("8. Partial failure: rail executes, our settlement posting fails")
API.post("/internal/faults", json={"enable": ["fail_settle"]})
t8 = show(post(tok_c(6), body(6, 180_000, "PK00FAKE0000000000000008")))
rail_log(t8["transfer_id"])
API.post("/internal/faults", json={"clear": True})
print("    exception queue: " + ", ".join(f"{r['kind']} ({r['owner_role']})" for r in q("SELECT kind, owner_role FROM ops_exception WHERE state = 'OPEN'")))

h("9. Reconciliation run 1 (end of day)")
run1 = API.post("/v1/reconciliation/runs", json={"statement_date": TODAY, "stuck_after_seconds": 1800},
                headers={"Authorization": f"Bearer {OPS}"}).json()
print(f"    statement lines imported={run1['lines_imported']} matched={run1['matched']} new breaks={run1['new_breaks']}")
for b in q("SELECT break_id, break_type, owner_role, detail, t.transaction_reference FROM recon_break JOIN transfer t USING (transfer_id) WHERE state <> 'RESOLVED'"):
    print(f"    break {b['break_type']} owner={b['owner_role']} {b['transaction_reference']} ({b['detail']})")
brk = q("SELECT break_id FROM recon_break WHERE transfer_id = %s", (t8["transfer_id"],))

h("10. Recovery of the partial failure, break resolved, reconciliation run 2")
print(f"    recovery worker result: {transfers.recover_transfer(t8['transfer_id'], force=True)}")
if brk:
    r = API.post(f"/v1/reconciliation/breaks/{brk[0]['break_id']}/resolution",
                 headers={"Authorization": f"Bearer {OPS}", "Idempotency-Key": "demo-" + uuid.uuid4().hex},
                 json={"resolution_code": "MATCHED_LATE", "comment": "settlement posted after status enquiry"})
    print(f"    break resolution -> HTTP {r.status_code} {r.json().get('state')}")
run2 = API.post("/v1/reconciliation/runs", json={"statement_date": TODAY},
                headers={"Authorization": f"Bearer {OPS}"}).json()
print(f"    run 2: matched={run2['matched']} new breaks={run2['new_breaks']}")
lineage(t8["transaction_reference"])

h("11. KYC/AML hold and officer release")
t11 = show(post(tok_c(4), body(4, 15_000_000, "PK00FAKE0000000000000011")))
case = API.get("/v1/compliance/cases", headers={"Authorization": f"Bearer {CO}"}).json()["items"][0]
print(f"    case reasons={case['reason_codes']} risk_score={case['risk_score']}")
r = API.post(f"/v1/compliance/cases/{case['case_id']}/decision",
             headers={"Authorization": f"Bearer {OPS}", "Idempotency-Key": "demo-" + uuid.uuid4().hex},
             json={"decision": "RELEASE", "rationale": "analyst trying to release"})
print(f"    analyst tries to release -> HTTP {r.status_code} {r.json()['code']}")
r = API.post(f"/v1/compliance/cases/{case['case_id']}/decision",
             headers={"Authorization": f"Bearer {CO}", "Idempotency-Key": "demo-" + uuid.uuid4().hex},
             json={"decision": "RELEASE", "rationale": "documented family support, source of funds verified"})
print(f"    officer releases -> HTTP {r.status_code} transfer status={r.json()['transfer']['status']}")

h("12. Unauthorised attempts are denied and logged")
for label, method, path, tok in [("customer reads breaks", "GET", "/v1/reconciliation/breaks", tok_c(4)),
                                 ("analyst reads finance report", "GET", "/v1/reports/settlement", OPS)]:
    r = API.request(method, path, headers={"Authorization": f"Bearer {tok}"})
    print(f"    {label} -> HTTP {r.status_code} {r.json()['code']}")
r = post(tok_c(4, mfa=False), body(4, 10_000))
print(f"    transfer without second factor -> HTTP {r.status_code} {r.json()['code']}")
for d in q("SELECT actor, action, outcome FROM audit_log WHERE outcome = 'DENIED' ORDER BY audit_id"):
    print(f"    audit: {d['actor']:<10} {d['action']:<34} {d['outcome']}")
print(f"    audit chain: {API.get('/v1/audit/verify', headers={'Authorization': f'Bearer {FIN}'}).json()}")

h("13. Ledger controls and finance report")
h_row = q("SELECT trial_balance_ok, projection_ok, float_invariant_ok, open_breaks, open_exceptions FROM v_ops_health")[0]
print(f"    {json.dumps(h_row)}")
print(f"    float 1100 = {rs(bal('1100'))}; wallets + in transit = "
      f"{rs(sum(r['balance_minor'] for r in q('SELECT balance_minor FROM account_balance JOIN ledger_account USING (account_id) WHERE code LIKE %s', ('W-CUST-%',))) + bal('2200'))}")
for r in API.get("/v1/reports/settlement", headers={"Authorization": f"Bearer {FIN}"}).json()["items"]:
    print("    report: " + ", ".join(f"{k}={v}" for k, v in r.items()))
events.relay_once()
print("\nDemo finished.")
