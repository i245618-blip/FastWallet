#!/usr/bin/env bash
# One command from a clean checkout to every piece of evidence (Week 14 reproducibility gate).
#   DATABASE_URL=postgresql://fw:fw@localhost:5432/fw ./infra/reproduce.sh            # writes evidence/week14
# Needs Python 3.10+, PostgreSQL 16 reachable at DATABASE_URL (a disposable database: it is reloaded),
# and the psql / pg_dump / pg_restore clients. Secrets are generated for the run and never written to disk.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?set DATABASE_URL to a disposable PostgreSQL 16 database}"
OUT="${FW_EVIDENCE_DIR:-evidence/week14}"; mkdir -p "$OUT"
export TEST_DATABASE_URL="$DATABASE_URL"
export FW_JWT_SECRET="${FW_JWT_SECRET:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(32))')}"
export FW_RAIL_ACK_SECRET="${FW_RAIL_ACK_SECRET:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(32))')}"
echo "== 1/6 dependencies";     python3 -m pip install -q -r requirements.txt
echo "== 2/6 automated tests";  python3 -m pytest -q | tee "$OUT/pytest_output.txt" | tail -3
echo "== 3/6 demo x3 (rehearsal)"
for i in 1 2 3; do FW_DEMO_SUMMARY="$OUT/rehearsal_run_$i.json" ./infra/run_demo.sh > "$OUT/demo_run_$i.txt" 2>&1; done
cp "$OUT/demo_run_1.txt" "$OUT/demo_run_output.txt"
echo "== 4/6 AI triage evaluation"; python3 infra/ai_triage_eval.py --sweep --out "$OUT/ai_triage_eval.json" >/dev/null
echo "== 5/6 load tests";        ./infra/run_load.sh "$OUT"
echo "== 6/6 backup and restore drill"; python3 infra/backup_restore_drill.py --out "$OUT/restore_drill.json" >/dev/null
python3 - "$OUT" <<'PY'
import json, pathlib, sys
o = pathlib.Path(sys.argv[1])
runs = [json.loads((o / f"rehearsal_run_{i}.json").read_text()) for i in (1, 2, 3)]
print("demo runs all checks OK:", [r["all_checks_ok"] for r in runs], "seconds:", [r["total_seconds"] for r in runs])
print("AI eval targets met:", json.loads((o / "ai_triage_eval.json").read_text())["targets_met"])
print("restore drill passed:", json.loads((o / "restore_drill.json").read_text())["passed"])
PY
echo "Evidence written to $OUT"
