"""Final technical demonstration (rehearsed in Week 14, used at the Week 15 defence).

Started by infra/run_demo.sh, which loads a fresh database and launches the mock rail and the API. Seven
segments that follow the talk track in docs/demo/demo_script.md (8-10 minutes when presented):

  1  Normal flow: initiate, screen, post, rail, settle, notify, reconcile
  2  Failure 1: rail timeout -> PENDING -> client retry (same key) -> recovery by status enquiry
  3  Failure 2: partial failure -> reconciliation break -> triage assistant -> person decides -> recovered
  4  Reconciliation outcome: duplicate payment on the rail -> break -> four-eyes write-off -> controls hold
  5  Late return after reconciliation -> customer credited, finance told
  6  Controls: compliance hold and release, denied role, rate limit, AI kill switch, audit chain
  7  Ledger controls and the finance report

Each segment prints its own elapsed time; a JSON summary is written to $FW_DEMO_SUMMARY if set.
"""
import datetime as dt
import json
import os
import sys
import time
import uuid

import httpx
import psycopg2
import psycopg2.extras

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from fastwallet import events, transfers  # noqa: E402
from fastwallet.security import issue_token  # noqa: E402

API = httpx.Client(base_url=os.environ.get("FW_API_URL", "http://127.0.0.1:8000"), timeout=20)
RAIL = httpx.Client(base_url=os.environ["FW_RAIL_URL"], timeout=20)
DSN = os.environ["DATABASE_URL"]
TODAY = dt.date.today().isoformat()
TOMORROW = (dt.date.today() + dt.timedelta(days=1)).isoformat()
SUMMARY = {"segments": [], "checks": {}}


def q(sql, params=None):
    conn = psycopg2.connect(DSN)
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute("SET search_path = fw, public")
        cur.execute(sql, params)
        rows = cur.fetchall() if cur.description else []
        conn.commit()
        return rows
    finally:
        conn.close()


def bal(code):
    r = q("SELECT balance_minor FROM account_balance JOIN ledger_account USING (account_id) WHERE code = %s", (code,))
    return r[0]["balance_minor"] if r else 0


def rs(minor):
    return f"Rs {minor / 100:,.2f}"


def tok_c(n, mfa=True):
    return issue_token(f"CUST-{n:04d}", ["customer"], "fw-app", mfa=mfa)


def tok_s(user, role):
    return issue_token(user, [role], "fw-backoffice", mfa=True)


OPS, FIN, FIN2, CO = (tok_s("ops.demo1", "ops_analyst"), tok_s("fin.demo1", "finance_controller"),
                      tok_s("fin.demo2", "finance_controller"), tok_s("co.demo1", "compliance_officer"))


def A(tok, key=False):
    h = {"Authorization": f"Bearer {tok}"}
    if key:
        h["Idempotency-Key"] = "demo-" + uuid.uuid4().hex
    return h


def body(w, amount, ident="PK00FAKE0000000000000001", name="Synthetic Beneficiary"):
    return {"source_wallet_id": f"b0000000-0000-0000-0000-{w:012d}", "purpose": "FAMILY_SUPPORT",
            "amount": {"currency": "PKR", "minor_units": amount},
            "beneficiary": {"scheme": "IBAN", "identifier": ident, "name": name}}


def post(tok, b, key=None):
    return API.post("/v1/transfers", json=b, headers={"Authorization": f"Bearer {tok}",
                                                      "Idempotency-Key": key or "demo-" + uuid.uuid4().hex})


def show(r):
    j = r.json()
    extra = f" reason={j.get('status_reason') or j.get('code')}" if (j.get("status_reason") or j.get("code")) else ""
    print(f"    HTTP {r.status_code}  {j.get('transaction_reference', '')}  status={j.get('status', '-')}{extra}"
          f"{'  [Idempotent-Replayed]' if r.headers.get('Idempotent-Replayed') else ''}")
    return j


def recon(date=TODAY):
    r = API.post("/v1/reconciliation/runs", json={"statement_date": date}, headers=A(OPS)).json()
    print(f"    reconciliation {date}: imported={r['lines_imported']} matched={r['matched']} new_breaks={r['new_breaks']}")
    return r


def lineage(ref):
    r = q("SELECT status, journals, state_changes, events FROM v_transfer_lineage WHERE transaction_reference = %s", (ref,))[0]
    print(f"    lineage {ref}: status={r['status']} journals=[{r['journals']}] state_changes={r['state_changes']} events={r['events']}")


class Segment:
    def __init__(self, n, title):
        self.n, self.title = n, title

    def __enter__(self):
        print(f"\n=== {self.n}. {self.title}")
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        secs = round(time.perf_counter() - self.t0, 2)
        print(f"    [segment {self.n} ran in {secs} s]")
        SUMMARY["segments"].append({"segment": self.n, "title": self.title, "seconds": secs, "ok": exc[0] is None})
        return False


def check(name, ok):
    SUMMARY["checks"][name] = bool(ok)
    print(f"    check {name}: {'OK' if ok else 'FAILED'}")
    if not ok:
        raise SystemExit(f"demo check failed: {name}")


def main():
    started = time.perf_counter()
    c4 = tok_c(4)

    with Segment(1, "Normal flow: initiate -> screen -> post -> rail -> settle -> notify -> reconcile"):
        w0 = bal("W-CUST-0004")
        t1 = show(post(c4, body(4, 150_000)))
        lineage(t1["transaction_reference"])
        events.relay_once()
        n = q("SELECT status, masked_msisdn FROM notification_log WHERE transfer_id = %s ORDER BY sequence", (t1["transfer_id"],))
        print(f"    notifications: {[r['status'] for r in n]} to {n[-1]['masked_msisdn']}")
        recon()
        st = API.get(f"/v1/transfers/{t1['transfer_id']}", headers=A(c4)).json()["status"]
        print(f"    customer sees: {st}; wallet {rs(w0)} -> {rs(bal('W-CUST-0004'))}")
        check("normal_flow_reconciled", st == "RECONCILED")

    with Segment(2, "Failure 1: rail timeout -> PENDING -> client retry with the same key -> recovery by enquiry"):
        RAIL.post("/_control/script", json={"modes": ["TIMEOUT_EXECUTED"]})
        key = "demo-retry-" + uuid.uuid4().hex[:8]
        t2 = show(post(c4, body(4, 90_000), key))
        print(f"    in transit (2200) = {rs(bal('2200'))}")
        show(post(c4, body(4, 90_000), key))
        submits = RAIL.get("/_control/stats").json()["submit_counts"].get(t2["transaction_reference"])
        print(f"    rail submissions for this reference: {submits}")
        print(f"    worker: {transfers.recover_transfer(t2['transfer_id'])}")
        rl = q("SELECT operation || ':' || outcome AS s FROM rail_message_log WHERE transfer_id = %s ORDER BY msg_id",
               (t2["transfer_id"],))
        print("    rail log: " + " -> ".join(r["s"] for r in rl))
        check("timeout_recovered_once", submits == 1 and
              q("SELECT status::text FROM transfer WHERE transfer_id = %s", (t2["transfer_id"],))[0]["status"] == "SETTLED")

    with Segment(3, "Failure 2: partial failure -> break -> triage assistant -> person decides -> recovered"):
        API.post("/internal/faults", json={"enable": ["fail_settle"]})
        t3 = show(post(c4, body(4, 180_000)))
        API.post("/internal/faults", json={"clear": True})
        print(f"    exception queue: {[(r['kind'], r['owner_role']) for r in q('SELECT kind, owner_role FROM ops_exception WHERE state = %s', ('OPEN',))]}")
        recon()
        brk = q("SELECT break_id::text, break_type::text FROM recon_break WHERE transfer_id = %s", (t3["transfer_id"],))[0]
        s = API.post("/v1/ai/triage", headers=A(OPS), json={"item_type": "BREAK", "item_id": brk["break_id"]}).json()
        print(f"    assistant ({s['model_version']}): {s['recommended_action']} confidence={s['confidence']} advisory_only={s['advisory_only']}")
        print(f"    summary: {s['summary']}")
        r = API.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=A(OPS),
                     json={"decision": "ACCEPT", "comment": "agree; running the enquiry myself"}).json()
        print(f"    analyst review: {r['decision']} (executed={r['executed']})")
        enq = API.post(f"/v1/transfers/{t3['transfer_id']}/status-enquiry", headers=A(OPS)).json()
        print(f"    analyst status enquiry -> {enq['transfer']['status']}")
        API.post(f"/v1/reconciliation/breaks/{brk['break_id']}/resolution", headers=A(OPS, True),
                 json={"resolution_code": "MATCHED_LATE", "comment": "settlement posted after status enquiry"})
        recon()
        check("partial_failure_reconciled",
              q("SELECT status::text FROM transfer WHERE transfer_id = %s", (t3["transfer_id"],))[0]["status"] == "RECONCILED")

    with Segment(4, "Reconciliation outcome: duplicate payment on the rail -> break -> four-eyes write-off"):
        t4 = show(post(tok_c(3), body(3, 120_000, ident="PK00FAKE0000000000000033")))
        RAIL.post("/_control/extra_line", json={"request_id": t4["transaction_reference"], "rail_reference": "RAIL-SYN-DUP1",
                                               "amount_minor": 120_000, "rail_status": "EXECUTED"})
        recon()
        b = q("SELECT break_id::text, break_type::text, owner_role, internal_amount_minor, external_amount_minor "
              "FROM recon_break WHERE transfer_id = %s", (t4["transfer_id"],))[0]
        print(f"    break {b['break_type']} owner={b['owner_role']} ours={rs(b['internal_amount_minor'])} rail={rs(b['external_amount_minor'])}")
        s = API.post("/v1/ai/triage", headers=A(FIN), json={"item_type": "BREAK", "item_id": b["break_id"]}).json()
        print(f"    assistant: {s['recommended_action']} confidence={s['confidence']}")
        API.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=A(FIN),
                 json={"decision": "ACCEPT", "comment": "return requested; rail refused after 5 days"})
        url = f"/v1/reconciliation/breaks/{b['break_id']}/resolution"
        same = API.post(url, headers=A(FIN, True), json={"resolution_code": "WRITTEN_OFF_APPROVED",
                        "comment": "rail refused to return the duplicate", "approved_by": "fin.demo1"})
        print(f"    write-off approved by the same person -> HTTP {same.status_code} {same.json()['code']}")
        ok = API.post(url, headers=A(FIN, True), json={"resolution_code": "WRITTEN_OFF_APPROVED",
                      "comment": "rail refused to return the duplicate", "approved_by": "fin.demo2"})
        print(f"    write-off with a second approver -> HTTP {ok.status_code} {ok.json()['state']}")
        print(f"    write-off expense 5100 = {rs(bal('5100'))}, float 1100 = {rs(bal('1100'))}")
        recon()
        check("write_off_posted", bal("5100") == 120_000 and same.status_code == 403)

    with Segment(5, "Late return after reconciliation -> customer credited, finance told"):
        w0 = bal("W-CUST-0004")
        RAIL.post(f"/_control/return/{t1['transaction_reference']}", params={"ack": "true", "return_date": TOMORROW})
        snap = API.get(f"/v1/transfers/{t1['transfer_id']}", headers=A(c4)).json()
        print(f"    {t1['transaction_reference']}: {snap['status']} ({snap['status_reason']}); wallet {rs(w0)} -> {rs(bal('W-CUST-0004'))}")
        e = q("SELECT exception_id::text, kind, owner_role FROM ops_exception WHERE transfer_id = %s AND state = 'OPEN'",
              (t1["transfer_id"],))[0]
        print(f"    exception queue: {e['kind']} owner={e['owner_role']}")
        recon(TOMORROW)
        API.post(f"/v1/ops/exceptions/{e['exception_id']}/resolution", headers=A(FIN),
                 json={"comment": "closed-day report re-issued with the return"})
        check("late_return_reversed", snap["status"] == "REVERSED")

    with Segment(6, "Controls: hold and release, denied role, rate limit, AI kill switch, audit chain"):
        t6 = show(post(c4, body(4, 6_000_000, ident="PK00FAKE0000000000000099", name="New Beneficiary")))
        case = API.get("/v1/compliance/cases", headers=A(CO)).json()["items"][0]
        print(f"    case reasons={case['reason_codes']} risk={case['risk_score']}")
        r = API.post(f"/v1/compliance/cases/{case['case_id']}/decision", headers=A(OPS, True),
                     json={"decision": "RELEASE", "rationale": "analyst trying to release"})
        print(f"    analyst tries to release -> HTTP {r.status_code} {r.json()['code']}")
        r = API.post(f"/v1/compliance/cases/{case['case_id']}/decision", headers=A(CO, True),
                     json={"decision": "RELEASE", "rationale": "beneficiary verified by callback; purpose documented"})
        print(f"    officer releases -> {r.json()['transfer']['status']}")
        q("UPDATE rate_limit_policy SET max_requests = 2 WHERE scope = 'transfer_create'")
        codes = [post(tok_c(1), body(1, 1_000 + i, ident=f"PK00FAKE{i:016d}")).status_code for i in range(3)]
        q("UPDATE rate_limit_policy SET max_requests = 30 WHERE scope = 'transfer_create'")
        print(f"    rate limit (2 per minute for the demo): {codes}")
        off = API.put("/v1/ai/triage/config", headers=A(FIN2), json={"enabled": False, "reason": "demo of the kill switch"})
        blocked = API.post("/v1/ai/triage", headers=A(OPS), json={"item_type": "EXCEPTION", "item_id": str(uuid.uuid4())})
        print(f"    kill switch on -> assistant answers HTTP {blocked.status_code} {blocked.json()['code']}")
        API.put("/v1/ai/triage/config", headers=A(FIN2), json={"enabled": True, "reason": "demo finished, back on"})
        chain = API.get("/v1/audit/verify", headers=A(FIN)).json()
        den = q("SELECT actor, action FROM audit_log WHERE outcome = 'DENIED' ORDER BY audit_id")
        for d in den:
            print(f"    audit: {d['actor']} {d['action']} DENIED")
        print(f"    audit chain: {chain}")
        check("controls", codes == [202, 202, 429] and blocked.status_code == 503 and chain["chain_ok"]
              and off.status_code == 200 and t6["status"] == "HELD")

    with Segment(7, "Ledger controls and the finance report"):
        h = API.get("/v1/ops/health-summary", headers=A(FIN)).json()
        print(f"    trial balance={h['trial_balance_ok']} projection={h['projection_ok']} float={h['float_invariant_ok']} "
              f"system accounts={h['system_accounts_ok']}")
        print(f"    open breaks={h['open_breaks']} exceptions={h['open_exceptions']} written off={rs(h['written_off_minor'])} "
              f"AI accepted={h['ai_accepted']} abstained={h['ai_abstained']}")
        for row in API.get("/v1/reports/settlement", headers=A(FIN)).json()["items"]:
            print(f"    report {row['business_date']}: transfers={row['transfers']} reconciled={rs(row['reconciled_minor'] or 0)} "
                  f"reversed={rs(row['reversed_minor'] or 0)} open_breaks={row['open_breaks']}")
        check("ledger_controls", h["trial_balance_ok"] and h["projection_ok"] and h["float_invariant_ok"]
              and h["system_accounts_ok"])

    SUMMARY["total_seconds"] = round(time.perf_counter() - started, 2)
    SUMMARY["all_checks_ok"] = all(SUMMARY["checks"].values())
    print(f"\nDemo finished in {SUMMARY['total_seconds']} s; all checks OK: {SUMMARY['all_checks_ok']}")
    if os.environ.get("FW_DEMO_SUMMARY"):
        with open(os.environ["FW_DEMO_SUMMARY"], "w") as f:
            json.dump(SUMMARY, f, indent=2)


if __name__ == "__main__":
    main()
