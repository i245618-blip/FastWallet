"""Small local load test for the accept-latency and availability SLIs (synthetic, local services only).

    FW_JWT_SECRET=... python infra/load_test.py --requests 300 --concurrency 20

Velocity rule R05 and the per-customer rate limit would stop most of these transfers, so the script raises
both for the run and restores them afterwards. It records client-side latency, the server's accept-latency
histogram and the ledger controls after the run.

--wallets one     every transfer from CUST-0004 (worst case: all requests queue on one wallet balance row)
--wallets spread  transfers spread over the five customers allowed to send (CUST-0001..0004, 0006)
"""
import argparse
import concurrent.futures as cf
import json
import os
import statistics
import sys
import time
import uuid

import httpx
import psycopg2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from fastwallet.security import issue_token  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--requests", type=int, default=300)
ap.add_argument("--concurrency", type=int, default=20)
ap.add_argument("--api", default=os.environ.get("FW_API_URL", "http://127.0.0.1:8000"))
ap.add_argument("--out", default="")
ap.add_argument("--wallets", choices=["one", "spread"], default="one")
a = ap.parse_args()
DSN = os.environ["DATABASE_URL"]


def sql(stmt, params=None):
    conn = psycopg2.connect(DSN)
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("SET search_path = fw, public")
    cur.execute(stmt, params)
    out = cur.fetchall() if cur.description else None
    conn.close()
    return out


SENDERS = [4] if a.wallets == "one" else [1, 2, 3, 4, 6]
TOKENS = {n: issue_token(f"CUST-{n:04d}", ["customer"], "fw-loadtest", mfa=True) for n in SENDERS}
old = sql("SELECT params FROM screening_rule WHERE rule_id = 'R05'")[0][0]
sql("UPDATE screening_rule SET params = %s WHERE rule_id = 'R05'", (json.dumps({**old, "max_count": 100000}),))
old_limit = sql("SELECT max_requests FROM rate_limit_policy WHERE scope = 'transfer_create'")[0][0]
sql("UPDATE rate_limit_policy SET max_requests = 1000000 WHERE scope = 'transfer_create'")
client = httpx.Client(base_url=a.api, timeout=30, limits=httpx.Limits(max_connections=a.concurrency))


def one(i):
    n = SENDERS[i % len(SENDERS)]
    t0 = time.perf_counter()
    r = client.post("/v1/transfers", headers={"Authorization": f"Bearer {TOKENS[n]}", "Idempotency-Key": f"load-{uuid.uuid4().hex}"},
                    json={"source_wallet_id": f"b0000000-0000-0000-0000-{n:012d}", "purpose": "OTHER",
                          "amount": {"currency": "PKR", "minor_units": 10_000},
                          "beneficiary": {"scheme": "IBAN", "identifier": f"PK00FAKE{i:016d}", "name": "Load Test"}})
    return time.perf_counter() - t0, r.status_code, r.json().get("status")


try:
    t_start = time.perf_counter()
    with cf.ThreadPoolExecutor(a.concurrency) as pool:
        results = list(pool.map(one, range(a.requests)))
    wall = time.perf_counter() - t_start
finally:
    sql("UPDATE screening_rule SET params = %s WHERE rule_id = 'R05'", (json.dumps(old),))
    sql("UPDATE rate_limit_policy SET max_requests = %s WHERE scope = 'transfer_create'", (old_limit,))

lat = sorted(r[0] for r in results)
pct = lambda p: lat[min(len(lat) - 1, int(p * len(lat)))]  # noqa: E731
codes, statuses = {}, {}
for _, c, s in results:
    codes[c] = codes.get(c, 0) + 1
    statuses[s] = statuses.get(s, 0) + 1
metrics = client.get("/metrics").text
acc = {ln.split("le=\"")[1].split("\"")[0]: float(ln.split()[-1]) for ln in metrics.splitlines()
       if ln.startswith("fw_transfer_accept_seconds_bucket")}
total = acc.get("+Inf", 0)
server_p95 = next((le for le, v in acc.items() if le != "+Inf" and v >= 0.95 * total), "+Inf")
health = sql("SELECT trial_balance_ok, projection_ok, float_invariant_ok FROM v_ops_health")[0]
chain = sql("SELECT chain_ok FROM verify_audit_chain()")[0][0]
report = {
    "requests": a.requests, "concurrency": a.concurrency, "wallets": a.wallets, "wall_seconds": round(wall, 2),
    "throughput_per_second": round(a.requests / wall, 1),
    "client_latency_ms": {"p50": round(pct(0.50) * 1000, 1), "p95": round(pct(0.95) * 1000, 1),
                          "p99": round(pct(0.99) * 1000, 1), "max": round(lat[-1] * 1000, 1),
                          "mean": round(statistics.mean(lat) * 1000, 1)},
    "server_accept_p95_bucket_seconds": server_p95,
    "http_status_counts": codes, "transfer_status_counts": statuses,
    "errors_5xx": sum(v for k, v in codes.items() if k >= 500),
    "ledger_controls_after_run": {"trial_balance_ok": health[0], "projection_ok": health[1], "float_invariant_ok": health[2]},
    "audit_chain_ok_after_run": chain,
    "note": "Client latency includes the inline rail call (mock rail, same machine). Server accept latency stops at the committed POSTED state.",
}
print(json.dumps(report, indent=2))
if a.out:
    open(a.out, "w").write(json.dumps(report, indent=2))
