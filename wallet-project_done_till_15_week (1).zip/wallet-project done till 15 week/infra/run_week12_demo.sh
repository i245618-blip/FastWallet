#!/usr/bin/env bash
# Loads the Week 12 data layer into the database named by DATABASE_URL and runs the demonstration.
# Example: DATABASE_URL=postgresql://fw:fw@localhost:5432/fw ./infra/run_week12_demo.sh
set -euo pipefail
export PGOPTIONS='-c client_min_messages=warning'
cd "$(dirname "$0")/.."
: "${DATABASE_URL:?set DATABASE_URL}"
for f in src/db/01_tables.sql src/db/02_integrity.sql src/db/03_reconciliation.sql src/db/04_reference_data.sql src/db/05_roles.sql \
         data/seed_demo.sql data/demo_helpers.sql; do
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null
done
psql "$DATABASE_URL" -f data/scenarios_week12.sql
