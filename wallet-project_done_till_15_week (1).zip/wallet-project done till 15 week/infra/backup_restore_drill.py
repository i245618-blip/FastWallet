"""Backup and restore drill: measures the full-restore recovery time and proves the restored copy tells the truth.

    DATABASE_URL=postgresql://fw:fw@localhost:5432/fw FW_JWT_SECRET=... python infra/backup_restore_drill.py --out evidence/week14/restore_drill.json

Steps: (1) logical backup of the live database with pg_dump (custom format); (2) the "incident": a new empty
database stands in for the lost one; (3) pg_restore; (4) integrity checks on the copy (row counts, a hash of
every transfer's reference/status/version, balances, ledger controls, audit chain); (5) an API process is
started against the copy and must answer /health/ready and serve a transfer. RTO = steps 3 to 5.
RPO for this method = time since the last dump; WAL archiving would bring it close to zero (not built here).
"""
import argparse
import json
import os
import pathlib
import subprocess
import sys
import time
import urllib.parse

import httpx
import psycopg2

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from fastwallet.security import issue_token  # noqa: E402

TABLES = ["transfer", "journal_entry", "ledger_entry", "transfer_state_history", "outbox_event", "audit_log",
          "recon_break", "rail_message_log", "idempotency_record", "ai_triage_suggestion"]


def facts(dsn):
    conn = psycopg2.connect(dsn)
    cur = conn.cursor()
    cur.execute("SET search_path = fw, public")
    out = {"counts": {}}
    for t in TABLES:
        cur.execute(f"SELECT count(*) FROM {t}")
        out["counts"][t] = cur.fetchone()[0]
    cur.execute("SELECT md5(coalesce(string_agg(transaction_reference || ':' || status || ':' || version, ',' "
                "ORDER BY transaction_reference), '')) FROM transfer")
    out["transfer_state_hash"] = cur.fetchone()[0]
    cur.execute("SELECT md5(coalesce(string_agg(a.code || '=' || b.balance_minor, ',' ORDER BY a.code), '')) "
                "FROM account_balance b JOIN ledger_account a USING (account_id)")
    out["balances_hash"] = cur.fetchone()[0]
    cur.execute("SELECT trial_balance_ok, projection_ok, float_invariant_ok, system_accounts_ok FROM v_ops_health")
    out["ledger_controls"] = dict(zip(["trial_balance", "projection", "float", "system_accounts"], cur.fetchone()))
    cur.execute("SELECT chain_ok FROM verify_audit_chain()")
    out["audit_chain_ok"] = cur.fetchone()[0]
    cur.execute("SELECT transfer_id::text FROM transfer ORDER BY created_at LIMIT 1")
    row = cur.fetchone()
    out["sample_transfer"] = row[0] if row else None
    conn.close()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="")
    ap.add_argument("--port", type=int, default=8301)
    a = ap.parse_args()
    src = os.environ["DATABASE_URL"]
    u = urllib.parse.urlparse(src)
    restore_db = (u.path.lstrip("/") or "fw") + "_restore_drill"
    dst = urllib.parse.urlunparse(u._replace(path="/" + restore_db))
    admin = urllib.parse.urlunparse(u._replace(path="/postgres"))
    dump = pathlib.Path("/tmp/fw_drill.dump")
    before = facts(src)

    t0 = time.perf_counter()
    subprocess.run(["pg_dump", "-Fc", "-f", str(dump), src], check=True)
    backup_s = time.perf_counter() - t0

    conn = psycopg2.connect(admin)
    conn.autocommit = True
    conn.cursor().execute(f'DROP DATABASE IF EXISTS "{restore_db}"')
    conn.cursor().execute(f'CREATE DATABASE "{restore_db}"')
    conn.close()

    t1 = time.perf_counter()
    subprocess.run(["pg_restore", "--exit-on-error", "-d", dst, str(dump)], check=True)
    restore_s = time.perf_counter() - t1
    after = facts(dst)
    verify_s = time.perf_counter() - t1 - restore_s

    env = {**os.environ, "DATABASE_URL": dst, "PYTHONPATH": str(ROOT / "src"), "FW_LOG_FILE": "/tmp/fw_drill_api.log"}
    t2 = time.perf_counter()
    api = subprocess.Popen([sys.executable, "-m", "uvicorn", "fastwallet.api:app", "--port", str(a.port),
                            "--log-level", "warning"], env=env, cwd=str(ROOT))
    served = None
    try:
        c = httpx.Client(base_url=f"http://127.0.0.1:{a.port}", timeout=5)
        for _ in range(200):
            try:
                if c.get("/health/ready").status_code == 200:
                    break
            except httpx.TransportError:
                pass
            time.sleep(0.05)
        ready_s = time.perf_counter() - t2
        if after["sample_transfer"]:
            tok = issue_token("ops.demo1", ["ops_analyst"], "fw-backoffice", mfa=True)
            served = c.get(f"/v1/transfers/{after['sample_transfer']}", headers={"Authorization": f"Bearer {tok}"}).json().get("status")
    finally:
        api.terminate()
        api.wait(10)

    same = {k: before[k] == after[k] for k in ("counts", "transfer_state_hash", "balances_hash")}
    report = {
        "backup_seconds": round(backup_s, 2), "dump_bytes": dump.stat().st_size,
        "restore_seconds": round(restore_s, 2), "verify_seconds": round(verify_s, 2),
        "api_ready_seconds": round(ready_s, 2),
        "rto_seconds_measured": round(restore_s + verify_s + ready_s, 2), "rto_target_seconds": 900,
        "identical_after_restore": same, "ledger_controls_after_restore": after["ledger_controls"],
        "audit_chain_ok_after_restore": after["audit_chain_ok"], "sample_transfer_served_status": served,
        "row_counts": after["counts"],
        "rpo_note": "logical dump: data written after the dump is lost (RPO = dump interval). WAL archiving is the production answer.",
        "passed": all(same.values()) and all(after["ledger_controls"].values()) and after["audit_chain_ok"],
    }
    print(json.dumps(report, indent=2))
    if a.out:
        pathlib.Path(a.out).write_text(json.dumps(report, indent=2))
    conn = psycopg2.connect(admin)
    conn.autocommit = True
    conn.cursor().execute(f'DROP DATABASE IF EXISTS "{restore_db}"')
    conn.close()


if __name__ == "__main__":
    main()
