"""Offline evaluation of the exception-triage assistant on a labelled synthetic case set.

    python infra/ai_triage_eval.py                    # evaluate on data/ai_triage_eval_set.json
    python infra/ai_triage_eval.py --regenerate       # rebuild the case set (fixed seed), then evaluate
    python infra/ai_triage_eval.py --sweep            # also show how the abstention threshold changes the metrics

The labels come from the recovery runbook (docs/architecture/recovery_runbook.md) through gold_label(),
which is written separately from the model in src/fastwallet/triage.py. Some cases carry facts an analyst
would know but the assistant cannot see (ctx_* fields, e.g. a return already announced by the bank), and
some have missing evidence. They are there on purpose: they are where a real assistant goes wrong.

Metrics (targets agreed in ADR-007):
  false_approval_rate     routine step suggested where the runbook needs escalation or a person   <= 2 %
  false_escalation_rate   escalation or abstention where a routine step was right (wasted effort) <= 25 %
  resolution_accuracy     suggestion equals the runbook answer, among answered cases              >= 90 %
  policy_violations       outputs that break a rule (catalogue, material, sanctions, personal data) = 0
  abstention_rate         share handed to a person without a suggestion                          reported
  latency_p95_ms          time to decide one case in-process                                     <= 50 ms
"""
import argparse
import json
import pathlib
import random
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from fastwallet.triage import ABSTAIN, ACTIONS, decide, policy_guard  # noqa: E402

CASES = ROOT / "data" / "ai_triage_eval_set.json"
MATERIAL = 15_000_000
THRESHOLD = 0.70
TARGETS = {"false_approval_rate": ("<=", 0.02), "false_escalation_rate": ("<=", 0.25),
           "resolution_accuracy": (">=", 0.90), "policy_violations": ("==", 0), "latency_p95_ms": ("<=", 50.0)}


# ---------------------------------------------------------------- runbook answer (independent of the model)

def gold_label(c: dict) -> str:
    amount = max(c.get("amount_minor") or 0, c.get("external_amount_minor") or 0, c.get("internal_amount_minor") or 0)
    if amount >= MATERIAL or c.get("has_compliance_case") or "R07" in (c.get("screening_reasons") or []):
        return ABSTAIN
    k, st = c["kind"], c.get("transfer_status")
    if k != "UNMATCHED_EXTERNAL" and not c.get("transaction_reference"):
        return ABSTAIN
    if c.get("ctx_return_announced"):                      # the bank has told us a return is coming
        return "ESCALATE_FINANCE_REVIEW"
    if c.get("ctx_rail_outage_known") and k in ("UNMATCHED_INTERNAL", "RECOVERY_EXHAUSTED"):
        return "WAIT_FOR_AUTOMATED_RECOVERY"
    table = {
        "UNMATCHED_EXTERNAL": lambda: "ESCALATE_COMPLIANCE_REVIEW",
        "MISSING": lambda: "ESCALATE_FINANCE_REVIEW",
        "RAIL_OUTCOME_CONFLICT": lambda: "ESCALATE_FINANCE_REVIEW",
        "LATE_RETURN_AFTER_RECON": lambda: "ESCALATE_FINANCE_REVIEW",
        "DUPLICATE": lambda: "REQUEST_RAIL_CORRECTION",
        "AMOUNT_MISMATCH": lambda: ("ESCALATE_FINANCE_REVIEW" if c["external_amount_minor"] > c["internal_amount_minor"]
                                    else "REQUEST_RAIL_CORRECTION"),
        "POSTING_FAILED": lambda: "WAIT_FOR_AUTOMATED_RECOVERY" if c["age_minutes"] < 30 else "ESCALATE_FINANCE_REVIEW",
        "RECOVERY_EXHAUSTED": lambda: (c.get("ctx_analyst_choice") or
                                       ("RUN_STATUS_ENQUIRY" if c["transfer_age_minutes"] < 240 else "ESCALATE_FINANCE_REVIEW")),
    }
    if k in table:
        return table[k]()
    if k == "UNMATCHED_INTERNAL":
        if st == "PENDING" and c["transfer_age_minutes"] < 15:
            return "WAIT_FOR_AUTOMATED_RECOVERY"
        return "RUN_STATUS_ENQUIRY" if st in ("POSTED", "PENDING") else "ESCALATE_FINANCE_REVIEW"
    if k == "STATUS_MISMATCH":
        executed, returned, last = c["statement_executed_lines"], c["statement_returned"], c.get("last_rail_outcome")
        if st in ("SETTLED", "RECONCILED"):
            if returned:
                return "ESCALATE_FINANCE_REVIEW"
            return "RESOLVE_AS_MATCHED_LATE" if executed else "RUN_STATUS_ENQUIRY"
        if st == "REVERSED":
            if returned or last in ("REJECTED", "RETURNED"):
                return "RESOLVE_AS_MATCHED_LATE"
            return "ESCALATE_FINANCE_REVIEW"
        return "RUN_STATUS_ENQUIRY"
    return ABSTAIN


# ---------------------------------------------------------------- synthetic case generator

def _base(rng, i, kind, owner):
    amount = rng.choice([50_000, 150_000, 480_000, 1_250_000, 2_000_000, 4_500_000, 9_000_000])
    return {"case_id": f"C{i:03d}", "item_type": "BREAK", "kind": kind, "owner_role": owner, "state": "OPEN",
            "age_minutes": rng.randint(5, 600), "transaction_reference": f"FW-20261118-{i:06d}",
            "transfer_status": "SETTLED", "status_reason": None, "transfer_age_minutes": rng.randint(10, 900),
            "amount_minor": amount, "internal_amount_minor": amount, "external_amount_minor": amount,
            "enquiry_attempts": rng.randint(0, 3), "last_rail_outcome": "EXECUTED", "statement_executed_lines": 1,
            "statement_returned": False, "journals": ["TRANSFER_POST", "TRANSFER_SETTLE"],
            "has_compliance_case": False, "screening_reasons": [], "detail": f"synthetic {kind}"}


def generate(n=240, seed=20261118):
    rng = random.Random(seed)
    cases = []
    for i in range(1, n + 1):
        arche = rng.choices(
            ["ui_open", "ui_settled", "sm_settled", "sm_reversed_ok", "sm_open", "sm_reversed_paid", "am_loss",
             "am_short", "dup", "ext", "missing", "pf", "rex", "conflict", "late_return"],
            weights=[14, 4, 16, 6, 8, 3, 5, 4, 7, 5, 3, 9, 8, 4, 4])[0]
        if arche.startswith("ui"):
            c = _base(rng, i, "UNMATCHED_INTERNAL", "ops_analyst")
            c.update(external_amount_minor=None, statement_executed_lines=0, last_rail_outcome=None)
            if arche == "ui_open":
                c.update(transfer_status=rng.choice(["POSTED", "PENDING"]), journals=["TRANSFER_POST"],
                         transfer_age_minutes=rng.randint(3, 400), last_rail_outcome=rng.choice([None, "UNKNOWN"]))
                c["ctx_rail_outage_known"] = rng.random() < 0.06
        elif arche.startswith("sm"):
            c = _base(rng, i, "STATUS_MISMATCH", "ops_analyst")
            if arche == "sm_settled":
                c["ctx_return_announced"] = rng.random() < 0.04
                if rng.random() < 0.08:                      # evidence incomplete: no statement line yet
                    c.update(statement_executed_lines=0, last_rail_outcome=None)
            elif arche == "sm_reversed_ok":
                c.update(transfer_status="REVERSED", statement_returned=rng.random() < 0.6,
                         last_rail_outcome=rng.choice(["REJECTED", "RETURNED"]),
                         journals=["TRANSFER_POST", "TRANSFER_REVERSE"])
            elif arche == "sm_open":
                c.update(transfer_status=rng.choice(["POSTED", "PENDING"]), journals=["TRANSFER_POST"])
            else:
                c.update(transfer_status="REVERSED", last_rail_outcome="EXECUTED",
                         journals=["TRANSFER_POST", "TRANSFER_REVERSE"])
        elif arche.startswith("am"):
            c = _base(rng, i, "AMOUNT_MISMATCH", "finance_controller")
            d = rng.choice([100, 5_000, 25_000])
            c["external_amount_minor"] = c["internal_amount_minor"] + (d if arche == "am_loss" else -d)
        elif arche == "dup":
            c = _base(rng, i, "DUPLICATE", "finance_controller")
            lines = rng.choice([2, 2, 3])
            c.update(statement_executed_lines=lines, external_amount_minor=c["internal_amount_minor"] * lines)
        elif arche == "ext":
            c = _base(rng, i, "UNMATCHED_EXTERNAL", "ops_analyst")
            c.update(transaction_reference=None, transfer_status=None, amount_minor=None, internal_amount_minor=None,
                     journals=[], last_rail_outcome=None, statement_executed_lines=0)
        elif arche == "missing":
            c = _base(rng, i, "MISSING", "finance_controller")
            c.update(journals=["TRANSFER_POST"])
        elif arche == "pf":
            c = _base(rng, i, "POSTING_FAILED", "finance_controller")
            c.update(item_type="EXCEPTION", transfer_status="POSTED", journals=["TRANSFER_POST"],
                     internal_amount_minor=None, external_amount_minor=None, age_minutes=rng.randint(1, 120))
        elif arche == "rex":
            c = _base(rng, i, "RECOVERY_EXHAUSTED", "ops_analyst")
            c.update(item_type="EXCEPTION", transfer_status="PENDING", journals=["TRANSFER_POST"], enquiry_attempts=5,
                     last_rail_outcome="UNKNOWN", internal_amount_minor=None, external_amount_minor=None,
                     statement_executed_lines=0, transfer_age_minutes=rng.randint(30, 600))
            if 200 <= c["transfer_age_minutes"] <= 280 and rng.random() < 0.3:   # judgement call near the boundary
                c["ctx_analyst_choice"] = ("ESCALATE_FINANCE_REVIEW" if c["transfer_age_minutes"] < 240
                                           else "RUN_STATUS_ENQUIRY")
            c["ctx_rail_outage_known"] = rng.random() < 0.08
        elif arche == "conflict":
            c = _base(rng, i, "RAIL_OUTCOME_CONFLICT", "finance_controller")
            c.update(item_type="EXCEPTION", transfer_status=rng.choice(["FAILED", "REVERSED"]),
                     internal_amount_minor=None, external_amount_minor=None)
        else:
            c = _base(rng, i, "LATE_RETURN_AFTER_RECON", "finance_controller")
            c.update(item_type="EXCEPTION", transfer_status="REVERSED", statement_returned=True,
                     journals=["TRANSFER_POST", "TRANSFER_SETTLE", "TRANSFER_RETURN"],
                     internal_amount_minor=None, external_amount_minor=None)
        # cases that must go to a person whatever the pattern
        r = rng.random()
        if r < 0.05:
            c["amount_minor"] = rng.choice([15_000_000, 18_000_000])
            if c.get("internal_amount_minor") is not None:
                c["internal_amount_minor"] = c["amount_minor"]
        elif r < 0.08 and c.get("transaction_reference"):
            c["screening_reasons"] = ["R07"]
        elif r < 0.10 and c["kind"] != "UNMATCHED_EXTERNAL":
            c["transaction_reference"] = None
        c["gold"] = gold_label(c)
        cases.append(c)
    return cases


# ---------------------------------------------------------------- evaluation

def tier(action):
    if action == ABSTAIN:
        return "HUMAN"
    return ACTIONS[action][0]


def evaluate(cases, threshold=THRESHOLD):
    rows, lat = [], []
    for c in cases:
        f = {k: v for k, v in c.items() if not k.startswith("ctx_") and k not in ("gold", "case_id")}
        t0 = time.perf_counter()
        s = decide(f, threshold, MATERIAL)
        violations = policy_guard(s, f, MATERIAL)
        lat.append((time.perf_counter() - t0) * 1000)
        rows.append({"case_id": c["case_id"], "kind": c["kind"], "gold": c["gold"], "out": s["recommended_action"],
                     "confidence": s["confidence"], "abstain_reason": s["abstain_reason"], "violations": violations})
    n = len(rows)
    needs_person = [r for r in rows if tier(r["gold"]) in ("ESCALATE", "HUMAN")]
    routine = [r for r in rows if tier(r["gold"]) == "ROUTINE"]
    answered = [r for r in rows if r["out"] != ABSTAIN]
    false_approvals = [r for r in needs_person if tier(r["out"]) == "ROUTINE"]
    false_escalations = [r for r in routine if tier(r["out"]) in ("ESCALATE", "HUMAN")]
    correct = [r for r in answered if r["out"] == r["gold"]]
    must_abstain = [r for r in rows if r["gold"] == ABSTAIN]
    lat.sort()
    m = {
        "cases": n, "threshold": threshold,
        "false_approval_rate": round(len(false_approvals) / n, 4), "false_approvals": len(false_approvals),
        "false_escalation_rate": round(len(false_escalations) / max(1, len(routine)), 4),
        "false_escalations": len(false_escalations), "routine_cases": len(routine),
        "resolution_accuracy": round(len(correct) / max(1, len(answered)), 4), "answered": len(answered),
        "abstention_rate": round((n - len(answered)) / n, 4),
        "must_abstain_cases": len(must_abstain),
        "must_abstain_honoured": sum(1 for r in must_abstain if r["out"] == ABSTAIN),
        "policy_violations": sum(1 for r in rows if r["violations"]),
        "latency_p95_ms": round(lat[int(0.95 * (n - 1))], 3),
        "abstain_reasons": {},
    }
    for r in rows:
        if r["abstain_reason"]:
            m["abstain_reasons"][r["abstain_reason"]] = m["abstain_reasons"].get(r["abstain_reason"], 0) + 1
    m["targets_met"] = all({"<=": m[k] <= v, ">=": m[k] >= v, "==": m[k] == v}[op] for k, (op, v) in TARGETS.items())
    m["errors"] = [r for r in rows if (r["out"] != r["gold"])][:40]
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--regenerate", action="store_true")
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    if a.regenerate or not CASES.exists():
        CASES.write_text(json.dumps(generate(), indent=1))
    cases = json.loads(CASES.read_text())
    m = evaluate(cases)
    report = {k: v for k, v in m.items() if k != "errors"}
    if a.sweep:
        report["threshold_sweep"] = [{k: evaluate(cases, t)[k] for k in
                                      ("threshold", "false_approval_rate", "false_escalation_rate",
                                       "resolution_accuracy", "abstention_rate")} for t in (0.5, 0.6, 0.7, 0.8, 0.9)]
    print(json.dumps(report, indent=2))
    if a.out:
        pathlib.Path(a.out).write_text(json.dumps({**report, "disagreements_sample": m["errors"]}, indent=2))


if __name__ == "__main__":
    main()
