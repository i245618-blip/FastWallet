"""Small helpers shared by the database tests."""
from contextlib import contextmanager

import psycopg2


@contextmanager
def expect_error(cur, token):
    """Run a block that must fail with an error containing `token`, then undo only that block."""
    cur.execute("SAVEPOINT expect_error")
    try:
        yield
    except psycopg2.Error as exc:
        assert token in str(exc), f"expected {token!r} in error, got: {exc}"
        cur.execute("ROLLBACK TO SAVEPOINT expect_error")
    else:
        raise AssertionError(f"expected an error containing {token!r}, but nothing failed")


def scalar(cur, sql, params=None):
    cur.execute(sql, params)
    row = cur.fetchone()
    return row[0] if row else None


def balance(cur, code):
    return scalar(cur, "SELECT coalesce((SELECT balance_minor FROM account_balance b "
                       "JOIN ledger_account a USING (account_id) WHERE a.code = %s), 0)", (code,))


def make_transfer(cur, wallet_n, amount, target):
    return scalar(cur, "SELECT demo_make_transfer(%s, %s, %s)", (wallet_n, amount, target))


def statement_line(cur, ref, amount, status):
    cur.execute("SELECT demo_statement_line(%s, %s, %s)", (ref, amount, status))
