"""Week 12 data/control gate: tests for ledger, state, events, controls and reconciliation rules.

Each test maps to one of the required scenarios in the project guidelines (section 5) or to an
integrity rule documented in the Week 12 submission.
"""
import json
import pathlib
import uuid

import psycopg2
import pytest
from jsonschema import Draft202012Validator, FormatChecker

from helpers import balance, expect_error, make_transfer, scalar, statement_line

ROOT = pathlib.Path(__file__).resolve().parents[1]
EVENT_SCHEMA = json.loads((ROOT / "api/events/transfer-status-changed.v1.schema.json").read_text())

OPS1 = "d0000000-0000-0000-0000-000000000001"
OPS2 = "d0000000-0000-0000-0000-000000000002"
FIN1 = "d0000000-0000-0000-0000-000000000003"
CO1 = "d0000000-0000-0000-0000-000000000005"


def transfer_id(cur, ref):
    return scalar(cur, "SELECT transfer_id FROM transfer WHERE transaction_reference = %s", (ref,))


# ---------------------------------------------------------------- reference data

def test_reference_and_seed_data_loaded(cur):
    assert scalar(cur, "SELECT count(*) FROM tier_policy") == 3
    assert scalar(cur, "SELECT count(*) FROM allowed_transition") == 15   # 14 + RECONCILED->REVERSED (Week 14 late return)
    assert scalar(cur, "SELECT count(*) FROM screening_rule WHERE active") == 10
    assert scalar(cur, "SELECT count(*) FROM wallet") == 6
    assert scalar(cur, "SELECT count(*) FROM break_policy") == 6


def test_seed_ledger_balances_and_float_equals_wallet_total(cur):
    wallets = scalar(cur, "SELECT sum(balance_minor) FROM account_balance b "
                          "JOIN ledger_account a USING (account_id) WHERE a.code LIKE 'W-CUST-%'")
    assert balance(cur, "1100") == wallets == 72_500_000
    assert scalar(cur, "SELECT count(*) FROM v_balance_projection_check") == 0


# ---------------------------------------------------------------- ledger rules

def test_unbalanced_journal_is_rejected_at_commit(cur):
    jid = str(uuid.uuid4())
    cur.execute("INSERT INTO journal_entry (journal_id, journal_type, funding_reference) "
                "VALUES (%s, 'FUNDING', 'T-UNBALANCED')", (jid,))
    cur.execute("INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) "
                "SELECT %s, 1, account_id, 'DEBIT', 100 FROM ledger_account WHERE code = '1100'", (jid,))
    with expect_error(cur, "UNBALANCED_JOURNAL"):
        cur.execute("SET CONSTRAINTS ALL IMMEDIATE")


def test_journal_without_entries_is_rejected(cur):
    cur.execute("INSERT INTO journal_entry (journal_type, funding_reference) VALUES ('FUNDING', 'T-EMPTY')")
    with expect_error(cur, "UNBALANCED_JOURNAL"):
        cur.execute("SET CONSTRAINTS ALL IMMEDIATE")


@pytest.mark.parametrize("sql", [
    "UPDATE ledger_entry SET amount_minor = 1",
    "DELETE FROM ledger_entry",
    "UPDATE journal_entry SET description = 'x'",
    "UPDATE transfer_state_history SET reason = 'x'",
])
def test_ledger_and_history_are_append_only(cur, sql):
    make_transfer(cur, 4, 100_000, "POSTED")
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute(sql)


def test_ledger_cannot_be_truncated(cur):
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute("TRUNCATE ledger_entry")
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute("TRUNCATE audit_log")


def test_overdraft_is_blocked_by_the_database(cur):
    # wallet 1 holds Rs 20,000; Rs 25,000 must not post
    with expect_error(cur, "INSUFFICIENT_FUNDS"):
        make_transfer(cur, 1, 2_500_000, "POSTED")


def test_normal_path_postings_and_trial_balance(cur):
    w0, f0 = balance(cur, "W-CUST-0004"), balance(cur, "1100")
    ref = make_transfer(cur, 4, 150_000, "POSTED")
    assert balance(cur, "W-CUST-0004") == w0 - 150_000
    assert balance(cur, "2200") == 150_000
    assert balance(cur, "1100") == f0

    cur.execute("SELECT demo_make_transfer(4, 100000, 'SETTLED')")  # second transfer, to settlement
    tid = transfer_id(cur, ref)
    cur.execute("SELECT ledger_post(%s, 'TRANSFER_SETTLE')", (tid,))
    cur.execute("UPDATE transfer SET status = 'SETTLED', rail_reference = 'RAIL-SYN-T1' WHERE transfer_id = %s", (tid,))
    assert balance(cur, "2200") == 0
    assert balance(cur, "1100") == f0 - 250_000

    debits, credits = scalar(cur, "SELECT sum(debit_total_minor), sum(credit_total_minor) FROM v_trial_balance"), None
    cur.execute("SELECT sum(debit_total_minor), sum(credit_total_minor) FROM v_trial_balance")
    debits, credits = cur.fetchone()
    assert debits == credits
    assert scalar(cur, "SELECT count(*) FROM v_balance_projection_check") == 0
    assert scalar(cur, "SELECT journals FROM v_transfer_lineage WHERE transaction_reference = %s", (ref,)) \
        == "TRANSFER_POST, TRANSFER_SETTLE"


def test_reversal_before_settlement_restores_wallet(cur):
    w0 = balance(cur, "W-CUST-0004")
    ref = make_transfer(cur, 4, 200_000, "REVERSED_PRE")
    assert balance(cur, "W-CUST-0004") == w0
    assert balance(cur, "2200") == 0
    reverse = scalar(cur, "SELECT reverses_journal_id IS NOT NULL FROM journal_entry j JOIN transfer t USING (transfer_id) "
                          "WHERE t.transaction_reference = %s AND j.journal_type = 'TRANSFER_REVERSE'", (ref,))
    assert reverse is True


def test_return_after_settlement_restores_wallet_and_float(cur):
    w0, f0 = balance(cur, "W-CUST-0004"), balance(cur, "1100")
    make_transfer(cur, 4, 300_000, "RETURNED")
    assert balance(cur, "W-CUST-0004") == w0
    assert balance(cur, "1100") == f0
    assert balance(cur, "2200") == 0


def test_a_transfer_gets_at_most_one_journal_of_each_type(cur):
    ref = make_transfer(cur, 4, 100_000, "POSTED")
    tid = transfer_id(cur, ref)
    with expect_error(cur, "INVALID_STATE_FOR_POSTING"):
        cur.execute("SELECT ledger_post(%s, 'TRANSFER_POST')", (tid,))
    with expect_error(cur, "uq_journal_per_transfer_type"):
        cur.execute("INSERT INTO journal_entry (transfer_id, journal_type) VALUES (%s, 'TRANSFER_POST')", (tid,))


# ---------------------------------------------------------------- state machine

def test_invalid_transition_is_rejected(cur):
    ref = make_transfer(cur, 4, 100_000, "INITIATED")
    with expect_error(cur, "INVALID_STATE_TRANSITION"):
        cur.execute("UPDATE transfer SET status = 'SETTLED' WHERE transaction_reference = %s", (ref,))


def test_status_cannot_claim_more_than_the_ledger_shows(cur):
    ref = make_transfer(cur, 4, 100_000, "AUTHORISED")
    with expect_error(cur, "STATE_LEDGER_MISMATCH"):
        cur.execute("UPDATE transfer SET status = 'POSTED' WHERE transaction_reference = %s", (ref,))


def test_terminal_states_have_no_exit(cur):
    ref = make_transfer(cur, 4, 100_000, "REVERSED_PRE")
    with expect_error(cur, "INVALID_STATE_TRANSITION"):
        cur.execute("UPDATE transfer SET status = 'SETTLED' WHERE transaction_reference = %s", (ref,))


def test_transaction_reference_amount_and_beneficiary_are_immutable(cur):
    ref = make_transfer(cur, 4, 100_000, "INITIATED")
    for col, val in [("transaction_reference", "'FW-20260101-000001'"), ("amount_minor", "5"),
                     ("beneficiary_identifier", "'PK00FAKE0000000000000099'")]:
        with expect_error(cur, "IMMUTABLE_FIELD"):
            cur.execute(f"UPDATE transfer SET {col} = {val} WHERE transaction_reference = %s", (ref,))


def test_state_history_records_every_change_and_actor(cur):
    ref = make_transfer(cur, 4, 100_000, "SETTLED")
    cur.execute("SELECT sequence, from_status, to_status, actor FROM transfer_state_history h "
                "JOIN transfer t USING (transfer_id) WHERE t.transaction_reference = %s ORDER BY sequence", (ref,))
    rows = cur.fetchall()
    assert [r[2] for r in rows] == ["INITIATED", "AUTHORISED", "POSTED", "SETTLED"]
    assert rows[0][1] is None and rows[-1][3] == "demo-driver"


# ---------------------------------------------------------------- events

def test_outbox_events_follow_the_week10_event_schema(cur):
    ref = make_transfer(cur, 4, 150_000, "SETTLED")
    tid = transfer_id(cur, ref)
    cur.execute("SELECT payload, sequence FROM outbox_event WHERE aggregate_id = %s ORDER BY sequence", (tid,))
    rows = cur.fetchall()
    assert [r[1] for r in rows] == [1, 2, 3, 4]
    validator = Draft202012Validator(EVENT_SCHEMA, format_checker=FormatChecker())
    for payload, seq in rows:
        validator.validate(payload)
        assert payload["sequence"] == seq and payload["transaction_reference"] == ref
    assert rows[-1][0]["data"]["status"] == "SETTLED" and rows[-1][0]["data"]["previous_status"] == "POSTED"
    assert "national_id" not in json.dumps(rows) and "full_name" not in json.dumps(rows)


def test_outbox_rows_cannot_be_rewritten_but_can_be_marked_published(cur):
    ref = make_transfer(cur, 4, 100_000, "INITIATED")
    tid = transfer_id(cur, ref)
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute("UPDATE outbox_event SET payload = '{}' WHERE aggregate_id = %s", (tid,))
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute("DELETE FROM outbox_event WHERE aggregate_id = %s", (tid,))
    cur.execute("UPDATE outbox_event SET published_at = now(), publish_attempts = 1 WHERE aggregate_id = %s", (tid,))
    assert cur.rowcount == 1


def test_duplicate_event_is_rejected_by_inbox_and_outbox_keys(cur):
    ref = make_transfer(cur, 4, 100_000, "INITIATED")
    tid = transfer_id(cur, ref)
    event_id = scalar(cur, "SELECT event_id FROM outbox_event WHERE aggregate_id = %s", (tid,))
    cur.execute("INSERT INTO inbox_event (consumer_name, event_id) VALUES ('notification', %s)", (event_id,))
    with expect_error(cur, "inbox_event_pkey"):
        cur.execute("INSERT INTO inbox_event (consumer_name, event_id) VALUES ('notification', %s)", (event_id,))
    cur.execute("INSERT INTO inbox_event (consumer_name, event_id) VALUES ('reporting', %s)", (event_id,))
    with expect_error(cur, "outbox_event_aggregate_id_sequence_key"):
        cur.execute("INSERT INTO outbox_event (event_id, aggregate_type, aggregate_id, sequence, event_type, "
                    "schema_version, correlation_id, payload) SELECT gen_random_uuid(), 'transfer', aggregate_id, "
                    "sequence, event_type, schema_version, correlation_id, payload FROM outbox_event "
                    "WHERE aggregate_id = %s", (tid,))


# ---------------------------------------------------------------- idempotency store

def test_idempotency_key_is_unique_per_client(cur):
    q = ("INSERT INTO idempotency_record (client_id, idem_key, request_hash, state) "
         "VALUES (%s, %s, repeat('a', 64), 'IN_PROGRESS')")
    cur.execute(q, ("app-1", "key-0000000000000001"))
    with expect_error(cur, "idempotency_record_pkey"):
        cur.execute(q, ("app-1", "key-0000000000000001"))
    cur.execute(q, ("app-2", "key-0000000000000001"))   # same key, different client, allowed


# ---------------------------------------------------------------- controls

def test_reversal_needs_two_different_people_with_the_right_roles(cur):
    ref = make_transfer(cur, 4, 100_000, "SETTLED")
    tid = transfer_id(cur, ref)
    with expect_error(cur, "ROLE_NOT_PERMITTED"):       # a finance controller cannot raise it
        cur.execute("INSERT INTO reversal_request (original_transfer_id, reason_code, reason_text, requested_by) "
                    "VALUES (%s, 'CUSTOMER_DISPUTE', 'beneficiary account closed', %s)", (tid, FIN1))
    cur.execute("INSERT INTO reversal_request (original_transfer_id, reason_code, reason_text, requested_by) "
                "VALUES (%s, 'CUSTOMER_DISPUTE', 'beneficiary account closed', %s) RETURNING reversal_id", (tid, OPS1))
    rid = cur.fetchone()[0]
    with expect_error(cur, "SOD_VIOLATION"):
        cur.execute("UPDATE reversal_request SET state='APPROVED', decided_by=%s, decided_at=now() "
                    "WHERE reversal_id=%s", (OPS1, rid))
    with expect_error(cur, "ROLE_NOT_PERMITTED"):       # another analyst is not a checker
        cur.execute("UPDATE reversal_request SET state='APPROVED', decided_by=%s, decided_at=now() "
                    "WHERE reversal_id=%s", (OPS2, rid))
    cur.execute("UPDATE reversal_request SET state='APPROVED', decided_by=%s, decided_at=now() "
                "WHERE reversal_id=%s", (FIN1, rid))
    with expect_error(cur, "uq_open_reversal"):         # no second open reversal for the same transfer
        cur.execute("INSERT INTO reversal_request (original_transfer_id, reason_code, reason_text, requested_by) "
                    "VALUES (%s, 'CUSTOMER_DISPUTE', 'second attempt here', %s)", (tid, OPS2))


def test_compliance_hold_preserves_evidence_and_needs_an_officer(cur):
    ref = make_transfer(cur, 3, 15_000_000, "INITIATED")
    tid = transfer_id(cur, ref)
    cur.execute("UPDATE transfer SET status = 'HELD', status_reason = 'COMPLIANCE_HOLD' WHERE transfer_id = %s", (tid,))
    cur.execute("INSERT INTO screening_decision (transfer_id, customer_id, rules_version, outcome, risk_score, "
                "reason_codes, inputs) VALUES (%s, 'c0000000-0000-0000-0000-000000000003', 'rules-v1', 'HOLD', 70, "
                "ARRAY['R10'], '{\"amount_minor\": 15000000}') RETURNING decision_id", (tid,))
    did = cur.fetchone()[0]
    cur.execute("INSERT INTO compliance_case (transfer_id, decision_id) VALUES (%s, %s) RETURNING case_id", (tid, did))
    cid = cur.fetchone()[0]
    with expect_error(cur, "ROLE_NOT_PERMITTED"):
        cur.execute("INSERT INTO case_decision (case_id, decision, rationale, decided_by) "
                    "VALUES (%s, 'RELEASE', 'looks fine to me', %s)", (cid, OPS1))
    cur.execute("INSERT INTO case_decision (case_id, decision, rationale, decided_by) "
                "VALUES (%s, 'RELEASE', 'salary payment confirmed with employer letter', %s)", (cid, CO1))
    assert scalar(cur, "SELECT state FROM compliance_case WHERE case_id = %s", (cid,)) == "RELEASED"
    with expect_error(cur, "IMMUTABLE_RECORD"):         # the original screening evidence is untouched
        cur.execute("UPDATE screening_decision SET outcome = 'ALLOW' WHERE decision_id = %s", (did,))
    cur.execute("UPDATE transfer SET status = 'AUTHORISED' WHERE transfer_id = %s", (tid,))


def test_audit_log_is_hash_chained_and_tampering_is_detected(cur):
    for i in range(3):
        cur.execute("SELECT audit('ops.demo1', 'ops_analyst', 'TRANSFER_READ', 'transfer', %s, 'ALLOWED')", (f"t{i}",))
    cur.execute("SELECT audit('cust-0001', 'customer', 'REVERSAL_REQUEST', 'transfer', 't9', 'DENIED')")
    cur.execute("SELECT chain_ok FROM verify_audit_chain()")
    assert cur.fetchone()[0] is True
    with expect_error(cur, "IMMUTABLE_RECORD"):
        cur.execute("UPDATE audit_log SET outcome = 'ALLOWED'")
    # simulate a privileged tamper that bypasses triggers
    try:
        cur.execute("SET LOCAL session_replication_role = replica")
    except psycopg2.Error:
        pytest.skip("needs a superuser to simulate tampering")
    cur.execute("UPDATE audit_log SET details = '{\"edited\": true}' WHERE audit_id = (SELECT min(audit_id) FROM audit_log)")
    cur.execute("SET LOCAL session_replication_role = origin")
    cur.execute("SELECT chain_ok, first_bad_id FROM verify_audit_chain()")
    ok, bad = cur.fetchone()
    assert ok is False and bad is not None


# ---------------------------------------------------------------- reconciliation

def build_scenarios(cur):
    s = {}
    s["ok"] = make_transfer(cur, 4, 100_000, "SETTLED");        statement_line(cur, s["ok"], 100_000, "EXECUTED")
    s["status"] = make_transfer(cur, 4, 110_000, "PENDING");    statement_line(cur, s["status"], 110_000, "EXECUTED")
    s["amount"] = make_transfer(cur, 4, 120_000, "SETTLED");    statement_line(cur, s["amount"], 119_000, "EXECUTED")
    s["dup"] = make_transfer(cur, 4, 130_000, "SETTLED")
    statement_line(cur, s["dup"], 130_000, "EXECUTED");         statement_line(cur, s["dup"], 130_000, "EXECUTED")
    s["unint"] = make_transfer(cur, 4, 140_000, "SETTLED")
    s["rejected"] = make_transfer(cur, 4, 150_000, "REVERSED_PRE"); statement_line(cur, s["rejected"], 150_000, "REJECTED")
    s["returned"] = make_transfer(cur, 4, 160_000, "RETURNED")
    statement_line(cur, s["returned"], 160_000, "EXECUTED");    statement_line(cur, s["returned"], 160_000, "RETURNED")
    s["late_return"] = make_transfer(cur, 4, 170_000, "SETTLED")
    statement_line(cur, s["late_return"], 170_000, "EXECUTED"); statement_line(cur, s["late_return"], 170_000, "RETURNED")
    s["stuck"] = make_transfer(cur, 4, 180_000, "PENDING")
    statement_line(cur, "FW-20990101-000001", 999_000, "EXECUTED")   # unknown to us
    return s


def run_recon(cur):
    cur.execute("SELECT run_reconciliation(current_date, 'test-run', interval '0 seconds')")
    return cur.fetchone()[0]


def breaks_by_type(cur):
    cur.execute("SELECT break_type::text, count(*) FROM recon_break GROUP BY 1")
    return dict(cur.fetchall())


def test_reconciliation_classifies_every_scenario(cur):
    s = build_scenarios(cur)
    run_recon(cur)
    assert breaks_by_type(cur) == {"DUPLICATE": 1, "UNMATCHED_EXTERNAL": 1, "AMOUNT_MISMATCH": 1,
                                   "STATUS_MISMATCH": 2, "UNMATCHED_INTERNAL": 2}
    cur.execute("SELECT t.transaction_reference, b.break_type::text FROM recon_break b JOIN transfer t USING (transfer_id)")
    got = {(r, t) for r, t in cur.fetchall()}
    assert (s["status"], "STATUS_MISMATCH") in got and (s["late_return"], "STATUS_MISMATCH") in got
    assert (s["amount"], "AMOUNT_MISMATCH") in got and (s["dup"], "DUPLICATE") in got
    assert (s["unint"], "UNMATCHED_INTERNAL") in got and (s["stuck"], "UNMATCHED_INTERNAL") in got
    # clean items are matched, and a matched settled transfer becomes RECONCILED
    assert scalar(cur, "SELECT matched_count FROM recon_run WHERE run_by = 'test-run'") == 3
    assert scalar(cur, "SELECT status::text FROM transfer WHERE transaction_reference = %s", (s["ok"],)) == "RECONCILED"
    assert scalar(cur, "SELECT status::text FROM transfer WHERE transaction_reference = %s", (s["dup"],)) == "SETTLED"


def test_every_break_has_an_owner_and_due_time(cur):
    build_scenarios(cur)
    run_recon(cur)
    assert scalar(cur, "SELECT count(*) FROM recon_break WHERE owner_role IS NULL OR due_at IS NULL") == 0
    assert scalar(cur, "SELECT owner_role FROM recon_break WHERE break_type = 'AMOUNT_MISMATCH'") == "finance_controller"
    assert scalar(cur, "SELECT owner_role FROM recon_break WHERE break_type = 'UNMATCHED_EXTERNAL'") == "ops_analyst"


def test_rerunning_reconciliation_does_not_duplicate_breaks(cur):
    build_scenarios(cur)
    run_recon(cur)
    first = scalar(cur, "SELECT count(*) FROM recon_break")
    run_recon(cur)
    assert scalar(cur, "SELECT count(*) FROM recon_break") == first == 7


def test_break_resolution_enforces_owner_and_four_eyes_for_write_off(cur):
    build_scenarios(cur)
    run_recon(cur)
    amount_break = scalar(cur, "SELECT break_id FROM recon_break WHERE break_type = 'AMOUNT_MISMATCH'")
    with expect_error(cur, "ROLE_NOT_PERMITTED"):       # ops cannot close a finance-owned break
        cur.execute("SELECT resolve_break(%s, 'MATCHED_LATE', 'rail corrected amount', %s)", (amount_break, OPS1))
    with expect_error(cur, "SOD_VIOLATION"):
        cur.execute("SELECT resolve_break(%s, 'WRITTEN_OFF_APPROVED', 'small difference accepted', %s, %s)",
                    (amount_break, FIN1, FIN1))
    cur.execute("SELECT resolve_break(%s, 'RAIL_CORRECTION_REQUESTED', 'asked rail to correct statement', %s)",
                (amount_break, FIN1))
    assert scalar(cur, "SELECT state FROM recon_break WHERE break_id = %s", (amount_break,)) == "RESOLVED"


def test_missing_ledger_backing_is_detected_as_a_lineage_break(cur):
    ref = make_transfer(cur, 4, 100_000, "POSTED")
    cur.execute("SET LOCAL session_replication_role = replica")     # simulate a manual database change
    cur.execute("UPDATE transfer SET status = 'SETTLED' WHERE transaction_reference = %s", (ref,))
    cur.execute("SET LOCAL session_replication_role = origin")
    run_recon(cur)
    assert breaks_by_type(cur).get("MISSING") == 1


def test_settlement_report_totals_agree_with_transfers(cur):
    build_scenarios(cur)
    run_recon(cur)
    cur.execute("SELECT transfers, reconciled_minor, open_breaks FROM v_settlement_report WHERE business_date = current_date")
    transfers, reconciled, open_breaks = cur.fetchone()
    assert transfers == 9 and reconciled == 100_000
    assert open_breaks == 6          # the unknown statement line has no transfer, so it is not counted per date


# ---------------------------------------------------------------- write-path roles (least privilege)

def as_role(cur, role):
    cur.execute(f"SET LOCAL ROLE {role}")


def reset_role(cur):
    cur.execute("RESET ROLE")


def test_notification_role_cannot_change_transfers_or_read_national_id(cur):
    ref = make_transfer(cur, 4, 100_000, "INITIATED")
    as_role(cur, "fw_notify")
    with expect_error(cur, "permission denied"):
        cur.execute("UPDATE transfer SET status = 'FAILED' WHERE transaction_reference = %s", (ref,))
    with expect_error(cur, "permission denied"):
        cur.execute("SELECT national_id_token FROM customer")
    cur.execute("SELECT customer_ref, mobile_msisdn FROM customer")        # contact details only
    assert cur.rowcount == 6
    cur.execute("SELECT count(*) FROM outbox_event")
    with expect_error(cur, "permission denied"):
        cur.execute("SELECT * FROM journal_entry")
    reset_role(cur)


def test_transaction_service_posts_only_through_the_ledger_function(cur):
    ref = make_transfer(cur, 4, 100_000, "AUTHORISED")
    tid = transfer_id(cur, ref)
    as_role(cur, "fw_txn")
    with expect_error(cur, "permission denied"):
        cur.execute("INSERT INTO journal_entry (transfer_id, journal_type) VALUES (%s, 'TRANSFER_POST')", (tid,))
    with expect_error(cur, "permission denied"):
        cur.execute("UPDATE account_balance_base SET balance_minor = balance_minor + 1")   # Week 14: base + shards
    with expect_error(cur, "permission denied"):
        cur.execute("UPDATE account_balance_shard SET balance_minor = balance_minor + 1")
    cur.execute("SELECT ledger_post(%s, 'TRANSFER_POST')", (tid,))          # the one allowed path
    cur.execute("UPDATE transfer SET status = 'POSTED' WHERE transfer_id = %s", (tid,))
    reset_role(cur)
    assert scalar(cur, "SELECT status::text FROM transfer WHERE transfer_id = %s", (tid,)) == "POSTED"


def test_transaction_service_cannot_read_identity_details(cur):
    as_role(cur, "fw_txn")
    cur.execute("SELECT customer_ref, kyc_tier FROM customer")
    assert cur.rowcount == 6
    for sql in ["SELECT national_id_token FROM customer", "SELECT full_name FROM customer",
                "SELECT mobile_msisdn FROM customer", "SELECT evidence FROM kyc_decision"]:
        with expect_error(cur, "permission denied"):
            cur.execute(sql)
    reset_role(cur)


def test_reconciliation_role_runs_reconciliation_but_cannot_edit_transfers(cur):
    make_transfer(cur, 4, 100_000, "SETTLED")
    as_role(cur, "fw_recon")
    with expect_error(cur, "permission denied"):
        cur.execute("UPDATE transfer SET status = 'REVERSED'")
    cur.execute("SELECT run_reconciliation(current_date, 'recon-service', interval '0 seconds')")
    reset_role(cur)
    assert scalar(cur, "SELECT count(*) FROM recon_run") == 1


def test_reporting_role_sees_views_not_tables(cur):
    make_transfer(cur, 4, 100_000, "SETTLED")
    as_role(cur, "fw_report")
    cur.execute("SELECT transfers FROM v_settlement_report")
    assert cur.fetchone()[0] == 1
    with expect_error(cur, "permission denied"):
        cur.execute("SELECT * FROM transfer")
    with expect_error(cur, "permission denied"):
        cur.execute("SELECT * FROM customer")
    reset_role(cur)


def test_outbox_relay_may_only_mark_events_published(cur):
    make_transfer(cur, 4, 100_000, "INITIATED")
    as_role(cur, "fw_relay")
    cur.execute("UPDATE outbox_event SET published_at = now(), publish_attempts = publish_attempts + 1")
    assert cur.rowcount == 1
    with expect_error(cur, "permission denied"):
        cur.execute("UPDATE outbox_event SET payload = '{}'")
    reset_role(cur)
