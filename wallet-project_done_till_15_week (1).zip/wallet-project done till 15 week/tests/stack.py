"""Test harness for the Week 13 service tests.

Starts the mock rail and the API as real uvicorn processes (so real timeouts, real HTTP and real process
crashes are exercised), and gives tests helpers to reset the database, script the rail, inject faults,
restart the API and query the database directly for assertions.

Environment for the services is set here, before any fastwallet module is imported, so the in-process
worker functions (recovery, relay, reconciliation) and the subprocesses share one configuration.
"""
import json
import os
import pathlib
import signal
import socket
import subprocess
import sys
import time
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "week13"
RUN_DIR = pathlib.Path(os.environ.get("FW_TEST_RUN_DIR", "/tmp/fw_week13_run"))
RUN_DIR.mkdir(parents=True, exist_ok=True)


def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


API_PORT, RAIL_PORT = _free_port(), _free_port()
ENV = {
    "DATABASE_URL": os.environ.get("TEST_DATABASE_URL", ""),
    "FW_JWT_SECRET": os.environ.get("FW_JWT_SECRET", "test-only-secret-not-for-production-0123456789"),
    "FW_RAIL_ACK_SECRET": "test-only-rail-ack-secret-0123456789",
    "FW_RAIL_URL": f"http://127.0.0.1:{RAIL_PORT}",
    "FW_ACK_URL": f"http://127.0.0.1:{API_PORT}/internal/rail/acks",
    "FW_RAIL_TIMEOUT_SECONDS": "1.0",       # 5 s in the design; shortened so the suite runs quickly
    "RAIL_SLOW_SECONDS": "2.5",
    "FW_BACKOFF_SCALE": "0",                # enquiries are due at once in tests
    "FW_STUCK_POSTED_SECONDS": "0",
    "FW_ENABLE_FAULT_INJECTION": "1",
    "RAIL_STATE_FILE": str(RUN_DIR / "rail_state.json"),
    "PYTHONPATH": str(ROOT / "src"),
}
os.environ.update({k: v for k, v in ENV.items() if v})
os.environ.setdefault("FW_LOG_FILE", str(RUN_DIR / "worker.log"))
os.environ.setdefault("FW_SERVICE_NAME", "fw-worker")
sys.path.insert(0, str(ROOT / "src"))

import httpx  # noqa: E402
import psycopg2  # noqa: E402
import psycopg2.extras  # noqa: E402

from fastwallet.security import issue_token  # noqa: E402

SQL_FILES = [
    "src/db/01_tables.sql", "src/db/02_integrity.sql", "src/db/03_reconciliation.sql",
    "src/db/04_reference_data.sql", "src/db/05_roles.sql", "src/db/06_week13.sql", "src/db/07_week14.sql",
    "data/seed_demo.sql", "data/demo_helpers.sql",
]
API_LOG = RUN_DIR / "api.log"


def wallet(n):
    return f"b0000000-0000-0000-0000-{n:012d}"


def body(wallet_n=4, amount=150_000, ident="PK00FAKE0000000000000001", name="Synthetic Beneficiary",
         purpose="FAMILY_SUPPORT"):
    return {"source_wallet_id": wallet(wallet_n), "amount": {"currency": "PKR", "minor_units": amount},
            "beneficiary": {"scheme": "IBAN", "identifier": ident, "name": name}, "purpose": purpose}


def key():
    return "k-" + uuid.uuid4().hex


class Stack:
    def __init__(self):
        self.api_proc = None
        self.rail_proc = None
        self.api = httpx.Client(base_url=f"http://127.0.0.1:{API_PORT}", timeout=15)
        self.rail = httpx.Client(base_url=f"http://127.0.0.1:{RAIL_PORT}", timeout=15)

    # ------------------------------------------------------------ processes
    def _spawn(self, app, port, log, extra_env=None):
        env = {**os.environ, **ENV, **(extra_env or {})}
        return subprocess.Popen([sys.executable, "-m", "uvicorn", app, "--port", str(port), "--log-level", "warning"],
                                env=env, cwd=str(ROOT), stdout=open(RUN_DIR / log, "ab"), stderr=subprocess.STDOUT)

    def _wait(self, client, path, timeout=20):
        end = time.time() + timeout
        while time.time() < end:
            try:
                if client.get(path).status_code == 200:
                    return
            except httpx.TransportError:
                pass
            time.sleep(0.05)
        raise RuntimeError(f"service at {client.base_url} did not become ready")

    def start(self):
        self.rail_proc = self._spawn("fastwallet.rail_mock:app", RAIL_PORT, "rail.out")
        self._wait(self.rail, "/health")
        self.start_api()

    def start_api(self):
        started = time.perf_counter()
        self.api_proc = self._spawn("fastwallet.api:app", API_PORT, "api.out", {"FW_LOG_FILE": str(API_LOG), "FW_SERVICE_NAME": "fw-api"})
        self._wait(self.api, "/health/ready")
        return time.perf_counter() - started

    def kill_api(self):
        """Hard kill (SIGKILL): no shutdown hooks, exactly like a crash."""
        if self.api_proc and self.api_proc.poll() is None:
            self.api_proc.send_signal(signal.SIGKILL)
            self.api_proc.wait(10)

    def restart_api(self):
        self.kill_api()
        return self.start_api()

    def stop(self):
        for p in (self.api_proc, self.rail_proc):
            if p and p.poll() is None:
                p.terminate()
                p.wait(10)

    # ------------------------------------------------------------ state
    def reset(self):
        conn = psycopg2.connect(ENV["DATABASE_URL"])
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute("SET client_min_messages = warning")
        for f in SQL_FILES:
            cur.execute((ROOT / f).read_text())
        conn.close()
        self.rail.post("/_control/reset")
        if self.api_proc is None or self.api_proc.poll() is not None:
            self.start_api()
        self.api.post("/internal/faults", json={"clear": True})

    def q(self, sql, params=None):
        conn = psycopg2.connect(ENV["DATABASE_URL"])
        try:
            cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("SET search_path = fw, public")
            cur.execute(sql, params)
            rows = cur.fetchall() if cur.description else []
            conn.commit()
            return rows
        finally:
            conn.close()

    def scalar(self, sql, params=None):
        rows = self.q(sql, params)
        return list(rows[0].values())[0] if rows else None

    def balance(self, code):
        return self.scalar("SELECT coalesce((SELECT balance_minor FROM account_balance b JOIN ledger_account a "
                           "USING (account_id) WHERE a.code = %s), 0)", (code,))

    def ledger_ok(self):
        h = self.q("SELECT trial_balance_ok, projection_ok, float_invariant_ok FROM v_ops_health")[0]
        return h["trial_balance_ok"] and h["projection_ok"] and h["float_invariant_ok"]

    # ------------------------------------------------------------ actions
    def script_rail(self, modes=(), enquiry_modes=()):
        self.rail.post("/_control/script", json={"modes": list(modes), "enquiry_modes": list(enquiry_modes)})

    def fault(self, *points):
        self.api.post("/internal/faults", json={"enable": list(points)})

    def clear_faults(self):
        self.api.post("/internal/faults", json={"clear": True})

    def transfer(self, token, b, idem=None, corr=None):
        headers = {"Authorization": f"Bearer {token}", "Idempotency-Key": idem or key()}
        if corr:
            headers["X-Correlation-ID"] = corr
        return self.api.post("/v1/transfers", json=b, headers=headers)

    @staticmethod
    def auth(token):
        return {"Authorization": f"Bearer {token}"}


def customer(n, mfa=True):
    return issue_token(f"CUST-{n:04d}", ["customer"], "fw-app", mfa=mfa)


def staff(username, role):
    return issue_token(username, [role], "fw-backoffice", mfa=True)


OPS1, OPS2 = staff("ops.demo1", "ops_analyst"), staff("ops.demo2", "ops_analyst")
FIN1, FIN2 = staff("fin.demo1", "finance_controller"), staff("fin.demo2", "finance_controller")
CO1 = staff("co.demo1", "compliance_officer")
RECOVERY_BOT = staff("recovery.bot", "system_recovery")


def record_evidence(name, data):
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    path = EVIDENCE / "measurements.json"
    current = json.loads(path.read_text()) if path.exists() else {}
    current[name] = data
    path.write_text(json.dumps(current, indent=2, default=str))
