"""Fixtures for the Week 12 data-layer tests and the Week 13 service tests (see stack.py).

The tests need a PostgreSQL 16 server. Point TEST_DATABASE_URL at an empty, disposable database, e.g.
    postgresql://fw:fw@localhost:5432/fw
The schema, reference data and synthetic seed are (re)loaded once per session. Each test runs in a
transaction that is rolled back, so tests do not leak into each other.
"""
import os
import pathlib

import psycopg2
import pytest

import stack as _stack_env  # noqa: F401  sets the service environment before any fastwallet import

ROOT = pathlib.Path(__file__).resolve().parents[1]
SQL_FILES = [
    "src/db/01_tables.sql", "src/db/02_integrity.sql", "src/db/03_reconciliation.sql",
    "src/db/04_reference_data.sql", "src/db/05_roles.sql", "src/db/06_week13.sql", "src/db/07_week14.sql", "data/seed_demo.sql", "data/demo_helpers.sql",
]
DSN = os.environ.get("TEST_DATABASE_URL")


def pytest_collection_modifyitems(config, items):
    if not DSN:
        skip = pytest.mark.skip(reason="set TEST_DATABASE_URL to run the database tests")
        for item in items:
            item.add_marker(skip)


@pytest.fixture(scope="session")
def _loaded():
    conn = psycopg2.connect(DSN)
    conn.autocommit = True
    cur = conn.cursor()
    for f in SQL_FILES:
        cur.execute((ROOT / f).read_text())
    conn.close()


@pytest.fixture
def cur(_loaded):
    conn = psycopg2.connect(DSN)
    conn.autocommit = False
    c = conn.cursor()
    c.execute("SET search_path = fw, public")
    yield c
    conn.rollback()
    conn.close()


# ---------------------------------------------------------------- Week 13 service stack
@pytest.fixture(scope="session")
def _stack_session():
    from stack import Stack
    s = Stack()
    s.start()
    yield s
    s.stop()
    # leave the database freshly loaded, so suites run in any order
    import psycopg2 as _pg
    conn = _pg.connect(DSN)
    conn.autocommit = True
    for f in SQL_FILES:
        conn.cursor().execute((ROOT / f).read_text())
    conn.close()


@pytest.fixture
def stack(_stack_session):
    """A running rail + API with a freshly loaded database and a clean rail for every test."""
    _stack_session.reset()
    yield _stack_session
    _stack_session.clear_faults() if _stack_session.api_proc and _stack_session.api_proc.poll() is None else None
