"""Week 13 security/observability gate: RBAC, audit evidence, structured logs, correlation IDs, metrics,
dashboard, and least privilege of the running services."""
import json
import time

import jwt as pyjwt

from fastwallet.security import issue_token
from stack import API_LOG, CO1, FIN1, OPS1, RECOVERY_BOT, body, customer, key


def denials(stack, action=None):
    if action:
        return stack.scalar("SELECT count(*) FROM audit_log WHERE outcome = 'DENIED' AND action = %s", (action,))
    return stack.scalar("SELECT count(*) FROM audit_log WHERE outcome = 'DENIED'")


# ---------------------------------------------------------------- authentication and role checks

def test_missing_expired_and_forged_tokens_are_rejected_and_logged(stack):
    assert stack.api.post("/v1/transfers", json=body(4), headers={"Idempotency-Key": key()}).status_code == 401
    expired = issue_token("CUST-0004", ["customer"], mfa=True, ttl=-10)
    assert stack.transfer(expired, body(4)).status_code == 401
    forged = pyjwt.encode({"sub": "CUST-0004", "roles": ["customer"], "mfa": True, "iss": "fw-mock-idp",
                           "exp": int(time.time()) + 600}, "attacker-guessed-secret-0123456789abcdef", algorithm="HS256")
    r = stack.transfer(forged, body(4))
    assert r.status_code == 401 and r.json()["code"] == "UNAUTHENTICATED"
    assert stack.scalar("SELECT count(*) FROM transfer") == 0
    assert denials(stack, "TRANSFER_CREATE") == 3


def test_unauthorised_role_attempt_is_denied_and_logged(stack):
    """Required scenario: access is denied and logged."""
    cases = [
        ("GET", "/v1/reconciliation/breaks", customer(4), "BREAK_LIST"),
        ("GET", "/v1/reports/settlement", OPS1, "REPORT_SETTLEMENT"),
        ("GET", "/v1/compliance/cases", OPS1, "CASE_LIST"),
        ("POST", "/v1/reconciliation/runs", CO1, "RECON_RUN"),
        ("GET", "/v1/audit/verify", customer(4), "AUDIT_VERIFY"),
    ]
    for method, path, tok, action in cases:
        r = stack.api.request(method, path, headers=stack.auth(tok), json={} if method == "POST" else None)
        assert r.status_code == 403 and r.json()["code"] == "FORBIDDEN_ROLE", path
        assert denials(stack, action) == 1, action
    # staff cannot create customer transfers, customers cannot run recovery
    assert stack.transfer(OPS1, body(4)).status_code == 403
    assert stack.api.post("/v1/transfers/00000000-0000-0000-0000-000000000000/status-enquiry",
                          headers=stack.auth(customer(4))).status_code == 403
    row = stack.q("SELECT actor, actor_role, details FROM audit_log WHERE action = 'REPORT_SETTLEMENT'")[0]
    assert row["actor"] == "ops.demo1" and row["actor_role"] == "ops_analyst"
    assert row["details"]["code"] == "FORBIDDEN_ROLE"
    assert stack.api.get("/v1/audit/verify", headers=stack.auth(FIN1)).json()["chain_ok"] is True


def test_second_factor_is_required_for_every_transfer(stack):
    r = stack.transfer(customer(4, mfa=False), body(4))
    assert r.status_code == 401 and r.json()["code"] == "STEP_UP_REQUIRED"
    assert stack.scalar("SELECT count(*) FROM transfer") == 0
    assert denials(stack, "TRANSFER_CREATE_NO_SECOND_FACTOR") == 1
    # the client completes the step-up and retries with the same key
    idem = key()
    assert stack.transfer(customer(4, mfa=False), body(4), idem).status_code == 401
    assert stack.transfer(customer(4), body(4), idem).status_code == 202


def test_role_matrix_for_allowed_calls(stack):
    t = stack.transfer(customer(4), body(4, 100_000)).json()
    allowed = [
        ("GET", "/v1/transfers", OPS1), ("GET", f"/v1/transfers/{t['transfer_id']}", FIN1),
        ("GET", "/v1/reconciliation/breaks", FIN1), ("GET", "/v1/reports/settlement", FIN1),
        ("GET", "/v1/compliance/cases", CO1), ("GET", "/v1/ops/exceptions", OPS1),
        ("GET", "/v1/ops/health-summary", FIN1), ("POST", f"/v1/transfers/{t['transfer_id']}/status-enquiry", RECOVERY_BOT),
    ]
    for method, path, tok in allowed:
        r = stack.api.request(method, path, headers=stack.auth(tok))
        assert r.status_code == 200, (path, r.text)


def test_services_run_with_least_privilege_database_roles(stack):
    """The running API switches to fw_txn: it can post through ledger_post() but cannot touch ledger tables."""
    from fastwallet import db
    import psycopg2
    with db.tx("fw_txn", "probe") as cur:
        cur.execute("SELECT current_user AS u")
        assert cur.fetchone()["u"] == "fw_txn"
    for role, sql in [("fw_txn", "INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) "
                                 "VALUES (gen_random_uuid(), 1, gen_random_uuid(), 'DEBIT', 1)"),
                      ("fw_txn", "SELECT national_id_token FROM customer"),
                      ("fw_notify", "UPDATE transfer SET status = 'FAILED'"),
                      ("fw_relay", "UPDATE outbox_event SET payload = '{}'"),
                      ("fw_report", "SELECT * FROM transfer")]:
        try:
            with db.tx(role, "probe") as cur:
                cur.execute(sql)
            raise AssertionError(f"{role} was allowed: {sql}")
        except psycopg2.errors.InsufficientPrivilege:
            pass


# ---------------------------------------------------------------- correlation, logs, metrics, dashboard

def test_correlation_id_flows_from_request_to_events_audit_and_logs(stack):
    corr = "7d2a6a56-2c3d-4f55-9b1a-9a4d1f0e2222"
    r = stack.transfer(customer(4), body(4, 150_000), corr=corr)
    assert r.headers["X-Correlation-ID"] == corr and r.json()["correlation_id"] == corr
    tid = r.json()["transfer_id"]
    assert stack.scalar("SELECT count(DISTINCT correlation_id) FROM outbox_event WHERE aggregate_id = %s", (tid,)) == 1
    assert str(stack.scalar("SELECT correlation_id FROM outbox_event WHERE aggregate_id = %s LIMIT 1", (tid,))) == corr
    assert str(stack.scalar("SELECT correlation_id FROM journal_entry WHERE transfer_id = %s LIMIT 1", (tid,))) == corr
    assert str(stack.scalar("SELECT correlation_id FROM audit_log WHERE action = 'TRANSFER_CREATE'")) == corr
    assert str(stack.scalar("SELECT correlation_id FROM rail_message_log WHERE transfer_id = %s LIMIT 1", (tid,))) == corr
    time.sleep(0.2)
    lines = [json.loads(x) for x in API_LOG.read_text().splitlines() if corr in x]
    assert {"transfer_created", "rail_call", "transfer_state_changed", "http_request"} <= {x["event"] for x in lines}
    # a malformed correlation id is replaced, never trusted
    bad = stack.transfer(customer(4), body(4, 100_000, ident="PK00FAKE0000000000000002"), corr="drop table x")
    assert bad.headers["X-Correlation-ID"] != "drop table x"


def test_logs_are_structured_json_without_personal_data(stack):
    offset = API_LOG.stat().st_size if API_LOG.exists() else 0      # only lines written by this test
    stack.transfer(customer(4), body(4, 150_000, name="Synthetic Beneficiary"))
    stack.transfer(customer(3), body(3, 15_000_000))
    stack.script_rail(["TIMEOUT_EXECUTED"])
    stack.transfer(customer(4), body(4, 100_000, ident="PK00FAKE0000000000000002"))
    time.sleep(0.2)
    with open(API_LOG) as fh:
        fh.seek(offset)
        text = fh.read()
    assert text.strip()
    for line in text.splitlines():
        rec = json.loads(line)                                  # every line parses as JSON
        assert {"ts", "level", "service", "event", "correlation_id"} <= rec.keys()
    for secret in ["PK00FAKE", "Synthetic Beneficiary", "Dania Mock", "Chand Test", "03000000004",
                   "synthetic-national-id"]:
        assert secret not in text, secret


def test_metrics_endpoint_exposes_slis(stack):
    tok = customer(4)
    stack.transfer(tok, body(4, 100_000))
    stack.script_rail(["TIMEOUT_EXECUTED"])
    stack.transfer(tok, body(4, 100_000, ident="PK00FAKE0000000000000002"))
    stack.transfer(OPS1, body(4))                               # one denial
    m = stack.api.get("/metrics").text
    for name in ["fw_http_requests_total", "fw_http_request_seconds_bucket", "fw_transfer_accept_seconds_bucket",
                 'fw_transfers_total{status="SETTLED"}', 'fw_transfers_total{status="PENDING"}',
                 'fw_rail_calls_total{operation="SUBMIT",outcome="UNKNOWN"}', "fw_auth_denials_total",
                 "fw_transfers_pending 1.0", "fw_outbox_unpublished", "fw_ledger_trial_balance_ok 1.0",
                 "fw_ledger_float_invariant_ok 1.0", "fw_database_up 1.0", "fw_settle_p95_seconds"]:
        assert name in m, name


def test_operations_dashboard_renders_for_ops_only(stack):
    stack.transfer(customer(4), body(4, 100_000))
    page = stack.api.get("/ops/dashboard", headers=stack.auth(OPS1))
    assert page.status_code == 200 and "Service level objectives" in page.text and "BREACH" not in page.text
    assert stack.api.get("/ops/dashboard", headers=stack.auth(customer(4))).status_code == 403


def test_health_endpoints(stack):
    assert stack.api.get("/health/live").json() == {"status": "ok"}
    assert stack.api.get("/health/ready").json()["database"] is True


def test_fault_injection_is_off_unless_explicitly_enabled():
    import os
    import subprocess
    import sys
    env = {k: v for k, v in os.environ.items() if k != "FW_ENABLE_FAULT_INJECTION"}
    out = subprocess.run([sys.executable, "-c", "from fastwallet.config import settings; print(settings.fault_injection)"],
                         env=env, capture_output=True, text=True)
    assert out.stdout.strip() == "False"
