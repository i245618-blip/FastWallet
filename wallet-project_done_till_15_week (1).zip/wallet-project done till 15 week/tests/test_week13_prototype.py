"""Week 13 prototype gate: the normal path works locally and is covered by automated tests.

Normal success scenario (guidelines section 5): end-to-end trace from initiation through posting,
settlement, notification and reconciliation, all through the running services.
"""
import datetime as dt

from fastwallet import events
from stack import CO1, FIN1, OPS1, body, customer, key, record_evidence


def test_normal_path_end_to_end(stack):
    tok = customer(4)
    w0, f0 = stack.balance("W-CUST-0004"), stack.balance("1100")

    r = stack.transfer(tok, body(4, 150_000))
    assert r.status_code == 202, r.text
    t = r.json()
    assert t["status"] == "SETTLED" and t["rail_reference"].startswith("RAIL-SYN-")
    assert r.headers["X-Correlation-ID"] == t["correlation_id"]

    # ledger: wallet debited once, float reduced by the same amount, in-transit cleared, books balance
    assert stack.balance("W-CUST-0004") == w0 - 150_000
    assert stack.balance("1100") == f0 - 150_000
    assert stack.balance("2200") == 0
    assert stack.ledger_ok()

    # authoritative status for the app
    g = stack.api.get(f"/v1/transfers/{t['transfer_id']}", headers=stack.auth(tok))
    assert g.status_code == 200 and g.json()["status"] == "SETTLED"

    # notification consumes the events and never creates financial truth
    assert events.relay_once() >= 4
    sent = stack.q("SELECT status, outcome, masked_msisdn, message FROM notification_log "
                   "WHERE transfer_id = %s ORDER BY sequence", (t["transfer_id"],))
    assert [n["status"] for n in sent] == ["INITIATED", "AUTHORISED", "POSTED", "SETTLED"]
    assert sent[-1]["outcome"] == "SENT" and sent[-1]["masked_msisdn"].endswith("004")
    assert "PK00FAKE" not in (sent[-1]["message"] or "")          # no beneficiary account in messages

    # reconciliation against the rail statement
    run = stack.api.post("/v1/reconciliation/runs", json={"statement_date": dt.date.today().isoformat()},
                         headers=stack.auth(OPS1)).json()
    assert run["matched"] == 1 and run["new_breaks"] == 0
    assert stack.scalar("SELECT status::text FROM transfer WHERE transfer_id = %s", (t["transfer_id"],)) == "RECONCILED"

    lineage = stack.q("SELECT journals, state_changes, events FROM v_transfer_lineage WHERE transaction_reference = %s",
                      (t["transaction_reference"],))[0]
    assert lineage["journals"] == "TRANSFER_POST, TRANSFER_SETTLE"
    assert lineage["state_changes"] == 5 and lineage["events"] == 5      # ... SETTLED, RECONCILED

    report = stack.api.get("/v1/reports/settlement", headers=stack.auth(FIN1)).json()["items"][0]
    assert report["reconciled_minor"] == 150_000 and report["open_breaks"] == 0
    record_evidence("normal_path", {"reference": t["transaction_reference"], "status_after_recon": "RECONCILED",
                                    "journals": lineage["journals"], "events": lineage["events"]})


def test_screening_decision_is_recorded_with_its_inputs(stack):
    t = stack.transfer(customer(4), body(4, 150_000)).json()
    d = stack.q("SELECT outcome, risk_score, rules_version, inputs FROM screening_decision WHERE transfer_id = %s",
                (t["transfer_id"],))[0]
    assert d["outcome"] == "ALLOW" and d["rules_version"] == "rules-v1"
    assert d["inputs"]["tier"] == 2 and d["inputs"]["second_factor"] is True
    assert d["inputs"]["amount_minor"] == 150_000


def test_customer_sees_only_their_own_transfers(stack):
    t = stack.transfer(customer(4), body(4, 100_000)).json()
    other = stack.api.get(f"/v1/transfers/{t['transfer_id']}", headers=stack.auth(customer(3)))
    assert other.status_code == 404                             # not 403: existence is not revealed
    mine = stack.api.get("/v1/transfers", headers=stack.auth(customer(4))).json()["items"]
    assert [x["transfer_id"] for x in mine] == [t["transfer_id"]]
    assert stack.api.get("/v1/transfers", headers=stack.auth(customer(3))).json()["items"] == []


def test_customer_cannot_send_from_someone_elses_wallet(stack):
    r = stack.transfer(customer(3), body(4, 100_000))
    assert r.status_code == 404 and r.json()["code"] == "NOT_FOUND"
    assert stack.scalar("SELECT count(*) FROM transfer") == 0


def test_contract_violation_is_rejected_and_nothing_is_persisted(stack):
    bad = body(4, 150_000)
    bad["amount"]["currency"] = "USD"
    r = stack.transfer(customer(4), bad)
    assert r.status_code == 400 and r.json()["code"] == "VALIDATION_ERROR"
    assert r.headers["content-type"].startswith("application/problem+json")
    missing_key = stack.api.post("/v1/transfers", json=body(4), headers=stack.auth(customer(4)))
    assert missing_key.status_code == 400
    assert stack.scalar("SELECT count(*) FROM transfer") == 0
    assert stack.scalar("SELECT count(*) FROM idempotency_record") == 0


def test_limit_and_tier_rules_block_with_evidence(stack):
    # Tier 1 customer 1: Rs 30,000 is above the Rs 25,000 per-transfer limit (R02)
    r = stack.transfer(customer(1), body(1, 3_000_000))
    assert r.status_code == 422 and r.json()["code"] == "LIMIT_EXCEEDED" and r.json()["reason_codes"] == ["R02"]
    # Tier 0 customer 5 cannot send to a bank account at all (R01)
    r0 = stack.transfer(customer(5), body(5, 10_000))
    assert r0.status_code == 422 and r0.json()["reason_codes"][0] == "R01"
    rows = stack.q("SELECT t.status::text, t.status_reason, d.outcome FROM transfer t "
                   "JOIN screening_decision d USING (transfer_id) ORDER BY t.created_at")
    assert [(x["status"], x["outcome"]) for x in rows] == [("FAILED", "BLOCK"), ("FAILED", "BLOCK")]
    assert stack.scalar("SELECT count(*) FROM journal_entry WHERE transfer_id IS NOT NULL") == 0


def test_insufficient_funds_fails_without_posting(stack):
    # customer 2 (Tier 1) holds Rs 10,000; Rs 15,000 passes the limits but cannot be covered
    r = stack.transfer(customer(2), body(2, 1_500_000))
    assert r.status_code == 422 and r.json()["code"] == "INSUFFICIENT_FUNDS"
    tid = r.json()["transfer_id"]
    assert stack.scalar("SELECT status::text FROM transfer WHERE transfer_id = %s", (tid,)) == "FAILED"
    assert stack.scalar("SELECT count(*) FROM journal_entry WHERE transfer_id = %s", (tid,)) == 0
    assert stack.balance("W-CUST-0002") == 1_000_000


def test_compliance_hold_then_officer_release(stack):
    # Rs 150,000 from Tier 2 customer 3: material amount (R10) and new beneficiary above Rs 50,000 (R06)
    r = stack.transfer(customer(3), body(3, 15_000_000))
    assert r.status_code == 202 and r.json()["status"] == "HELD"
    tid = r.json()["transfer_id"]
    assert stack.balance("W-CUST-0003") == 15_000_000                 # nothing moved while held

    cases = stack.api.get("/v1/compliance/cases", headers=stack.auth(CO1)).json()["items"]
    assert len(cases) == 1 and set(cases[0]["reason_codes"]) == {"R06", "R10"}
    case_id = cases[0]["case_id"]

    # an analyst is not an officer: denied by the API and audited
    denied = stack.api.post(f"/v1/compliance/cases/{case_id}/decision", headers={**stack.auth(OPS1), "Idempotency-Key": key()},
                            json={"decision": "RELEASE", "rationale": "looks fine to me honestly"})
    assert denied.status_code == 403
    ok = stack.api.post(f"/v1/compliance/cases/{case_id}/decision", headers={**stack.auth(CO1), "Idempotency-Key": key()},
                        json={"decision": "RELEASE", "rationale": "salary transfer, employer letter on file"})
    assert ok.status_code == 200 and ok.json()["transfer"]["status"] == "SETTLED"
    assert stack.balance("W-CUST-0003") == 0
    # the screening evidence is still exactly what the rules saw
    assert stack.scalar("SELECT outcome FROM screening_decision WHERE transfer_id = %s", (tid,)) == "HOLD"
    assert stack.scalar("SELECT decision FROM case_decision") == "RELEASE"
    hist = stack.q("SELECT to_status::text FROM transfer_state_history WHERE transfer_id = %s ORDER BY sequence", (tid,))
    assert [h["to_status"] for h in hist] == ["INITIATED", "HELD", "AUTHORISED", "POSTED", "SETTLED"]


def test_velocity_watchlist_and_new_wallet_rules_hold(stack):
    # R07: beneficiary name close to a synthetic watchlist entry
    w = stack.transfer(customer(4), body(4, 50_000, ident="PK00FAKE0000000000000077", name="Sampel Blocked Person"))
    assert w.json()["status"] == "HELD"
    # R08: wallet 6 was opened today; Rs 30,000 is above the new-wallet threshold
    n = stack.transfer(customer(6), body(6, 3_000_000, ident="PK00FAKE0000000000000066"))
    assert n.json()["status"] == "HELD"
    # R05: more than 5 transfers in 10 minutes from one wallet
    statuses = [stack.transfer(customer(1), body(1, 10_000)).json()["status"] for _ in range(6)]
    assert statuses[:5] == ["SETTLED"] * 5 and statuses[5] == "HELD"
    codes = {r["reason"] for r in stack.q("SELECT unnest(reason_codes) AS reason FROM screening_decision "
                                          "WHERE outcome = 'HOLD'")}
    assert {"R05", "R07", "R08"} <= codes


def test_reversal_needs_maker_checker_and_rail_confirmed_return(stack):
    tok = customer(4)
    w0 = stack.balance("W-CUST-0004")
    t = stack.transfer(tok, body(4, 200_000)).json()
    assert t["status"] == "SETTLED"
    req = stack.api.post(f"/v1/transfers/{t['transfer_id']}/reversals",
                         headers={**stack.auth(OPS1), "Idempotency-Key": key()},
                         json={"reason_code": "RAIL_RETURN", "reason_text": "beneficiary bank returned the funds"})
    assert req.status_code == 201
    rid = req.json()["reversal_id"]
    # the maker cannot approve, and an analyst is not a checker
    same = stack.api.post(f"/v1/reversals/{rid}/approval", headers={**stack.auth(OPS1), "Idempotency-Key": key()},
                          json={"decision": "APPROVE", "comment": "approving my own request"})
    assert same.status_code == 403
    stack.rail.post(f"/_control/return/{t['transaction_reference']}")       # rail confirms the return
    ok = stack.api.post(f"/v1/reversals/{rid}/approval", headers={**stack.auth(FIN1), "Idempotency-Key": key()},
                        json={"decision": "APPROVE", "comment": "return confirmed on rail enquiry"})
    assert ok.status_code == 200 and ok.json()["state"] == "POSTED"
    assert ok.json()["transfer"]["status"] == "REVERSED"
    assert stack.balance("W-CUST-0004") == w0 and stack.ledger_ok()
    link = stack.scalar("SELECT reverses_journal_id IS NOT NULL FROM journal_entry WHERE transfer_id = %s "
                        "AND journal_type = 'TRANSFER_RETURN'", (t["transfer_id"],))
    assert link is True
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action IN ('REVERSAL_REQUEST','REVERSAL_DECISION') "
                        "AND outcome = 'ALLOWED'") == 2
