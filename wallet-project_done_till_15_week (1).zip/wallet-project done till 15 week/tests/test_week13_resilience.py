"""Week 13 failure/resilience gate: timeout, duplicate and partial-failure behaviour, restart and recovery.

Maps to the required scenarios in guidelines section 5 and the test names planned in the Week 10
submission (section 8.5).
"""
import concurrent.futures as cf
import datetime as dt
import hashlib
import hmac
import json
import os
import subprocess
import time

import httpx
import pytest

from fastwallet import events, transfers
from stack import ENV, FIN1, OPS1, body, customer, key, record_evidence

TODAY = dt.date.today().isoformat()


def status_of(stack, tid):
    return stack.scalar("SELECT status::text FROM transfer WHERE transfer_id = %s", (tid,))


def submits(stack, ref):
    return stack.rail.get("/_control/stats").json()["submit_counts"].get(ref, 0)


# ---------------------------------------------------------------- client retry after timeout

def test_same_key_returns_prior_status_no_double_debit(stack):
    tok, idem, b = customer(4), key(), body(4, 150_000)
    w0 = stack.balance("W-CUST-0004")
    stack.script_rail(["TIMEOUT_EXECUTED"])                     # rail pays, but answers too late
    first = stack.transfer(tok, b, idem)
    assert first.status_code == 202 and first.json()["status"] == "PENDING"
    assert first.json()["status_reason"] == "RAIL_TIMEOUT"

    retry = stack.transfer(tok, b, idem)                        # client did not see the answer and retries
    assert retry.status_code == 202 and retry.headers["Idempotent-Replayed"] == "true"
    assert retry.json()["transfer_id"] == first.json()["transfer_id"]
    assert stack.scalar("SELECT count(*) FROM transfer") == 1
    assert stack.balance("W-CUST-0004") == w0 - 150_000         # debited exactly once
    assert submits(stack, first.json()["transaction_reference"]) == 1


def test_same_key_different_body_returns_422(stack):
    tok, idem = customer(4), key()
    assert stack.transfer(tok, body(4, 150_000), idem).status_code == 202
    other = stack.transfer(tok, body(4, 999_00), idem)
    assert other.status_code == 422 and other.json()["code"] == "IDEMPOTENCY_KEY_REUSED"
    assert stack.scalar("SELECT count(*) FROM transfer") == 1
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action = 'TRANSFER_CREATE_KEY_REUSED' "
                        "AND outcome = 'DENIED'") == 1


def test_concurrent_requests_with_one_key_create_one_transfer(stack):
    tok, idem, b = customer(4), key(), body(4, 120_000)
    with cf.ThreadPoolExecutor(10) as pool:
        results = list(pool.map(lambda _: stack.transfer(tok, b, idem), range(10)))
    assert {r.status_code for r in results} <= {202, 409}
    assert len({r.json().get("transfer_id") for r in results if r.status_code == 202}) == 1
    assert stack.scalar("SELECT count(*) FROM transfer") == 1
    assert stack.scalar("SELECT count(*) FROM journal_entry WHERE journal_type = 'TRANSFER_POST'") == 1
    record_evidence("concurrent_same_key", {"requests": 10, "codes": sorted(r.status_code for r in results),
                                            "transfers_created": 1})


# ---------------------------------------------------------------- downstream timeout

def test_rail_timeout_sets_pending_and_enquires_not_replays(stack):
    stack.script_rail(["TIMEOUT_EXECUTED"])
    t = stack.transfer(customer(4), body(4, 110_000)).json()
    assert t["status"] == "PENDING"
    assert stack.balance("2200") == 110_000                     # money is parked in transit, not lost

    assert transfers.recover_transfer(t["transfer_id"]) == "SETTLED"
    assert submits(stack, t["transaction_reference"]) == 1      # enquiry, not a second submission
    ops = [r["operation"] + ":" + r["outcome"] for r in
           stack.q("SELECT operation, outcome FROM rail_message_log WHERE transfer_id = %s ORDER BY msg_id",
                   (t["transfer_id"],))]
    assert ops == ["SUBMIT:SENT", "ACK:UNKNOWN", "ENQUIRY:SENT", "ENQUIRY_RESULT:EXECUTED"]
    assert stack.scalar("SELECT status_reason FROM transfer WHERE transfer_id = %s", (t["transfer_id"],)) \
        == "RECOVERED_BY_ENQUIRY"
    assert stack.balance("2200") == 0 and stack.ledger_ok()


def test_lost_request_is_resubmitted_only_after_rail_says_not_found(stack):
    stack.script_rail(["TIMEOUT_NOT_EXECUTED"])                 # the rail never got it
    t = stack.transfer(customer(4), body(4, 130_000)).json()
    assert t["status"] == "PENDING"
    assert stack.rail.get("/_control/stats").json()["payments"] == 0
    assert transfers.recover_transfer(t["transfer_id"]) == "SETTLED"
    stats = stack.rail.get("/_control/stats").json()
    assert stats["submit_counts"][t["transaction_reference"]] == 2 and stats["executed"] == 1
    assert stack.scalar("SELECT count(*) FROM rail_message_log WHERE transfer_id = %s AND outcome = "
                        "'RESUBMIT_AFTER_NOT_FOUND'", (t["transfer_id"],)) == 1


def test_rail_unavailable_before_executing_is_recovered(stack):
    stack.script_rail(["UNAVAILABLE"])
    t = stack.transfer(customer(4), body(4, 50_000)).json()
    assert t["status"] == "PENDING" and t["status_reason"] == "RAIL_HTTP_503"
    assert transfers.recover_transfer(t["transfer_id"]) == "SETTLED"


def test_recovery_backs_off_then_hands_over_to_a_person(stack):
    stack.script_rail(["TIMEOUT_EXECUTED"], ["ENQ_TIMEOUT"] * 5)
    t = stack.transfer(customer(4), body(4, 140_000)).json()
    results = [transfers.recover_transfer(t["transfer_id"]) for _ in range(6)]
    assert results[:5] == ["PENDING"] * 5 and results[5] == "EXHAUSTED"
    exc = stack.q("SELECT kind, owner_role, state FROM ops_exception WHERE transfer_id = %s", (t["transfer_id"],))
    assert exc == [{"kind": "RECOVERY_EXHAUSTED", "owner_role": "ops_analyst", "state": "OPEN"}]
    assert status_of(stack, t["transfer_id"]) == "PENDING" and stack.balance("2200") == 140_000
    # an analyst can still force one more enquiry once the rail answers again
    forced = stack.api.post(f"/v1/transfers/{t['transfer_id']}/status-enquiry", headers=stack.auth(OPS1))
    assert forced.status_code == 200 and forced.json()["transfer"]["status"] == "SETTLED"


def test_backoff_schedule_is_respected():
    from fastwallet.config import settings
    assert settings.backoff_schedule == (5, 15, 45, 120, 300)


# ---------------------------------------------------------------- rejection and compensation

def test_rail_rejection_compensates_the_wallet(stack):
    w0 = stack.balance("W-CUST-0004")
    stack.script_rail(["REJECT"])
    t = stack.transfer(customer(4), body(4, 160_000)).json()
    assert t["status"] == "REVERSED" and t["status_reason"] == "RAIL_REJECTED"
    assert stack.balance("W-CUST-0004") == w0 and stack.balance("2200") == 0
    assert stack.scalar("SELECT reverses_journal_id IS NOT NULL FROM journal_entry WHERE transfer_id = %s "
                        "AND journal_type = 'TRANSFER_REVERSE'", (t["transfer_id"],)) is True


# ---------------------------------------------------------------- duplicates at every layer

def _signed_ack(stack, payload, secret=None):
    raw = json.dumps(payload).encode()
    sig = hmac.new((secret or ENV["FW_RAIL_ACK_SECRET"]).encode(), raw, hashlib.sha256).hexdigest()
    return stack.api.post("/internal/rail/acks", content=raw,
                          headers={"X-Rail-Signature": sig, "Content-Type": "application/json"})


def test_duplicate_rail_acknowledgements_are_ignored(stack):
    stack.script_rail(["DUPLICATE_ACK"])                        # rail answers, then sends the ack twice
    t = stack.transfer(customer(4), body(4, 170_000)).json()
    assert t["status"] == "SETTLED"
    deadline = time.time() + 5
    while time.time() < deadline and stack.scalar(
            "SELECT count(*) FROM rail_message_log WHERE transfer_id = %s AND operation = 'ACK'", (t["transfer_id"],)) < 3:
        time.sleep(0.1)
    assert stack.scalar("SELECT count(*) FROM rail_message_log WHERE transfer_id = %s AND operation = 'ACK'",
                        (t["transfer_id"],)) == 3       # inline answer + two callbacks, all kept as evidence
    assert stack.scalar("SELECT count(*) FROM journal_entry WHERE transfer_id = %s AND journal_type = 'TRANSFER_SETTLE'",
                        (t["transfer_id"],)) == 1
    # a forged acknowledgement is refused and audited
    forged = _signed_ack(stack, {"request_id": t["transaction_reference"], "status": "REJECTED"}, secret="wrong-secret")
    assert forged.status_code == 401
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action = 'RAIL_ACK_BAD_SIGNATURE'") == 1
    assert status_of(stack, t["transfer_id"]) == "SETTLED"


def test_duplicate_submission_to_the_rail_pays_once(stack):
    t = stack.transfer(customer(4), body(4, 50_000)).json()
    again = httpx.post(ENV["FW_RAIL_URL"] + "/rail/v1/payments", json={
        "request_id": t["transaction_reference"], "amount_minor": 50_000,
        "beneficiary_scheme": "IBAN", "beneficiary_identifier": "PK00FAKE0000000000000001"}).json()
    assert again["duplicate"] is True and again["rail_reference"] == t["rail_reference"]
    assert stack.rail.get("/_control/stats").json()["executed"] == 1


def test_consumer_ignores_duplicate_event_id(stack):
    t = stack.transfer(customer(4), body(4, 60_000)).json()
    evs = [r["payload"] for r in stack.q("SELECT payload FROM outbox_event WHERE aggregate_id = %s ORDER BY sequence",
                                          (t["transfer_id"],))]
    assert [events.notify(e) for e in evs] == ["NOT_NOTIFIABLE", "NOT_NOTIFIABLE", "SENT", "SENT"]
    # relay crashed after delivering and before marking published: everything is delivered again
    assert [events.notify(e) for e in evs] == ["DUPLICATE"] * 4
    assert stack.scalar("SELECT count(*) FROM notification_log WHERE transfer_id = %s", (t["transfer_id"],)) == 4
    # the relay itself still delivers each event once and marks it
    assert events.relay_once() == len(evs)
    assert stack.scalar("SELECT count(*) FROM notification_log WHERE transfer_id = %s", (t["transfer_id"],)) == 4
    assert stack.scalar("SELECT count(*) FROM outbox_event WHERE published_at IS NULL") == 0


def test_out_of_order_event_is_not_applied(stack):
    t = stack.transfer(customer(4), body(4, 60_000)).json()
    evs = [r["payload"] for r in stack.q("SELECT payload FROM outbox_event WHERE aggregate_id = %s ORDER BY sequence",
                                          (t["transfer_id"],))]
    assert events.notify(evs[3]) == "SENT"                       # SETTLED arrives first
    assert events.notify(evs[2]) == "SKIPPED_STALE"              # the older POSTED event must not overwrite it


def test_poison_event_goes_to_dead_letter(stack):
    assert events.notify({"event_id": "not-a-uuid", "event_type": "transfer.status.changed"}) == "DEAD_LETTER"
    dlq = stack.q("SELECT consumer_name, state, error FROM dead_letter_event")
    assert len(dlq) == 1 and dlq[0]["state"] == "OPEN" and dlq[0]["error"].startswith("SCHEMA_INVALID")


def test_notification_respects_withdrawn_consent(stack):
    t = stack.transfer(customer(2), body(2, 50_000)).json()      # customer 2 withdrew SERVICE_NOTIFICATIONS
    events.relay_once()
    outcomes = {r["outcome"] for r in stack.q("SELECT outcome FROM notification_log WHERE transfer_id = %s",
                                              (t["transfer_id"],))}
    assert "SENT" not in outcomes and "SUPPRESSED_NO_CONSENT" in outcomes
    assert stack.api.get(f"/v1/transfers/{t['transfer_id']}", headers=stack.auth(customer(2))).json()["status"] == "SETTLED"


# ---------------------------------------------------------------- partial failure

def test_rail_executed_ledger_missing_is_reconciled_and_recovered(stack):
    """One side posts while the other fails: the rail pays, our settlement posting fails."""
    tok = customer(4)
    stack.fault("fail_settle")
    t = stack.transfer(tok, body(4, 180_000)).json()
    assert t["status"] == "POSTED"                              # last committed truth, nothing invented
    evidence = stack.q("SELECT operation, outcome FROM rail_message_log WHERE transfer_id = %s ORDER BY msg_id",
                       (t["transfer_id"],))
    assert evidence[-1] == {"operation": "ACK", "outcome": "EXECUTED"}      # the rail's answer was kept
    assert stack.q("SELECT kind, owner_role FROM ops_exception") == [{"kind": "POSTING_FAILED",
                                                                     "owner_role": "finance_controller"}]
    stack.clear_faults()

    # end of day: reconciliation sees that the rail executed but our books say POSTED
    run1 = stack.api.post("/v1/reconciliation/runs", json={"statement_date": TODAY}, headers=stack.auth(OPS1)).json()
    brk = stack.q("SELECT break_id, break_type::text, owner_role FROM recon_break WHERE transfer_id = %s",
                  (t["transfer_id"],))
    assert run1["new_breaks"] == 1 and brk[0]["break_type"] == "STATUS_MISMATCH" and brk[0]["owner_role"] == "ops_analyst"

    # recovery: status enquiry confirms execution and posts the missing settlement (a new linked journal)
    assert transfers.recover_transfer(t["transfer_id"]) == "SETTLED"
    assert stack.scalar("SELECT state FROM ops_exception") == "RESOLVED"
    res = stack.api.post(f"/v1/reconciliation/breaks/{brk[0]['break_id']}/resolution",
                         headers={**stack.auth(OPS1), "Idempotency-Key": key()},
                         json={"resolution_code": "MATCHED_LATE", "comment": "settlement posted after status enquiry"})
    assert res.status_code == 200 and res.json()["state"] == "RESOLVED"

    run2 = stack.api.post("/v1/reconciliation/runs", json={"statement_date": TODAY}, headers=stack.auth(OPS1)).json()
    assert run2["new_breaks"] == 0 and run2["matched"] == 1
    assert status_of(stack, t["transfer_id"]) == "RECONCILED"
    assert stack.ledger_ok() and stack.balance("2200") == 0
    record_evidence("partial_failure", {"first_run": run1, "second_run": run2, "final_status": "RECONCILED"})


# ---------------------------------------------------------------- restart and recovery

def test_crash_between_posting_and_rail_submit_then_restart(stack):
    tok, idem, b = customer(4), key(), body(4, 190_000)
    w0 = stack.balance("W-CUST-0004")
    stack.fault("crash_after_post")
    with pytest.raises(httpx.TransportError):
        stack.transfer(tok, b, idem)                            # process dies mid-request
    assert stack.api_proc.poll() is not None
    restart_seconds = stack.start_api()

    t = stack.q("SELECT transfer_id, transaction_reference, status::text FROM transfer")[0]
    assert t["status"] == "POSTED" and stack.balance("W-CUST-0004") == w0 - 190_000
    retry = stack.transfer(tok, b, idem)                        # client retries after the outage
    assert retry.headers.get("Idempotent-Replayed") == "true" and retry.json()["status"] == "POSTED"
    assert stack.scalar("SELECT count(*) FROM transfer") == 1

    assert transfers.recover_transfer(t["transfer_id"]) == "SETTLED"    # rail says NOT_FOUND, safe resubmit
    assert submits(stack, t["transaction_reference"]) == 1
    assert stack.balance("W-CUST-0004") == w0 - 190_000 and stack.ledger_ok()
    record_evidence("crash_after_post", {"api_restart_seconds": round(restart_seconds, 2),
                                         "status_after_restart": "POSTED", "status_after_recovery": "SETTLED"})


def test_state_survives_restart(stack):
    tok = customer(4)
    stack.script_rail(["SUCCESS", "TIMEOUT_EXECUTED", "REJECT"])
    ids = [stack.transfer(tok, body(4, a)).json()["transfer_id"] for a in (100_000, 110_000, 120_000)]
    held = stack.transfer(customer(3), body(3, 15_000_000)).json()["transfer_id"]
    before = stack.q("SELECT transfer_id, status::text, version FROM transfer ORDER BY created_at")
    bal_before = stack.q("SELECT account_id, balance_minor FROM account_balance ORDER BY account_id")
    audit_before = stack.scalar("SELECT count(*) FROM audit_log")

    seconds = stack.restart_api()                               # SIGKILL, then start again

    assert stack.q("SELECT transfer_id, status::text, version FROM transfer ORDER BY created_at") == before
    assert stack.q("SELECT account_id, balance_minor FROM account_balance ORDER BY account_id") == bal_before
    assert stack.scalar("SELECT count(*) FROM audit_log") == audit_before
    assert stack.api.get("/v1/audit/verify", headers=stack.auth(FIN1)).json()["chain_ok"] is True
    statuses = [stack.api.get(f"/v1/transfers/{i}", headers=stack.auth(tok)).json()["status"] for i in ids]
    assert statuses == ["SETTLED", "PENDING", "REVERSED"]
    assert stack.api.get(f"/v1/transfers/{held}", headers=stack.auth(customer(3))).json()["status"] == "HELD"
    assert transfers.recover_all()[ids[1]] == "SETTLED"          # unknown outcome resolved after restart
    record_evidence("restart", {"api_restart_seconds": round(seconds, 2), "transfers_checked": len(before)})


@pytest.mark.skipif(not os.environ.get("FW_TEST_PG_RESTART_CMD"),
                    reason="set FW_TEST_PG_RESTART_CMD (e.g. 'pg_ctlcluster 16 main restart') to run")
def test_database_restart_is_survived(stack):
    tok = customer(4)
    t = stack.transfer(tok, body(4, 100_000)).json()
    started = time.perf_counter()
    subprocess.run(os.environ["FW_TEST_PG_RESTART_CMD"], shell=True, check=True)
    deadline = time.time() + 60
    while time.time() < deadline and stack.api.get("/health/ready").status_code != 200:
        time.sleep(0.2)
    recovered = time.perf_counter() - started
    assert stack.api.get("/health/ready").status_code == 200
    assert stack.api.get(f"/v1/transfers/{t['transfer_id']}", headers=stack.auth(tok)).json()["status"] == "SETTLED"
    assert stack.transfer(tok, body(4, 100_000, ident="PK00FAKE0000000000000002")).json()["status"] == "SETTLED"
    assert stack.ledger_ok()
    record_evidence("database_restart", {"seconds_until_api_ready": round(recovered, 2)})
