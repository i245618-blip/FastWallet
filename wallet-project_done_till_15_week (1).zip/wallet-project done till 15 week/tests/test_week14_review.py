"""Week 14 architecture-review gate: the items carried from Week 13 and the bounded AI extension.

  * connection pool and sharded system balances (ADR-008)
  * rate limiting (ADR-009)
  * late rail return after reconciliation, write-off posting, exception-queue resolution (ADR-010)
  * dead-letter replay and discard
  * exception-triage assistant: advisory only, abstains, human review, kill switch, least privilege (ADR-007)
"""
import datetime as dt
import json
import pathlib
import subprocess
import sys

import psycopg2
import pytest

from fastwallet import db, events, triage
from stack import CO1, ENV, FIN1, FIN2, OPS1, ROOT, body, customer, key, record_evidence

TODAY = dt.date.today().isoformat()
TOMORROW = (dt.date.today() + dt.timedelta(days=1)).isoformat()


def recon(stack, date=TODAY, who=OPS1):
    r = stack.api.post("/v1/reconciliation/runs", json={"statement_date": date}, headers=stack.auth(who))
    assert r.status_code == 200, r.text
    return r.json()


def hdr(stack, tok):
    return {**stack.auth(tok), "Idempotency-Key": key()}


# ---------------------------------------------------------------- ADR-008: pool and sharded balances

def test_pooled_connections_do_not_carry_role_or_actor_between_units_of_work():
    with db.tx("fw_ai", "first-actor") as cur:
        cur.execute("SELECT current_user AS u, current_setting('fw.actor') AS a")
        assert cur.fetchone() == {"u": "fw_ai", "a": "first-actor"}
    for _ in range(3):                                   # the same pooled connection is reused
        with db.tx("fw_report", "second") as cur:
            cur.execute("SELECT current_user AS u, current_setting('fw.actor') AS a")
            assert cur.fetchone() == {"u": "fw_report", "a": "second"}


def test_system_accounts_use_sharded_balances_and_controls_hold(stack):
    tok = customer(4)
    for i in range(5):                                   # R05 velocity holds the sixth
        assert stack.transfer(tok, body(4, 10_000 + i, ident=f"PK00FAKE{i:016d}")).json()["status"] == "SETTLED"
    shards = stack.scalar("""SELECT count(*) FROM account_balance_shard s JOIN ledger_account a USING (account_id)
                              WHERE a.code = '2200'""")
    assert shards > 1                                                    # postings spread over several rows
    assert stack.balance("2200") == 0                                    # the combined balance is still exact
    h = stack.q("SELECT system_accounts_ok, trial_balance_ok, projection_ok, float_invariant_ok FROM v_ops_health")[0]
    assert all(h.values())


# ---------------------------------------------------------------- ADR-009: rate limiting

def test_rate_limit_returns_429_with_retry_after_and_audits_once(stack):
    stack.q("UPDATE rate_limit_policy SET max_requests = 3 WHERE scope = 'transfer_create'")
    tok = customer(3)
    codes = [stack.transfer(tok, body(3, 1_000 + i, ident=f"PK00FAKE{i:016d}")).status_code for i in range(6)]
    assert codes[:3] == [202, 202, 202] and codes[3:] == [429, 429, 429]
    r = stack.transfer(tok, body(3, 9_999))
    assert r.status_code == 429 and r.json()["code"] == "RATE_LIMITED" and int(r.headers["Retry-After"]) >= 1
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action = 'RATE_LIMITED' AND outcome = 'DENIED'") == 1
    assert stack.scalar("SELECT count(*) FROM transfer t JOIN wallet w ON w.wallet_id = t.source_wallet_id "
                        "WHERE w.customer_id = 'c0000000-0000-0000-0000-000000000003'") == 3
    assert stack.transfer(customer(4), body(4, 1_000)).status_code == 202      # other customers unaffected
    assert stack.q("SELECT rate_limited_last_hour FROM v_ops_health")[0]["rate_limited_last_hour"] == 4


# ---------------------------------------------------------------- ADR-010: late return, write-off, exception queue

def test_late_return_after_reconciliation_credits_customer_and_tells_finance(stack):
    tok = customer(4)
    t = stack.transfer(tok, body(4, 210_000)).json()
    assert recon(stack)["matched"] == 1
    assert stack.scalar("SELECT status::text FROM transfer WHERE transfer_id = %s", (t["transfer_id"],)) == "RECONCILED"
    w0 = stack.balance("W-CUST-0004")

    # next day the beneficiary bank returns the money; the rail sends its signed RETURNED acknowledgement
    stack.rail.post(f"/_control/return/{t['transaction_reference']}", params={"ack": "true", "return_date": TOMORROW})
    snap = stack.api.get(f"/v1/transfers/{t['transfer_id']}", headers=stack.auth(tok)).json()
    assert snap["status"] == "REVERSED" and snap["status_reason"] == "RAIL_RETURN_AFTER_RECON"
    assert stack.balance("W-CUST-0004") == w0 + 210_000
    journals = [r["journal_type"] for r in stack.q("SELECT journal_type::text FROM journal_entry WHERE transfer_id = %s "
                                                   "ORDER BY posted_at", (t["transfer_id"],))]
    assert journals == ["TRANSFER_POST", "TRANSFER_SETTLE", "TRANSFER_RETURN"]
    exc = stack.q("SELECT exception_id, kind, owner_role FROM ops_exception WHERE transfer_id = %s", (t["transfer_id"],))
    assert [(e["kind"], e["owner_role"]) for e in exc] == [("LATE_RETURN_AFTER_RECON", "finance_controller")]

    # the next day's reconciliation matches REVERSED against RETURNED: nothing new to chase
    run = recon(stack, TOMORROW)
    assert run["new_breaks"] == 0 and run["lines_imported"] == 1

    # the owner (finance) closes the exception; ops cannot
    eid = str(exc[0]["exception_id"])
    denied = stack.api.post(f"/v1/ops/exceptions/{eid}/resolution", headers=stack.auth(OPS1),
                            json={"comment": "trying to close a finance item"})
    assert denied.status_code == 403
    ok = stack.api.post(f"/v1/ops/exceptions/{eid}/resolution", headers=stack.auth(FIN1),
                        json={"comment": "closed-day report for yesterday re-issued with the return"})
    assert ok.status_code == 200 and ok.json()["state"] == "RESOLVED"
    assert stack.ledger_ok()
    record_evidence("week14_late_return", {"status": snap["status"], "journals": journals, "next_day_recon": run})


def test_write_off_posts_adjustment_journal_with_four_eyes(stack):
    t = stack.transfer(customer(4), body(4, 120_000)).json()
    # the rail statement shows the payment twice: the money left the sponsor bank twice
    stack.rail.post("/_control/extra_line", json={"request_id": t["transaction_reference"], "rail_reference": "RAIL-SYN-DUP1",
                                                  "amount_minor": 120_000, "rail_status": "EXECUTED"})
    run = recon(stack)
    brk = stack.q("SELECT break_id, break_type::text, owner_role, internal_amount_minor, external_amount_minor "
                  "FROM recon_break WHERE transfer_id = %s", (t["transfer_id"],))[0]
    assert run["new_breaks"] == 1 and brk["break_type"] == "DUPLICATE" and brk["external_amount_minor"] == 240_000
    url = f"/v1/reconciliation/breaks/{brk['break_id']}/resolution"
    f0, x0 = stack.balance("1100"), stack.balance("5100")

    same = stack.api.post(url, headers=hdr(stack, FIN1), json={"resolution_code": "WRITTEN_OFF_APPROVED",
                          "comment": "rail refused to return the duplicate", "approved_by": "fin.demo1"})
    assert same.status_code == 403 and same.json()["code"] == "SOD_VIOLATION"
    assert stack.balance("5100") == x0                                    # nothing posted

    ok = stack.api.post(url, headers=hdr(stack, FIN1), json={"resolution_code": "WRITTEN_OFF_APPROVED",
                        "comment": "rail refused to return the duplicate", "approved_by": "fin.demo2"})
    assert ok.status_code == 200, ok.text
    adj = stack.q("""SELECT j.journal_type::text, a.code, e.direction::text, e.amount_minor FROM journal_entry j
                      JOIN ledger_entry e USING (journal_id) JOIN ledger_account a USING (account_id)
                     WHERE j.transfer_id = %s AND j.journal_type = 'RECON_ADJUSTMENT' ORDER BY e.leg_no""",
                  (t["transfer_id"],))
    assert [(r["code"], r["direction"], r["amount_minor"]) for r in adj] == [("5100", "DEBIT", 120_000),
                                                                              ("1100", "CREDIT", 120_000)]
    assert stack.balance("1100") == f0 - 120_000 and stack.balance("5100") == x0 + 120_000
    assert stack.ledger_ok()                                              # float invariant counts the write-off

    rerun = recon(stack)                                                  # same evidence is not raised again
    assert rerun["new_breaks"] == 0 and rerun["matched"] == 1
    assert stack.scalar("SELECT status::text FROM transfer WHERE transfer_id = %s", (t["transfer_id"],)) == "RECONCILED"
    assert stack.q("SELECT written_off_minor FROM v_ops_health")[0]["written_off_minor"] == 120_000
    record_evidence("week14_write_off", {"break": "DUPLICATE", "adjustment": [dict(r) for r in adj], "rerun": rerun})


def test_write_off_is_refused_when_there_is_no_loss(stack):
    stack.fault("fail_settle")
    t = stack.transfer(customer(4), body(4, 60_000)).json()
    stack.clear_faults()
    recon(stack)                                                          # STATUS_MISMATCH, amounts equal
    bid = stack.scalar("SELECT break_id FROM recon_break WHERE transfer_id = %s", (t["transfer_id"],))
    r = stack.api.post(f"/v1/reconciliation/breaks/{bid}/resolution", headers=hdr(stack, FIN1),
                       json={"resolution_code": "WRITTEN_OFF_APPROVED", "comment": "attempted write-off without a loss",
                             "approved_by": "fin.demo2"})
    assert r.status_code == 422 and r.json()["code"] == "WRITE_OFF_NOT_APPLICABLE"
    assert stack.scalar("SELECT count(*) FROM journal_entry WHERE journal_type = 'RECON_ADJUSTMENT'") == 0


# ---------------------------------------------------------------- dead-letter replay and discard

def test_dead_letter_replay_and_discard_are_controlled_and_audited(stack):
    assert events.notify({"event_id": "not-a-uuid", "event_type": "transfer.status.changed"}) == "DEAD_LETTER"
    poison = stack.scalar("SELECT dlq_id FROM dead_letter_event")
    r = stack.api.post(f"/v1/ops/dead-letters/{poison}/replay", headers=stack.auth(OPS1))
    assert r.status_code == 200 and r.json()["result"] == "STILL_INVALID" and r.json()["state"] == "OPEN"
    assert stack.api.post(f"/v1/ops/dead-letters/{poison}/discard", headers=stack.auth(FIN1),
                          json={"reason": "finance trying to discard"}).status_code == 403
    d = stack.api.post(f"/v1/ops/dead-letters/{poison}/discard", headers=stack.auth(OPS1),
                       json={"reason": "malformed test event, no transfer behind it"})
    assert d.status_code == 200 and d.json()["state"] == "DISCARDED"

    # an event that failed because of a consumer defect, now fixed: replay delivers it exactly once
    t = stack.transfer(customer(4), body(4, 30_000)).json()
    ev = stack.q("SELECT payload FROM outbox_event WHERE aggregate_id = %s ORDER BY sequence DESC LIMIT 1",
                 (t["transfer_id"],))[0]["payload"]
    stack.q("INSERT INTO dead_letter_event (consumer_name, event_id, payload, error) VALUES ('notification', %s, %s, %s)",
            (ev["event_id"], json.dumps(ev), "CONSUMER_DEFECT: template missing (fixed in 0.14.0)"))
    good = stack.scalar("SELECT max(dlq_id) FROM dead_letter_event")
    r = stack.api.post(f"/v1/ops/dead-letters/{good}/replay", headers=stack.auth(OPS1))
    assert r.json()["result"] == "SENT" and r.json()["state"] == "REPLAYED"
    assert stack.api.post(f"/v1/ops/dead-letters/{good}/replay", headers=stack.auth(OPS1)).status_code == 422
    assert stack.scalar("SELECT count(*) FROM notification_log WHERE event_id = %s", (ev["event_id"],)) == 1
    actions = [r["action"] for r in stack.q("SELECT action FROM audit_log WHERE action LIKE 'DLQ_%%' "
                                            "AND outcome = 'ALLOWED' ORDER BY audit_id")]
    assert actions == ["DLQ_REPLAY", "DLQ_DISCARD", "DLQ_REPLAY"]


# ---------------------------------------------------------------- ADR-007: exception-triage assistant

def _partial_failure_items(stack):
    stack.fault("fail_settle")
    t = stack.transfer(customer(4), body(4, 180_000)).json()
    stack.clear_faults()
    recon(stack)
    exc = stack.scalar("SELECT exception_id FROM ops_exception WHERE transfer_id = %s", (t["transfer_id"],))
    brk = stack.scalar("SELECT break_id FROM recon_break WHERE transfer_id = %s", (t["transfer_id"],))
    return t, str(exc), str(brk)


def test_triage_suggests_from_the_catalogue_and_records_everything(stack):
    t, exc, brk = _partial_failure_items(stack)
    r = stack.api.post("/v1/ai/triage", headers=stack.auth(OPS1), json={"item_type": "BREAK", "item_id": brk})
    assert r.status_code == 201, r.text
    s = r.json()
    assert s["advisory_only"] is True and s["category"] == "STATUS_MISMATCH"
    assert s["recommended_action"] == "RUN_STATUS_ENQUIRY" and not s["abstained"] and s["confidence"] >= 0.7
    assert t["transaction_reference"] in s["summary"]
    row = stack.q("SELECT inputs, input_hash, model_version FROM ai_triage_suggestion WHERE suggestion_id = %s",
                  (s["suggestion_id"],))[0]
    blob = json.dumps(row["inputs"])
    for secret in ("PK00FAKE", "Dania", "0300000000", "CUST-0004", "Synthetic Beneficiary"):
        assert secret not in blob and secret not in s["summary"]           # no personal data reached the assistant
    assert row["input_hash"] == triage.input_hash(row["inputs"])
    audit = stack.q("SELECT actor, actor_role, details FROM audit_log WHERE action = 'AI_TRIAGE_SUGGESTION'")
    assert len(audit) == 1 and audit[0]["actor"] == "ai.triage" and audit[0]["details"]["input_hash"] == row["input_hash"]

    e = stack.api.post("/v1/ai/triage", headers=stack.auth(FIN1), json={"item_type": "EXCEPTION", "item_id": exc}).json()
    assert e["category"] == "POSTING_FAILED" and e["recommended_action"] == "WAIT_FOR_AUTOMATED_RECOVERY"


def test_triage_review_is_human_only_and_executes_nothing(stack):
    t, _, brk = _partial_failure_items(stack)
    s = stack.api.post("/v1/ai/triage", headers=stack.auth(OPS1), json={"item_type": "BREAK", "item_id": brk}).json()
    before = stack.q("SELECT status::text, version FROM transfer WHERE transfer_id = %s", (t["transfer_id"],))[0]
    assert stack.api.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=stack.auth(CO1),
                          json={"decision": "ACCEPT", "comment": "compliance has no say here"}).status_code == 403
    r = stack.api.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=stack.auth(OPS1),
                       json={"decision": "ACCEPT", "comment": "agree, enquiry is the right first step"})
    assert r.status_code == 200 and r.json()["executed"] is False
    assert stack.q("SELECT status::text, version FROM transfer WHERE transfer_id = %s", (t["transfer_id"],))[0] == before
    assert stack.api.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=stack.auth(OPS1),
                          json={"decision": "REJECT", "comment": "changing my mind later"}).status_code == 422
    # the person then takes the step through the normal endpoint, under their own role
    enq = stack.api.post(f"/v1/transfers/{t['transfer_id']}/status-enquiry", headers=stack.auth(OPS1)).json()
    assert enq["transfer"]["status"] == "SETTLED"
    q = stack.api.get("/v1/ai/triage/quality", headers=stack.auth(FIN1)).json()
    assert q["by_model_version"][0]["accepted"] == 1 and q["config"]["enabled"] is True


def test_triage_abstains_on_material_and_sanctions_cases():
    base = {"kind": "STATUS_MISMATCH", "transfer_status": "SETTLED", "transaction_reference": "FW-20261119-000009",
            "statement_executed_lines": 1, "statement_returned": False, "last_rail_outcome": "EXECUTED",
            "amount_minor": 150_000, "owner_role": "ops_analyst", "age_minutes": 10, "journals": ["TRANSFER_POST"]}
    assert triage.decide(base, 0.7, 15_000_000)["recommended_action"] == "RESOLVE_AS_MATCHED_LATE"
    m = triage.decide({**base, "amount_minor": 15_000_000}, 0.7, 15_000_000)
    assert m["abstained"] and m["abstain_reason"] == "MATERIAL_AMOUNT" and m["recommended_action"] == "HUMAN_ANALYSIS_REQUIRED"
    s = triage.decide({**base, "screening_reasons": ["R07"]}, 0.7, 15_000_000)
    assert s["abstained"] and s["abstain_reason"] == "SANCTIONS_OR_COMPLIANCE_RELATED"
    low = triage.decide({**base, "statement_executed_lines": 0, "last_rail_outcome": None,
                         "statement_returned": True}, 0.95, 15_000_000)
    assert low["abstained"] and low["abstain_reason"] == "LOW_CONFIDENCE"
    # the guard rejects anything outside the catalogue or carrying personal data, whatever the model said
    bad = {**triage.decide(base, 0.7, 15_000_000), "recommended_action": "APPROVE_WRITE_OFF"}
    assert "ACTION_NOT_IN_CATALOGUE" in triage.policy_guard(bad, base, 15_000_000)
    leak = {**triage.decide(base, 0.7, 15_000_000), "summary": "pay PK00FAKE0000000000000001 now"}
    assert "PERSONAL_DATA_IN_OUTPUT" in triage.policy_guard(leak, base, 15_000_000)


def test_assistant_role_cannot_touch_money_or_controls(stack):
    t, _, brk = _partial_failure_items(stack)
    probes = [
        "UPDATE transfer SET status = 'FAILED'",
        "SELECT ledger_post('%s', 'TRANSFER_SETTLE')" % t["transfer_id"],
        "INSERT INTO journal_entry (journal_type, funding_reference) VALUES ('FUNDING', 'x')",
        "SELECT resolve_break('%s', 'MATCHED_LATE', 'ai closing it', NULL, NULL)" % brk,
        "UPDATE recon_break SET state = 'RESOLVED'",
        "INSERT INTO case_decision (case_id, decision, rationale, decided_by) VALUES (gen_random_uuid(), 'RELEASE', 'xxxxxxxxxx', gen_random_uuid())",
        "UPDATE ai_triage_config SET enabled = true",
        "INSERT INTO ai_triage_review (suggestion_id, decision, comment, reviewed_by) VALUES (gen_random_uuid(), 'ACCEPT', 'self approval', gen_random_uuid())",
        "SELECT full_name, mobile_msisdn FROM customer",
        "SELECT beneficiary_identifier FROM transfer",
        "SELECT * FROM rail_message_log",
    ]
    for sql in probes:
        with pytest.raises(psycopg2.errors.InsufficientPrivilege):
            with db.tx("fw_ai", "probe") as cur:
                cur.execute(sql)
    with db.tx("fw_ai", "probe") as cur:                 # what it is allowed to do
        cur.execute("SELECT count(*) AS n FROM v_triage_item")
        assert cur.fetchone()["n"] >= 1


def test_kill_switch_is_finance_only_and_stops_the_assistant(stack):
    _, _, brk = _partial_failure_items(stack)
    off = {"enabled": False, "reason": "model under review after a complaint"}
    assert stack.api.put("/v1/ai/triage/config", headers=stack.auth(OPS1), json=off).status_code == 403
    assert stack.api.put("/v1/ai/triage/config", headers=stack.auth(FIN2), json=off).json()["enabled"] is False
    r = stack.api.post("/v1/ai/triage", headers=stack.auth(OPS1), json={"item_type": "BREAK", "item_id": brk})
    assert r.status_code == 503 and r.json()["code"] == "AI_DISABLED"
    assert stack.api.get("/v1/reconciliation/breaks", headers=stack.auth(OPS1)).status_code == 200   # work goes on
    on = {"enabled": True, "abstain_below": 0.75, "reason": "review finished, threshold raised"}
    assert stack.api.put("/v1/ai/triage/config", headers=stack.auth(FIN2), json=on).json()["abstain_below"] == 0.75
    assert stack.api.post("/v1/ai/triage", headers=stack.auth(OPS1),
                          json={"item_type": "BREAK", "item_id": brk}).status_code == 201
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action = 'AI_TRIAGE_CONFIG' AND outcome = 'ALLOWED'") == 2


def test_offline_evaluation_meets_the_agreed_targets():
    sys.path.insert(0, str(ROOT / "infra"))
    import ai_triage_eval as ev
    cases = json.loads((ROOT / "data" / "ai_triage_eval_set.json").read_text())
    m = ev.evaluate(cases)
    assert m["cases"] == 240 and m["targets_met"], {k: m[k] for k in ev.TARGETS}
    assert m["must_abstain_honoured"] == m["must_abstain_cases"]
    assert m["policy_violations"] == 0
    record_evidence("week14_ai_eval", {k: v for k, v in m.items() if k != "errors"})


def test_metrics_and_dashboard_show_the_week14_controls(stack):
    m = stack.api.get("/metrics").text
    for name in ("fw_ledger_system_accounts_ok", "fw_written_off_minor", "fw_rate_limited_last_hour",
                 "fw_ai_awaiting_review", "fw_ai_abstained"):
        assert name in m
    page = stack.api.get("/ops/dashboard", headers=stack.auth(FIN1)).text
    assert "AI awaiting review" in page and "Rate-limited" in page and "system accounts" in page


def test_assistant_role_holds_exactly_its_three_grants(stack):
    """Found by the Week 14 mutation check: a probe list can miss a new grant, so check the full grant set."""
    grants = {(r["table_name"], r["privilege_type"]) for r in stack.q(
        "SELECT table_name, privilege_type FROM information_schema.role_table_grants WHERE grantee = 'fw_ai'")}
    assert grants == {("v_triage_item", "SELECT"), ("ai_triage_config", "SELECT"), ("ai_triage_suggestion", "INSERT")}


def test_an_abstention_cannot_be_accepted(stack):
    """Found by the Week 14 mutation check: nobody may 'accept' a case the assistant handed to a person."""
    _, _, brk = _partial_failure_items(stack)
    stack.api.put("/v1/ai/triage/config", headers=stack.auth(FIN1),
                  json={"enabled": True, "abstain_below": 0.99, "reason": "force abstention for the test"})
    s = stack.api.post("/v1/ai/triage", headers=stack.auth(OPS1), json={"item_type": "BREAK", "item_id": brk}).json()
    assert s["abstained"] and s["recommended_action"] == "HUMAN_ANALYSIS_REQUIRED" and s["abstain_reason"] == "LOW_CONFIDENCE"
    r = stack.api.post(f"/v1/ai/triage/suggestions/{s['suggestion_id']}/review", headers=stack.auth(OPS1),
                       json={"decision": "ACCEPT", "comment": "accepting an abstention"})
    assert r.status_code == 422


def test_audit_chain_stays_intact_under_concurrent_writers(stack):
    """Found by the Week 15 restore drill: ids were drawn before the chain lock, so concurrent writers broke
    the chain as seen in id order. The chain now has its own sequence drawn under the lock."""
    import concurrent.futures as cf

    def write(i):
        with db.tx("fw_txn", f"probe-{i}") as cur:
            cur.execute("SELECT audit(%s, 'ops_analyst', 'CONCURRENCY_PROBE', 'probe', %s, 'ALLOWED')",
                        (f"probe-{i}", str(i)))
    with cf.ThreadPoolExecutor(16) as pool:
        list(pool.map(write, range(200)))
    assert stack.scalar("SELECT count(*) FROM audit_log WHERE action = 'CONCURRENCY_PROBE'") == 200
    assert stack.q("SELECT chain_ok FROM verify_audit_chain()")[0]["chain_ok"] is True
