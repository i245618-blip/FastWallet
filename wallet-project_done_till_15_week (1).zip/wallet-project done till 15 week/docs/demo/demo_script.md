# Technical demonstration: talk track (8-10 minutes)

Run: `./infra/run_demo.sh` (fresh database, mock rail and API, seven segments). The script pauses nothing;
the presenter talks over each segment's output. Planned time 9.75 minutes plus questions.

| # | Segment | Presenter | Minutes | What to point at |
|---|---|---|---|---|
| - | Opening: problem, journey, architecture in one slide | Safiullah Shakeel | 0.75 | Wallet-to-bank over an instant rail; C4 container view; PostgreSQL is the system of record |
| 1 | Normal flow: initiate -> screen -> post -> rail -> settle -> notify -> reconcile | Safiullah Shakeel | 1.25 | Lineage line: 2 journals, 4 state changes, 4 events; masked SMS; reconciliation match |
| 2 | Failure 1: rail timeout -> PENDING -> client retry with the same key -> recovery by enquiry | Danyal Kiyani | 1.5 | Same Idempotency-Key replayed; one rail submission; rail log ends ENQUIRY_RESULT:EXECUTED |
| 3 | Failure 2: partial failure -> break -> triage assistant -> person decides -> recovered | Khawaja Rafay | 1.75 | POSTING_FAILED item; STATUS_MISMATCH break; assistant suggestion is advisory; analyst runs the enquiry |
| 4 | Reconciliation outcome: duplicate payment on the rail -> break -> four-eyes write-off | Sarmad | 1.25 | DUPLICATE break; same-person write-off refused (SOD); second approver posts RECON_ADJUSTMENT |
| 5 | Late return after reconciliation -> customer credited, finance told | Sarmad | 0.75 | REVERSED with RAIL_RETURN_AFTER_RECON; LATE_RETURN item for finance; next-day recon clean |
| 6 | Controls: hold and release, denied role, rate limit, AI kill switch, audit chain | Shyan | 1.5 | Officer-only release; 429 on the third request; kill switch 503; denied actions in the audit chain |
| 7 | Ledger controls and the finance report | Shyan | 0.5 | Four ledger controls true; settlement report |
| 8 | Close: what is proven, limits, recommendation | Khawaja Rafay | 0.5 | Go / conditional-go recommendation and the open limits |

## Rehearsal record

The script was run three times in a row on a fresh database each time:

| Run | All checks OK | Script time (s) |
|---|---|---|
| 1 | True | 6.36 |
| 2 | True | 6.45 |
| 3 | True | 6.32 |

Segment 2 waits for the 5-second rail budget on purpose; the rest runs in under a second each.
If the live run fails, show `evidence/week14/demo_run_output.txt` (same script, same output) and continue.

## Checklist before the defence
- Fresh database reachable; `pytest -q` green on the presenting laptop.
- Secrets exported (`FW_JWT_SECRET`, `FW_RAIL_ACK_SECRET`); ports 8000 and 8100 free.
- Dashboard open at `/ops/dashboard` with a finance token for segment 7.
- Backup: evidence folder and slides open offline.
