# ADR-008: Connection pool and sharded balances for the two system accounts
**Status:** Accepted (Week 14)

## Context
Week 13 missed the accept-latency SLO (p95 < 500 ms) at 20 concurrent requests. Sampling `pg_stat_activity`
during the load run showed almost every waiting session blocked on a row lock inside `ledger_post`: every
transfer updates the single balance row of 2200 (in transit) and every settlement the row of 1100 (float).
Each unit of work also opened a new database connection (about 8.5 ms).

## Decision
- A blocking connection pool per process (`FW_DB_POOL_SIZE`, default 20). `SET LOCAL ROLE` and the actor
  setting end with each transaction, so nothing leaks between requests. A dead connection after a database
  restart is detected on the first statement, the idle set is discarded and the work restarts once.
- Accounts flagged with `balance_shards > 1` (1100 and 2200, 16 shards) keep their running balance in
  `account_balance_shard`, one row chosen per entry. `account_balance` is now a view adding base and shards,
  so every reader is unchanged. Customer wallets keep one row, because their overdraft check needs it.
- The per-row negative-balance check for the two system accounts moves to the control view
  (`system_accounts_ok`, a dashboard gauge).

## Alternatives considered
- More API worker processes: +15 % throughput in a trial, but in-process metrics would then need
  Prometheus multiprocess mode. Deferred.
- Asynchronous balance projection: removes the lock but makes balances briefly stale; rejected for wallets.
- Removing the audit hash chain lock: it is now the next shared wait; kept, because the chain is a control.

## Consequences
+ 20 concurrent requests spread over five customers: accept p95 <= 400 ms (Week 13: <= 1 s).
+ Ledger controls hold after every load run; projection check and trial balance unchanged.
- One wallet sending 20 requests at once still queues on its own balance row (accept p95 <= 750 ms).
  That serialisation is correct: it is what stops an overdraft.
