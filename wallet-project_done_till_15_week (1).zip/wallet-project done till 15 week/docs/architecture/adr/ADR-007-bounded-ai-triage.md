# ADR-007: The AI extension is an advisory exception-triage assistant with no authority
**Status:** Accepted (Week 14)

## Context
Guidelines section 7 requires one bounded AI extension with allowed data, prohibited actions, an abstention
threshold, a human approval boundary, audit logging and at least four quality and risk metrics. AI must never
become the authority for money movement, KYC override, sanctions clearance or other material controls.
Operations and finance spend most manual time on the exception queue and reconciliation breaks.

## Decision
- Extension: exception triage. For one open exception or break the assistant writes a plain summary and
  recommends one step from a fixed catalogue of six (status enquiry, wait for recovery, resolve as matched late,
  request rail correction, escalate to finance, escalate to compliance), with a confidence.
- Data: only `v_triage_item` (references, statuses, amounts, counts, reason codes). No names, mobile numbers,
  national id tokens, beneficiary accounts or customer references.
- Authority: none. It runs as database role `fw_ai` with exactly three grants (read its view and its
  configuration, insert suggestions). A person accepts or rejects; accepting executes nothing.
- Abstention: material amount (Rs 150,000, same as R10), anything sanctions or compliance related, missing
  evidence, unknown pattern, or confidence below 0.70. An independent policy guard re-checks every output.
- Model: deterministic weighted-evidence scorer (allowed by section 7 when no generative model is used),
  version `triage-rules-1.2`. Suggestions, inputs, input hash, model version and latency are stored
  append-only and audited.
- Kill switch and threshold: finance controller only, audited.
- Metrics and targets: false approval <= 2 %, false escalation <= 25 %, resolution accuracy >= 90 %,
  policy violations = 0, audit completeness 100 %, latency p95 <= 50 ms; human override rate monitored live.

## Alternatives considered
- Fraud-alert triage on compliance holds: closer to sanctions and KYC decisions, the area the brief says AI
  must not control. Rejected.
- A hosted language model writing free-text advice: better summaries, but personal data would leave the
  boundary and outputs are harder to test. Kept as a later option behind the same view, guard and review.
- Letting the assistant run status enquiries itself: an enquiry is safe, but it would be the first step
  towards automatic action. Rejected; the person runs it.

## Consequences
+ The assistant can be wrong without moving money; every error is caught by a person or the guard.
+ The evaluation shows the remaining false approvals come from facts it cannot see (a return announced by
  the bank by phone). The threshold cannot fix those, which is why review stays mandatory.
- Abstention costs analyst time (15 % of cases handed over without a suggestion on the evaluation set).
