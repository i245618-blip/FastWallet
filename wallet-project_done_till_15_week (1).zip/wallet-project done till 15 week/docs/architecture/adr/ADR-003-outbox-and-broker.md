# ADR-003: Transactional outbox with duplicate-safe consumers; broker is pluggable
**Status:** Accepted (proposed Week 10, confirmed at the Week 14 architecture review)

## Context
Events (`transfer.status.changed`) must never be lost when state changes, and consumers must tolerate duplicates and reordering.

## Decision
- Producer writes an **outbox row** in the same DB transaction as the state change; a relay publishes it and marks it sent (at-least-once).
- Consumers use an **inbox table** with `UNIQUE (consumer_name, event_id)` plus a per-transfer `sequence` check.
- Default local delivery: DB-polling relay and in-process dispatch (zero extra infrastructure). Optional upgrade: Redpanda/RabbitMQ behind the same relay interface, without changing the event contract.

## Alternatives considered
- Publish directly to a broker after commit (dual write): can lose events on crash.
- Kafka-compatible broker from day one: more realistic but harder to explain/run; brief says a simple stack done correctly scores higher.

## Consequences
+ No lost events, simple reproducible demo, real exactly-once *effect* via idempotent consumers.
- Polling adds small latency (target < 1 s).
