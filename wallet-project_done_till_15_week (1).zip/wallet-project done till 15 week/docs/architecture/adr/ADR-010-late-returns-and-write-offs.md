# ADR-010: Late rail returns and approved write-offs post linked journals
**Status:** Accepted (Week 14)

## Context
Two Week 13 gaps: a return arriving after a transfer was already RECONCILED went to the exception queue as a
conflict, and an approved write-off was recorded on the break but nothing was posted, so the books still
showed money that had left the sponsor bank.

## Decision
- Late return: the rail's signed RETURNED answer is the evidence. `RECONCILED -> REVERSED` is allowed only with
  a TRANSFER_RETURN journal (enforced by the trigger). The customer is credited at once and a
  LATE_RETURN_AFTER_RECON item tells finance that a closed day changed. Statement import became incremental,
  so the return line is picked up and the next run matches REVERSED against RETURNED.
- Write-off: approval by a second finance controller posts a RECON_ADJUSTMENT journal for the loss only
  (rail amount above ours): debit 5100 write-off expense, credit 1100 float. No loss, or no internal transfer,
  gives 422 WRITE_OFF_NOT_APPLICABLE. The float invariant becomes float + write-offs = wallets + in transit.
- A resolved break is not raised again for the same evidence when a day is re-run.

## Alternatives considered
- Keep RECONCILED terminal and refund by a manual journal: slower for the customer, and a manual journal is
  exactly what the ledger rules forbid.
- Post write-offs from the API: would give the API write access to the ledger.

## Consequences
+ Every change to money is still a new, linked, balanced journal; nothing is edited.
+ Finance reports and the float control stay true after a write-off.
- A closed day can change; the exception item and the audit trail make that visible.
