# ADR-001: Synchronous accept, asynchronous downstream effects
**Status:** Accepted (proposed Week 10, confirmed at the Week 14 architecture review) | **Deciders:** Team

## Context
A transfer touches the ledger (must be atomic), an external rail (slow, can time out) and consumers such as notification and reconciliation (must not block the customer).

## Decision
- The client-facing call `POST /v1/transfers` is **synchronous up to POSTED** (validation, controls, ledger posting) and returns `202 Accepted` with the current status.
- Rail submission is attempted inline with a 5 s budget; any non-definitive result leaves the transfer `PENDING` and the client polls `GET /v1/transfers/{id}` (or receives a notification).
- Everything after a state change (notification, reconciliation feed, reporting) is **event-driven**.

## Alternatives considered
1. Fully synchronous end-to-end: simple, but customer latency and thread exhaustion follow rail slowness, and timeouts leak into the client.
2. Fully asynchronous (queue before posting): better smoothing, but the customer cannot be told that funds were reserved, and idempotent accept becomes harder to explain.

## Consequences
+ Clear money-movement truth at the moment of 202; failures are modelled as states, not exceptions.
- Clients must handle `PENDING`; requires status polling or push.
