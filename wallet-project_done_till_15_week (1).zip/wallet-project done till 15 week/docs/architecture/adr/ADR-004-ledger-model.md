# ADR-004: Double-entry append-only ledger inside the transaction service's database
**Status:** Accepted (Week 12; amended Week 14 by ADR-008 and ADR-010)

## Context
The brief requires balanced debit/credit entries, immutable references and a clear source of truth for balances.

## Decision
- Every posting is a **journal** of two or more entries whose debits equal credits (enforced by a DB constraint/check before commit).
- Entries are append-only; corrections are new linked entries (`reverses_entry_id`).
- Accounts used: customer wallet (liability), transit/suspense (liability), settlement-clearing (asset/receivable from the rail), fee revenue (extension).
- The ledger is a module sharing the transaction DB so that posting, state, idempotency and outbox commit atomically. Balances are derived from entries (with a projected balance row for speed, rebuildable).

## Alternatives considered
- Separate ledger microservice: cleaner boundary, but needs sagas or 2PC for atomicity; harder to demo and test in a semester.
- Single balance column updated in place: no audit trail and no safe reversal.

## Consequences
+ Strong integrity and auditability; reconciliation can recompute truth from entries.
- Tighter coupling; the dossier must state this trade-off and how it would be split later.
