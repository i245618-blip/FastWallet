# ADR-002: Idempotency records live in PostgreSQL, not Redis
**Status:** Accepted (proposed Week 10, confirmed at the Week 14 architecture review)

## Context
Idempotency must survive restarts and be atomic with the financial state change.

## Decision
Store idempotency records in a PostgreSQL table (see `04_idempotency_strategy.md`), written in the same transaction as the transfer, ledger entries and outbox row. Redis is optional later as a read cache only, never as the authority.

## Alternatives considered
- Redis `SET NX` with TTL: fast, but a crash between the Redis write and the DB commit (or a Redis flush) creates either lost protection or a stuck key; two stores cannot commit atomically.
- No key store, rely on business uniqueness: cannot replay the original response and cannot detect payload tampering.

## Consequences
+ Atomic, durable, easy to test and demo with one container.
- Slightly more DB load; mitigated by a 72 h purge job and a primary-key lookup.
