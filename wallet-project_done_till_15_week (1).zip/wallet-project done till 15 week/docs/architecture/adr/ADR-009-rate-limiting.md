# ADR-009: Fixed-window rate limiting stored in PostgreSQL
**Status:** Accepted (Week 14)

## Context
The error model reserved `RATE_LIMITED` but nothing enforced it. A runaway client retry loop or a stolen
token should not be able to flood the transfer path, the audit log or staff endpoints.

## Decision
`rate_limit_take(scope, subject)` increments one counter row per subject per window and answers allowed,
hits, limit and seconds to wait. Limits are data (`rate_limit_policy`): 30 transfer requests per customer per
minute, 120 staff writes and 60 triage requests per staff user per minute. Refusals return 429 with
`Retry-After`. Only the first refusal in a window is audited. The worker purges windows older than a day.

## Alternatives considered
- Redis token bucket: faster and standard, but another component to run; the counter is one short
  transaction on a row only that subject touches.
- In-process limits: wrong as soon as there is more than one API process or a restart.

## Consequences
+ Shared by every API process, survives restarts, testable, tunable without a deploy.
- One extra short transaction per limited request (about 1 ms with the pool).
