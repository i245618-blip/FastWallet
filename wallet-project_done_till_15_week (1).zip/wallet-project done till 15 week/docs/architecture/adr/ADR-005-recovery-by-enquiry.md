# ADR-005: Recover unknown rail outcomes by status enquiry, never by blind replay
**Status:** Accepted (Week 13)

## Context
A rail call can time out after the rail has already paid, or the request can be lost before it arrives.
The service can also crash between committing POSTED and calling the rail. Replaying the payment risks a
double payment; doing nothing leaves customer money parked in suspense.

## Decision
Any non-definitive answer (timeout, 5xx, unreachable) moves the transfer to PENDING. A worker asks the
rail for the status of the immutable transaction reference with backoff 5 s, 15 s, 45 s, 2 min, 5 min.
EXECUTED settles, REJECTED reverses, and NOT_FOUND (the rail never saw it) allows one resubmission with the
same reference, which the rail deduplicates. After five unanswered enquiries the transfer goes to a manual
exception queue owned by ops. Every rail answer is logged before it is applied, and one function
(`apply_outcome`) applies answers from all sources.

## Alternatives considered
- Retry the submit on timeout: simple, but pays twice whenever the first call executed.
- Reverse on timeout: protects the customer but is wrong whenever the rail executed, and the money is gone.
- Wait for the end-of-day statement only: correct but leaves money unknown for hours.

## Consequences
+ No double payment, demonstrated by tests that count rail submissions.
+ Partial failures leave evidence (rail message log) and a queue item instead of silent drift.
- Needs a worker process and a rail enquiry operation; customers see PENDING for up to 15 minutes.
