# ADR-006: Token-based authentication with two-layer authorisation and per-service database roles
**Status:** Accepted for the prototype (Week 13)

## Context
The brief requires authentication, authorisation, least privilege, segregation of duties and audited
denials. A full identity provider is optional in the stack.

## Decision
The gateway validates HS256 JWTs (signature, expiry, issuer) carrying `sub`, `roles`, `client_id` and
`mfa`. Roles are checked on every operation, and again inside the database for money-moving or
control decisions. Each service switches to its own NOLOGIN role (`SET LOCAL ROLE`) for every unit of
work. Secrets come only from environment variables. Rail acknowledgements are HMAC-signed.

## Alternatives considered
- Keycloak from day one: realistic, but adds a component the team must run and explain; the token shape is
  compatible, so it can replace the mock IdP later.
- One database user with full rights: simpler, but a defect in any service could move money.

## Consequences
+ Denials are enforced and audited in two places; tests show each service role cannot exceed its job.
+ Integration testing found two real grant defects (notification consumer `RETURNING`, `assert_role` not
  granted), which this layering made visible.
- HS256 uses a shared secret; production would use asymmetric keys and per-service login users.
