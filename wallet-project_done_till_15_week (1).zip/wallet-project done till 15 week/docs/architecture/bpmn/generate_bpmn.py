"""Builds the BPMN 2.0 model of the wallet-to-bank transfer (with diagram coordinates, so it opens in Camunda
Modeler or bpmn.io) and renders the same layout to PNG.   python docs/architecture/bpmn/generate_bpmn.py"""
import pathlib
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch, Polygon, Rectangle

HERE = pathlib.Path(__file__).parent
LANES = ["Customer app", "Gateway +\nTxn Service", "Compliance\nofficer", "Payment rail\n(mock)",
         "Recovery\nworker", "Operations\nanalyst", "Finance\ncontroller"]
LANE_H, X0, COL_W = 120, 170, 135
# id, type, label, lane, column
N = [
    ("start", "start", "Customer\nsends money", 0, 0),
    ("submit", "task", "Submit transfer\n(token, 2FA,\nIdempotency-Key)", 0, 1),
    ("validate", "task", "Validate token,\nrole, key,\nownership", 1, 1),
    ("screen", "task", "Screen KYC/AML\nrules R01-R10", 1, 2),
    ("gw_screen", "xor", "Outcome?", 1, 3),
    ("blocked", "end", "Blocked\n(FAILED,\nevidence kept)", 0, 3),
    ("review", "task", "Review case\n(release/reject)", 2, 3),
    ("gw_case", "xor", "Released?", 2, 4),
    ("rejected", "end", "Rejected\n(FAILED)", 2, 5),
    ("post", "task", "Post debit to\nin-transit 2200\n(+ outbox event)", 1, 5),
    ("send", "task", "Submit to rail\n(5 s budget)", 1, 6),
    ("rail", "task", "Execute or\nreject payment", 3, 6),
    ("gw_rail", "xor", "Rail answer?", 1, 7),
    ("settle", "task", "Settle journal,\nstatus SETTLED", 1, 8),
    ("reverse", "task", "Compensate:\nreverse journal,\nREVERSED", 1, 9),
    ("pending", "task", "Mark PENDING\n(money stays\nin 2200)", 4, 7),
    ("enquire", "task", "Status enquiry\nwith backoff\n(never replay)", 4, 8),
    ("gw_enq", "xor", "Known?", 4, 9),
    ("manual", "task", "Exception queue:\nenquire or\nescalate", 5, 9),
    ("recon", "task", "Daily reconciliation\nvs rail statement", 6, 10),
    ("gw_recon", "xor", "Break?", 6, 11),
    ("resolve", "task", "Resolve break\n(write-off needs\nsecond approver)", 6, 12),
    ("triage", "task", "Triage assistant\nsuggests (advisory);\nanalyst decides", 5, 11),
    ("notify", "task", "Show authoritative\nstatus / SMS", 0, 10),
    ("done", "end", "Reconciled", 6, 13),
]
E = [("start", "submit", ""), ("submit", "validate", ""), ("validate", "screen", ""), ("screen", "gw_screen", ""),
     ("gw_screen", "blocked", "BLOCK"), ("gw_screen", "review", "HOLD"), ("gw_screen", "post", "ALLOW"),
     ("review", "gw_case", ""), ("gw_case", "rejected", "no"), ("gw_case", "post", "yes"),
     ("post", "send", ""), ("send", "rail", ""), ("rail", "gw_rail", ""),
     ("gw_rail", "settle", "EXECUTED"), ("gw_rail", "reverse", "REJECTED"), ("gw_rail", "pending", "timeout"),
     ("pending", "enquire", ""), ("enquire", "gw_enq", ""), ("gw_enq", "settle", "EXECUTED"),
     ("gw_enq", "manual", "5 tries"), ("manual", "enquire", "retry"),
     ("settle", "notify", ""), ("settle", "recon", ""), ("reverse", "notify", ""), ("recon", "gw_recon", ""),
     ("gw_recon", "done", "matched"), ("gw_recon", "triage", "yes"), ("triage", "resolve", ""), ("resolve", "done", "")]
SIZE = {"task": (112, 70), "xor": (44, 44), "start": (36, 36), "end": (36, 36)}
pos = {}
for nid, typ, label, lane, col in N:
    w, h = SIZE[typ]
    pos[nid] = (X0 + col * COL_W + (112 - w) / 2, lane * LANE_H + (LANE_H - h) / 2, w, h)
WIDTH = X0 + 14 * COL_W
tag = {"task": "task", "xor": "exclusiveGateway", "start": "startEvent", "end": "endEvent"}
lane_of = {n[0]: n[3] for n in N}

x = ['<?xml version="1.0" encoding="UTF-8"?>',
     '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" '
     'xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" '
     'xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="defs" targetNamespace="https://fastwallet.example/bpmn">',
     '<bpmn:collaboration id="collab"><bpmn:participant id="pool" name="FastWallet wallet-to-bank transfer (proposed)" processRef="transfer"/></bpmn:collaboration>',
     '<bpmn:process id="transfer" isExecutable="false"><bpmn:laneSet id="lanes">']
for i, ln in enumerate(LANES):
    x.append(f'<bpmn:lane id="lane{i}" name="{escape(ln.replace(chr(10), " "))}">' + "".join(
        f"<bpmn:flowNodeRef>{n[0]}</bpmn:flowNodeRef>" for n in N if n[3] == i) + "</bpmn:lane>")
x.append("</bpmn:laneSet>")
for nid, typ, label, lane, col in N:
    ins = "".join(f"<bpmn:incoming>f{k}</bpmn:incoming>" for k, e in enumerate(E) if e[1] == nid)
    outs = "".join(f"<bpmn:outgoing>f{k}</bpmn:outgoing>" for k, e in enumerate(E) if e[0] == nid)
    x.append(f'<bpmn:{tag[typ]} id="{nid}" name="{escape(label.replace(chr(10), " "))}">{ins}{outs}</bpmn:{tag[typ]}>')
x.append('<bpmn:boundaryEvent id="timer" name="5 s rail budget" attachedToRef="send" cancelActivity="true">'
         '<bpmn:timerEventDefinition id="td"><bpmn:timeDuration>PT5S</bpmn:timeDuration></bpmn:timerEventDefinition>'
         '</bpmn:boundaryEvent>')
for k, (a, b, lbl) in enumerate(E):
    x.append(f'<bpmn:sequenceFlow id="f{k}" name="{escape(lbl)}" sourceRef="{a}" targetRef="{b}"/>')
x.append('</bpmn:process><bpmndi:BPMNDiagram id="d"><bpmndi:BPMNPlane id="p" bpmnElement="collab">')
x.append(f'<bpmndi:BPMNShape id="pool_di" bpmnElement="pool" isHorizontal="true"><dc:Bounds x="0" y="0" width="{WIDTH}" height="{LANE_H * len(LANES)}"/></bpmndi:BPMNShape>')
for i in range(len(LANES)):
    x.append(f'<bpmndi:BPMNShape id="lane{i}_di" bpmnElement="lane{i}" isHorizontal="true"><dc:Bounds x="30" y="{i * LANE_H}" width="{WIDTH - 30}" height="{LANE_H}"/></bpmndi:BPMNShape>')
for nid, (px, py, w, h) in pos.items():
    x.append(f'<bpmndi:BPMNShape id="{nid}_di" bpmnElement="{nid}"><dc:Bounds x="{px:.0f}" y="{py:.0f}" width="{w}" height="{h}"/></bpmndi:BPMNShape>')
sx, sy, sw, sh = pos["send"]
x.append(f'<bpmndi:BPMNShape id="timer_di" bpmnElement="timer"><dc:Bounds x="{sx + sw - 30:.0f}" y="{sy + sh - 18:.0f}" width="36" height="36"/></bpmndi:BPMNShape>')


def anchors(a, b):
    ax, ay, aw, ah = pos[a]
    bx, by, bw, bh = pos[b]
    if lane_of[a] == lane_of[b] and abs(bx - ax) > 1.5 * COL_W:      # skip over the node in between
        yb = lane_of[a] * LANE_H + LANE_H - 8
        return [(ax + aw / 2, ay + ah), (ax + aw / 2, yb), (bx + bw / 2, yb), (bx + bw / 2, by + bh)]
    if abs(lane_of[a] - lane_of[b]) == 0:
        p1 = (ax + aw, ay + ah / 2) if bx > ax else (ax, ay + ah / 2)
        p2 = (bx, by + bh / 2) if bx > ax else (bx + bw, by + bh / 2)
        return [p1, p2]
    p1 = (ax + aw / 2, ay + ah) if by > ay else (ax + aw / 2, ay)
    p2 = (bx + bw / 2, by) if by > ay else (bx + bw / 2, by + bh)
    return [p1, (p1[0], (p1[1] + p2[1]) / 2), (p2[0], (p1[1] + p2[1]) / 2), p2]


for k, (a, b, lbl) in enumerate(E):
    wps = "".join(f'<di:waypoint x="{px:.0f}" y="{py:.0f}"/>' for px, py in anchors(a, b))
    x.append(f'<bpmndi:BPMNEdge id="f{k}_di" bpmnElement="f{k}">{wps}</bpmndi:BPMNEdge>')
x.append("</bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>")
(HERE / "wallet_to_bank_transfer.bpmn").write_text("\n".join(x))

# ---------------------------------------------------------------- PNG from the same coordinates
H = LANE_H * len(LANES)
fig, ax = plt.subplots(figsize=(WIDTH / 100, H / 100), dpi=110)
ax.set_xlim(0, WIDTH); ax.set_ylim(H, 0); ax.axis("off")
for i, ln in enumerate(LANES):
    ax.add_patch(Rectangle((0, i * LANE_H), WIDTH, LANE_H, fill=i % 2 == 0, color="#f3f5f9", ec="#9aa3b5", lw=0.8))
    ax.add_patch(Rectangle((0, i * LANE_H), 30, LANE_H, fill=True, color="#dde3ee", ec="#9aa3b5", lw=0.8))
    ax.text(15, i * LANE_H + LANE_H / 2, ln, rotation=90, ha="center", va="center", fontsize=6, linespacing=1.0, weight="bold", color="#1f3864")
for k, (a, b, lbl) in enumerate(E):
    pts = anchors(a, b)
    ax.plot([p[0] for p in pts], [p[1] for p in pts], color="#3a4660", lw=0.9)
    ax.annotate("", xy=pts[-1], xytext=pts[-2], arrowprops=dict(arrowstyle="-|>", color="#3a4660", lw=0.9))
    if lbl:
        mx, my = (pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2
        ax.text(mx + 3, my - 4, lbl, fontsize=5.5, color="#b3261e" if lbl in ("BLOCK", "REJECTED", "timeout", "no", "5 tries", "yes") and a.startswith("gw") else "#11733a")
for nid, typ, label, lane, col in N:
    px, py, w, h = pos[nid]
    cx, cy = px + w / 2, py + h / 2
    if typ == "task":
        ax.add_patch(FancyBboxPatch((px, py), w, h, boxstyle="round,pad=0,rounding_size=8", fc="white", ec="#1f3864", lw=1.1))
        ax.text(cx, cy, label, ha="center", va="center", fontsize=5.6)
    elif typ == "xor":
        ax.add_patch(Polygon([(cx, py), (px + w, cy), (cx, py + h), (px, cy)], fc="#fff8e1", ec="#8a6d00", lw=1.1))
        ax.text(cx, cy, "X", ha="center", va="center", fontsize=8, weight="bold", color="#8a6d00")
        ax.text(cx, py - 4, label, ha="center", va="bottom", fontsize=5.5)
    else:
        ax.add_patch(Circle((cx, cy), w / 2, fc="white", ec="#11733a" if typ == "start" else "#b3261e", lw=1.2 if typ == "start" else 2.6))
        ax.text(cx, py + h + 4, label, ha="center", va="top", fontsize=5.4)
ax.add_patch(Circle((sx + sw - 12, sy + sh), 12, fc="white", ec="#3a4660", lw=1))
ax.text(sx + sw - 12, sy + sh, "5s", ha="center", va="center", fontsize=5)
plt.savefig(HERE / "wallet_to_bank_transfer.png", bbox_inches="tight")
print("written", HERE / "wallet_to_bank_transfer.bpmn")
