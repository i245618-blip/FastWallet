# SLO / SLI and observability specification (Week 13)

Targets are synthetic design values from the Week 10 non-functional assumptions. Every SLI is backed by a
metric on `GET /metrics` (Prometheus text format) and shown on `GET /ops/dashboard`.

## Service level indicators and objectives
| SLI | Definition | Metric | Objective | Window | Alert when |
|---|---|---|---|---|---|
| Accept latency | Time to commit the transfer up to POSTED / HELD / FAILED, before the rail call | `fw_transfer_accept_seconds` (histogram) | p95 < 500 ms | 30 days | p95 > 500 ms for 10 min |
| Accept availability | Share of POST /v1/transfers answered without a 5xx | `fw_http_requests_total{route="/v1/transfers",status=~"5.."}` | ≥ 99.9 % | 30 days | burn rate > 14x over 1 h |
| End-to-end settlement time | INITIATED to SETTLED, from state history | `fw_settle_p95_seconds` | p95 ≤ 10 s | 24 h | p95 > 10 s |
| Unknown-outcome resolution | Age of the oldest PENDING transfer | `fw_transfers_pending_oldest_seconds` | < 15 min | instant | > 900 s |
| Stuck postings | POSTED with no outcome after 60 s | `fw_transfers_posted_stuck` | 0 | instant | > 0 for 5 min |
| Event delivery lag | Age of the oldest unpublished outbox event | `fw_outbox_lag_seconds` | < 5 s | instant | > 5 s for 5 min |
| Poison events | Open dead letters | `fw_dead_letters_open` | 0 | instant | > 0 |
| Reconciliation timeliness | Breaks past their due time | `fw_recon_breaks_overdue` | 0 | instant | > 0 |
| Compliance timeliness | Cases past their 4-hour target | v_ops_health.overdue_cases | 0 | instant | > 0 |
| Ledger integrity | Trial balance, projection and float invariant all hold | `fw_ledger_*_ok` | always 1 | instant | any 0 (page) |
| Audit completeness | Hash chain verifies; every denial recorded | `verify_audit_chain()`, `fw_audit_denials` | always intact | daily | chain_ok = false (page) |

## Logs
One JSON object per line with `ts`, `level`, `service`, `event`, `correlation_id`, plus event fields.
Business events: `transfer_created`, `transfer_state_changed`, `rail_call`, `recovery_attempt`,
`duplicate_rail_answer_ignored`, `posting_failed_after_rail_answer`, `notification_processed`,
`event_duplicate_ignored`, `event_dead_lettered`, `reconciliation_run`, `fault_injected`. Every request
also writes `http_request` with route, status, latency and whether it was an idempotent replay.
No names, mobile numbers, national IDs or beneficiary accounts are logged (checked by a test).

## Trace
The correlation ID is accepted from `X-Correlation-ID` (valid UUID only) or created by the gateway. It is
echoed in the response, stored on the transfer, journals, state history, every outbox event, rail
message log and audit rows, forwarded to the rail, and present on every log line. `v_transfer_lineage`
shows status, journals, state changes and events per transfer.

## Business transaction status
`GET /v1/transfers/{id}` is the authoritative status for the app. `fw_transfers_by_status` and the
dashboard chips show the count in each state.


## Week 14 additions
| SLI | Objective | Source |
|---|---|---|
| System account balances non-negative (1100, 2200) | always true | `fw_ledger_system_accounts_ok` |
| Requests refused by the rate limiter | watched, no target; spikes investigated | `fw_rate_limited_total`, `fw_rate_limited_last_hour` |
| Triage suggestions waiting for review | < 20, none older than 4 h | `fw_ai_awaiting_review` |
| Triage rejected by reviewers (override rate) | < 15 % per model version; above that, finance reviews the model | `fw_ai_rejected` / reviewed |
| Triage latency inside the service | p95 <= 50 ms | `fw_ai_triage_seconds` |
| Policy-guard blocks | 0 expected; any block is reviewed | `fw_ai_policy_guard_blocks_total` |
