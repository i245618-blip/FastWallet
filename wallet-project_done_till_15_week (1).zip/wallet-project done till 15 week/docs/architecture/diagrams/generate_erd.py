"""Draws the ERD views from the live database catalogue, so the diagrams cannot drift from the schema.

Usage: DATABASE_URL=postgresql://... python generate_erd.py   (needs Graphviz `dot` on the PATH)
Only a curated set of columns is drawn per table; every drawn column is checked against the database.
"""
import os
import subprocess
import psycopg2

VIEWS = {
    "erd_1_identity_wallet": ("Identity, consent, KYC and wallet", {
        "tier_policy": ["tier", "name", "can_send_to_bank", "per_txn_limit_minor", "daily_limit_minor"],
        "customer": ["customer_id", "customer_ref", "mobile_msisdn", "national_id_token", "kyc_tier", "status"],
        "consent_record": ["consent_id", "customer_id", "purpose", "notice_version", "granted_at", "withdrawn_at"],
        "kyc_decision": ["kyc_decision_id", "customer_id", "method", "result", "tier_granted", "watchlist_prescreen", "evidence"],
        "wallet": ["wallet_id", "customer_id", "ledger_account_id", "currency", "status"],
        "ledger_account": ["account_id", "code", "account_type", "normal_side", "allow_negative"],
    }, []),
    "erd_2_transfer_ledger_events": ("Transfer, ledger and events", {
        "wallet": ["wallet_id", "ledger_account_id"],
        "transfer": ["transfer_id", "transaction_reference", "source_wallet_id", "amount_minor", "status",
                     "correlation_id", "version"],
        "allowed_transition": ["from_status", "to_status"],
        "transfer_state_history": ["transfer_id", "sequence", "from_status", "to_status", "actor"],
        "idempotency_record": ["client_id", "idem_key", "request_hash", "state", "transfer_id"],
        "journal_entry": ["journal_id", "transfer_id", "journal_type", "reverses_journal_id"],
        "ledger_entry": ["entry_id", "journal_id", "leg_no", "account_id", "direction", "amount_minor"],
        "ledger_account": ["account_id", "code", "normal_side"],
        "account_balance": ["account_id", "balance_minor", "last_entry_id"],
        "rail_message_log": ["msg_id", "transfer_id", "rail_request_id", "operation", "outcome"],
        "outbox_event": ["event_id", "aggregate_id", "sequence", "event_type", "published_at"],
        "inbox_event": ["consumer_name", "event_id"],
        "dead_letter_event": ["dlq_id", "consumer_name", "event_id", "state"],
    }, [("transfer", "outbox_event", "aggregate_id (logical)")]),
    "erd_3_controls_recon_audit": ("Compliance, reversals, reconciliation and audit", {
        "transfer": ["transfer_id", "transaction_reference", "status"],
        "app_user": ["user_id", "username", "role"],
        "screening_rule": ["rule_id", "outcome_on_hit", "params"],
        "screening_decision": ["decision_id", "transfer_id", "outcome", "risk_score", "reason_codes", "inputs"],
        "compliance_case": ["case_id", "transfer_id", "decision_id", "state", "due_at"],
        "case_decision": ["case_decision_id", "case_id", "decision", "rationale", "decided_by"],
        "reversal_request": ["reversal_id", "original_transfer_id", "state", "requested_by", "decided_by"],
        "rail_statement_line": ["line_id", "statement_date", "rail_request_id", "amount_minor", "rail_status"],
        "recon_run": ["run_id", "statement_date", "matched_count"],
        "recon_match": ["run_id", "transfer_id", "rail_request_id"],
        "recon_break": ["break_id", "run_id", "break_type", "transfer_id", "statement_line_id", "state",
                        "owner_role", "resolved_by", "approved_by"],
        "break_policy": ["break_type", "default_owner_role", "sla_hours"],
        "audit_log": ["audit_id", "actor", "action", "outcome", "prev_hash", "row_hash"],
    }, [("transfer", "rail_statement_line", "transaction_reference = rail_request_id (logical)")]),
}

HEAD = {"erd_1_identity_wallet": "#1F3864", "erd_2_transfer_ledger_events": "#1F3864",
        "erd_3_controls_recon_audit": "#1F3864"}


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def load_catalogue(cur):
    cur.execute("""SELECT c.relname, a.attname, format_type(a.atttypid, a.atttypmod)
                     FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid
                    WHERE c.relnamespace = 'fw'::regnamespace AND c.relkind = 'r' AND a.attnum > 0 AND NOT a.attisdropped""")
    cols = {}
    for t, a, ty in cur.fetchall():
        cols.setdefault(t, {})[a] = ty
    cur.execute("""SELECT c.relname, a.attname FROM pg_constraint k JOIN pg_class c ON c.oid = k.conrelid
                     JOIN pg_attribute a ON a.attrelid = k.conrelid AND a.attnum = ANY (k.conkey)
                    WHERE k.contype = 'p' AND c.relnamespace = 'fw'::regnamespace""")
    pks = {(t, a) for t, a in cur.fetchall()}
    cur.execute("""SELECT c.relname, p.relname, a.attname FROM pg_constraint k
                     JOIN pg_class c ON c.oid = k.conrelid JOIN pg_class p ON p.oid = k.confrelid
                     JOIN pg_attribute a ON a.attrelid = k.conrelid AND a.attnum = ANY (k.conkey)
                    WHERE k.contype = 'f' AND c.relnamespace = 'fw'::regnamespace""")
    fks = cur.fetchall()
    return cols, pks, fks


def build_dot(title, tables, logical, cols, pks, fks):
    fk_cols = {(c, a) for c, _, a in fks}
    out = ['digraph G {',
           f'  graph [rankdir=LR, labelloc=t, label="{title}", fontname="Helvetica-Bold", fontsize=22, '
           'nodesep=0.3, ranksep=0.7, pad=0.3, bgcolor=white];',
           '  node [shape=plain, fontname="Helvetica", fontsize=14];',
           '  edge [color="#555555", arrowsize=0.8, fontname="Helvetica", fontsize=10];']
    for t, shown in tables.items():
        for c in shown:
            assert c in cols[t], f"{t}.{c} is not in the database"
        rows = []
        for c in shown:
            tag = "PK" if (t, c) in pks else ("FK" if (t, c) in fk_cols else "")
            tagcell = f'<FONT POINT-SIZE="11" COLOR="#7A1F1F">{tag}</FONT>' if tag else " "
            bold = "<B>" if tag == "PK" else ""
            unbold = "</B>" if tag == "PK" else ""
            rows.append(f'<TR><TD ALIGN="LEFT" WIDTH="26">{tagcell}</TD>'
                        f'<TD ALIGN="LEFT">{bold}{esc(c)}{unbold}</TD>'
                        f'<TD ALIGN="LEFT"><FONT POINT-SIZE="11" COLOR="#666666">{esc(cols[t][c])}</FONT></TD></TR>')
        out.append(f'  {t} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" COLOR="#444444">'
                   f'<TR><TD COLSPAN="3" BGCOLOR="{HEAD.get(title, "#1F3864")}"><FONT COLOR="white"><B>{t}</B></FONT></TD></TR>'
                   + "".join(rows) + '</TABLE>>];')
    seen = set()
    for child, parent, _ in fks:
        if child in tables and parent in tables and (parent, child) not in seen:
            seen.add((parent, child))
            out.append(f'  {parent} -> {child} [dir=both, arrowtail=tee, arrowhead=crow];')
    for a, b, label in logical:
        out.append(f'  {a} -> {b} [style=dashed, dir=both, arrowtail=tee, arrowhead=crow, label="{label}"];')
    out.append("}")
    return "\n".join(out)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    conn = psycopg2.connect(os.environ["DATABASE_URL"])
    cur = conn.cursor()
    cols, pks, fks = load_catalogue(cur)
    for name, (title, tables, logical) in VIEWS.items():
        dot_path = os.path.join(here, name + ".dot")
        open(dot_path, "w").write(build_dot(title, tables, logical, cols, pks, fks))
        subprocess.run(["dot", "-Tpng", "-Gdpi=140", dot_path, "-o", os.path.join(here, name + ".png")], check=True)
        print("wrote", name + ".png")


if __name__ == "__main__":
    main()
