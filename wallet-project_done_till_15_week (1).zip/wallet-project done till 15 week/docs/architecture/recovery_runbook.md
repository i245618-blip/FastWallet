# Recovery assumptions and runbook (Week 13, updated Week 14)

## Assumptions (proposed, synthetic)
| Item | Assumption | Basis |
|---|---|---|
| RPO, ledger and transfer state | 0 | Single PostgreSQL, synchronous commit; state, journal, history and outbox commit in one transaction |
| RPO, notifications | 0 lost, may be duplicated | Transactional outbox, at-least-once relay, inbox dedupe |
| RTO, API process | 15 min target; measured restart is in evidence/week13 | Stateless process; all truth is in the database |
| RTO, database restart | 15 min target; measured in evidence/week13 | Pooled connections found dead are discarded and the work restarts once (ADR-008) |
| RTO, full restore | 15 min target; drill measured 1.4 s for a 1613 KB database (1400 transfers) | `infra/backup_restore_drill.py`, evidence/week14/restore_drill.json |
| Unknown rail outcome | Resolved by enquiry within 15 min, else manual queue | Backoff 5 s, 15 s, 45 s, 2 min, 5 min |
| Backups | Logical dump drilled (RPO = dump interval). Nightly base backup plus WAL archiving is the production answer (RPO near 0) | WAL archiving not built in the local stack |

## Failure modes
| Failure | What the system does | Detection | Recovery | Test |
|---|---|---|---|---|
| Rail timeout after executing | Transfer PENDING, money in suspense 2200 | `fw_transfers_pending` | Worker enquires, posts settlement | `test_rail_timeout_sets_pending_and_enquires_not_replays` |
| Rail lost the request | PENDING | same | Enquiry says NOT_FOUND, safe resubmit with the same reference | `test_lost_request_is_resubmitted_only_after_rail_says_not_found` |
| Rail rejects | Compensating journal, REVERSED | `fw_transfers_total{status="REVERSED"}` | Automatic | `test_rail_rejection_compensates_the_wallet` |
| Rail never answers enquiries | PENDING kept; after 5 tries a RECOVERY_EXHAUSTED item for ops | `fw_ops_exceptions_open` | Analyst forces an enquiry or escalates | `test_recovery_backs_off_then_hands_over_to_a_person` |
| Our posting fails after the rail executed | Last committed state kept; rail answer logged; POSTING_FAILED item | `fw_posting_failures_total`, recon STATUS_MISMATCH | Worker settles; analyst resolves break MATCHED_LATE | `test_rail_executed_ledger_missing_is_reconciled_and_recovered` |
| API crash between posting and rail submit | Transfer POSTED, idempotency record replays POSTED | `fw_transfers_posted_stuck` | Worker enquires (NOT_FOUND) and submits once | `test_crash_between_posting_and_rail_submit_then_restart` |
| API killed at any time | Nothing lost | readiness probe | Restart | `test_state_survives_restart` |
| Database restart | Requests fail with 503 DEPENDENCY_UNAVAILABLE, nothing half-written | `/health/ready`, `fw_database_up` | Automatic on reconnect | `test_database_restart_is_survived` |
| Duplicate rail acknowledgement | Logged, ignored | `fw_rail_duplicate_acks_total` | None needed | `test_duplicate_rail_acknowledgements_are_ignored` |
| Duplicate or out-of-order event | Ignored by inbox / sequence check | `fw_events_consumed_total{result="DUPLICATE"}` | None needed | `test_consumer_ignores_duplicate_event_id` |
| Poison event | Dead-lettered | `fw_dead_letters_open` | `POST /v1/ops/dead-letters/{id}/replay` or `/discard` (ops, audited) | `test_dead_letter_replay_and_discard_are_controlled_and_audited` |
| Rail returns a transfer after it was reconciled | Customer credited (TRANSFER_RETURN), REVERSED, LATE_RETURN_AFTER_RECON item for finance | `fw_ops_exceptions_open` | Finance re-issues the closed-day report and resolves the item | `test_late_return_after_reconciliation_credits_customer_and_tells_finance` |
| Rail paid twice and will not return it | DUPLICATE break (finance) | `fw_recon_breaks_open` | Request return; if refused, write-off by two finance controllers posts RECON_ADJUSTMENT | `test_write_off_posts_adjustment_journal_with_four_eyes` |
| Database lost | Restore latest dump, run integrity checks, start API | `/health/ready`, `fw_database_up` | `infra/backup_restore_drill.py` steps | drill evidence |

## Operator steps
1. Check `/ops/dashboard`: pending, stuck, exception queue, open breaks, ledger controls.
2. For an item in the exception queue, run `POST /v1/transfers/{id}/status-enquiry` (ops_analyst).
3. If the rail confirms, the worker or the enquiry posts the linked journal; resolve any recon break with
   `MATCHED_LATE`. If the rail cannot answer, escalate to the rail operator; money stays in 2200.
4. Never edit transfer or ledger rows. Corrections are new linked journals posted through `ledger_post()`.
5. After any incident, verify the audit chain (`GET /v1/audit/verify`) and the four ledger gauges.
6. The triage assistant (`POST /v1/ai/triage`) may be asked for a first view of an item. It never acts; the
   analyst decides and acts through the normal endpoint. If it misbehaves, finance switches it off
   (`PUT /v1/ai/triage/config`), and this runbook continues unchanged.
