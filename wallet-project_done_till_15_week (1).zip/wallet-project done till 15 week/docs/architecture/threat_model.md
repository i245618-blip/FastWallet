# Threat model and risk-control matrix (Week 13)

Scope: the wallet-to-bank transfer as built in Week 13 — API gateway / Transaction Service, rules engine,
PostgreSQL (ledger, transfers, idempotency, outbox, audit), recovery worker, outbox relay, notification
consumer, reconciliation job and the mock rail. Method: STRIDE per element of the data-flow diagram
(`diagrams/threat_dfd.png`). Synthetic system; no real service was probed or tested.

## Assets
| Asset | Why it matters |
|---|---|
| Ledger entries and balances | Money. An error is a customer or company loss. |
| Transfer state and rail outcome | Decides whether money is shown as sent, pending or returned. |
| Idempotency records | Stop a retry from becoming a second debit. |
| Customer identity data (name, mobile, national ID token, KYC evidence) | Personal data; regulatory exposure. |
| Audit log | Evidence of who did what; must be complete and tamper-evident. |
| Secrets (JWT signing key, rail acknowledgement key, DB password) | Whoever holds them can impersonate users or the rail. |

## Trust boundaries
1. Internet → API gateway (customer app and back-office users, bearer tokens).
2. Rail → FastWallet (acknowledgement callback, HMAC-signed).
3. Services → database (each service switches to its own least-privilege role).
4. FastWallet → rail (outbound, 5-second budget, immutable request id).

## STRIDE analysis
| ID | STRIDE | Threat | Control in the build | Evidence (test) | Residual risk |
|---|---|---|---|---|---|
| T1 | Spoofing | Stolen or forged customer token used to send money | JWT signature, expiry and issuer checked on every call; second factor (`mfa`) required for every transfer (R09); denials audited | `test_missing_expired_and_forged_tokens_are_rejected_and_logged`, `test_second_factor_is_required_for_every_transfer` | Mock IdP uses a shared HS256 secret; production would use asymmetric keys from an IdP such as Keycloak |
| T2 | Spoofing | Forged rail acknowledgement marks a transfer settled or rejected | HMAC-SHA256 over the raw body, constant-time compare, audited on failure; acks can only apply legal transitions; reconciliation re-checks against the statement | `test_duplicate_rail_acknowledgements_are_ignored` | Key rotation not implemented |
| T3 | Tampering | Retry with the same key but a changed amount or beneficiary | SHA-256 request fingerprint stored with the key; mismatch returns 422 and is audited | `test_same_key_different_body_returns_422` | None identified |
| T4 | Tampering | Direct change to ledger, history or audit rows | Append-only triggers; no service role can write ledger tables; audit log is hash-chained | Week 12 append-only tests, `test_services_run_with_least_privilege_database_roles`, audit-chain test | A database superuser can still bypass triggers; detected by `verify_audit_chain()` |
| T5 | Tampering | Double spend through concurrent requests | Idempotency row lock, `FOR UPDATE` on the transfer, overdraft trigger, one journal per type per transfer | `test_concurrent_requests_with_one_key_create_one_transfer`, Week 12 overdraft test | Not load-tested beyond the local run in evidence/week13 |
| T6 | Repudiation | Officer or approver denies a decision | `case_decision` and `reversal_request` store the user id, time and rationale; append-only; audit row per decision | `test_compliance_hold_then_officer_release`, `test_reversal_needs_maker_checker_and_rail_confirmed_return` | Staff identity comes from the mock IdP |
| T7 | Information disclosure | Personal data leaks into logs, events or messages | Logs carry references only; event schema forbids extra fields and holds only `customer_ref`; SMS text masks the mobile and omits the beneficiary account | `test_logs_are_structured_json_without_personal_data`, Week 12 event-schema test | API responses to the customer include the beneficiary they entered (by design) |
| T8 | Information disclosure | Customer reads another customer's transfer or wallet (IDOR) | Ownership check on every read and on the source wallet; 404 rather than 403 so existence is not revealed | `test_customer_sees_only_their_own_transfers`, `test_customer_cannot_send_from_someone_elses_wallet` | None identified |
| T9 | Information disclosure | Secrets committed to the repository | All secrets from environment variables; `.env` is git-ignored; template has placeholders; API refuses to start with a missing or short JWT secret | `infra/.env.example`, `security.py` | No vault integration (would be the production choice) |
| T10 | Denial of service | Slow or unavailable rail ties up the service | 5-second client timeout; non-definitive answers become PENDING; recovery runs in the worker, not in the request | `test_rail_timeout_sets_pending_and_enquires_not_replays`, `test_rail_unavailable_before_executing_is_recovered` | No API rate limiting yet (`RATE_LIMITED` code is reserved); single database |
| T11 | Denial of service | Malformed event blocks the notification consumer | Schema validation first; failures go to `dead_letter_event`; relay continues | `test_poison_event_goes_to_dead_letter` | DLQ replay is manual |
| T12 | Elevation of privilege | Analyst approves own reversal or releases a held transfer | Role check at the gateway and again inside the database (`assert_role`, SoD trigger) | `test_unauthorised_role_attempt_is_denied_and_logged`, Week 12 SoD tests | None identified |
| T13 | Elevation of privilege | A compromised service is used to move money | Each service runs as its own DB role; notification, relay and reporting cannot write transfers or ledger | `test_services_run_with_least_privilege_database_roles` | Services share one login user locally; production would give each its own login |
| T14 | Elevation of privilege | Test fault-injection endpoint abused in a real deployment | Endpoint answers 404 unless `FW_ENABLE_FAULT_INJECTION=1`; default off | `test_fault_injection_is_off_unless_explicitly_enabled` | Operator error in configuration |
| T15 | Tampering / spoofing | Log injection through the correlation header | Header accepted only if it is a valid UUID; logs are JSON-encoded | `test_correlation_id_flows_from_request_to_events_audit_and_logs` | None identified |

## Risk-control matrix
Likelihood and impact are team judgements on a 1-3 scale for the synthetic system.

| Risk | L | I | Preventive control | Detective control | Corrective control | Owner |
|---|---|---|---|---|---|---|
| Double debit on retry or timeout | 3 | 3 | Idempotency key + request hash; immutable rail request id; enquiry before resubmit | Recon DUPLICATE break; `fw_idempotent_replays_total` | Return request to the rail, linked reversal | Transaction Service |
| Money shown as sent but rail did not execute (or the reverse) | 2 | 3 | PENDING on any unknown answer; single `apply_outcome` path | Recon STATUS_MISMATCH; pending-age SLI | Recovery worker posts the missing linked journal | Ops analyst |
| Rail executed, our posting failed (partial failure) | 2 | 3 | Rail answer logged before it is applied | POSTING_FAILED exception; `fw_posting_failures_total`; recon break | Recovery worker settles; analyst resolves break | Finance controller |
| Unauthorised money movement | 2 | 3 | JWT + 2FA, ownership checks, RBAC at API and DB | Audit denials, `fw_auth_denials_total` | Freeze wallet (status), reversal | Security / ops |
| Release of a sanctioned or fraudulent transfer | 2 | 3 | Rules R01-R10; officer-only release with rationale | Open-case and overdue-case gauges | Reject case; compliance report | Compliance officer |
| Personal data exposure | 2 | 2 | Column grants, masking, schema-restricted events | Log scan test in CI | Rotate and purge | Data owner |
| Lost events / missed notifications | 2 | 1 | Transactional outbox; at-least-once relay | Outbox-lag SLI; DLQ gauge | Replay from outbox / DLQ | Ops analyst |
| Ledger corruption | 1 | 3 | Balanced-journal and overdraft triggers; append-only | Trial-balance, projection and float gauges | Rebuild projection from entries | Finance controller |


## Week 14 additions
| ID | Threat | Control | Test |
|---|---|---|---|
| T16 | Triage assistant moves money or closes a control item | Role `fw_ai` holds exactly three grants; catalogue has no money or control action; review executes nothing | `test_assistant_role_cannot_touch_money_or_controls`, `test_assistant_role_holds_exactly_its_three_grants` |
| T17 | Personal data reaches the assistant or its output | Input view without personal columns; policy guard scans every output | `test_triage_suggests_from_the_catalogue_and_records_everything`, guard test |
| T18 | Staff over-trust a confident but wrong suggestion | Mandatory human review; abstention on material, sanctions, missing evidence and low confidence; override rate on the dashboard | `test_an_abstention_cannot_be_accepted`, offline evaluation |
| T19 | Retry storm or stolen token floods the API | Rate limit per subject, first refusal audited | `test_rate_limit_returns_429_with_retry_after_and_audits_once` |
| T20 | Write-off used to hide a loss | Loss only, second finance approver, linked journal, float control counts it | `test_write_off_posts_adjustment_journal_with_four_eyes` |

| Risk | L | I | Preventive control | Detective control | Corrective control | Owner |
|---|---|---|---|---|---|---|
| Wrong AI suggestion acted on | 2 | 2 | Advisory only, abstention, review | Rejected-suggestion count, offline metrics per model version | Kill switch (finance), raise threshold | Finance controller |
| Late rail return after a closed day | 2 | 2 | Signed acknowledgement only; linked TRANSFER_RETURN | LATE_RETURN_AFTER_RECON item | Finance re-issues the closed-day report | Finance controller |
