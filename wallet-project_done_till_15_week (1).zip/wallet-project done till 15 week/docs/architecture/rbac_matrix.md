# Role-based access matrix (Week 13)

Enforced twice: by the API gateway (`authorise()` in `src/fastwallet/api.py`) on every call, and by the
database (service roles, `assert_role()`, the segregation-of-duties triggers). Every denial is written to
the hash-chained audit log and counted in `fw_auth_denials_total`.

## API operations by role
| Operation | customer | ops_analyst | compliance_officer | finance_controller | system_recovery |
|---|---|---|---|---|---|
| POST /v1/transfers | Own wallet, 2FA required | - | - | - | - |
| GET /v1/transfers, /v1/transfers/{id} | Own only (404 otherwise) | All | All | All | All |
| POST /v1/transfers/{id}/status-enquiry | - | Yes | - | - | Yes |
| POST /v1/transfers/{id}/reversals (maker) | - | Yes | - | - | - |
| POST /v1/reversals/{id}/approval (checker) | - | - | - | Yes, not the maker | - |
| GET /v1/compliance/cases | - | - | Yes | - | - |
| POST /v1/compliance/cases/{id}/decision | - | - | Yes (checked again in DB) | - | - |
| POST /v1/reconciliation/runs | - | Yes | - | Yes | - |
| GET /v1/reconciliation/breaks | - | Yes | - | Yes | - |
| POST /v1/reconciliation/breaks/{id}/resolution | - | Owner role only (DB) | - | Yes; write-off needs a second controller | - |
| GET /v1/ops/exceptions, /v1/ops/health-summary, /ops/dashboard | - | Yes | - | Yes | - |
| GET /v1/reports/settlement | - | - | - | Yes | - |
| GET /v1/audit/verify | - | - | - | Yes | - |
| POST /internal/rail/acks | Rail only, HMAC signature | | | | |

## Database roles used by the running services
| Service | Role | Can | Cannot |
|---|---|---|---|
| API / Transaction Service, recovery worker | fw_txn | Insert/update transfers, cases, reversals, idempotency; post via `ledger_post()`; write audit via `audit()`; raise exceptions | Insert journals or ledger rows; change balances; read name, mobile, national ID token, KYC evidence |
| Reconciliation job | fw_recon | Import statement lines; run and resolve through functions | Edit transfers directly |
| Notification consumer | fw_notify | Read events, consent, contact columns; write inbox, DLQ, notification log | Touch transfers, ledger, national ID token; read back the inbox |
| Outbox relay | fw_relay | Read outbox; set `published_at`, `publish_attempts` | Change a payload |
| Reporting, dashboard, metrics | fw_report | Read views; verify audit chain | Read any table |

## Segregation of duties
| Pair | Rule | Enforced by |
|---|---|---|
| Reversal maker / checker | Different people; maker is ops_analyst, checker is finance_controller | API role check + `reversal_request_guard` trigger |
| Write-off resolver / approver | Different finance controllers | `resolve_break()` |
| Screening engine / officer | Engine can only HOLD; release needs an active compliance officer with a rationale | `case_decision_guard` trigger |
| Customer / staff | Staff tokens cannot create transfers; customers cannot reach back-office operations | API role check |


## Week 14 operations
| Operation | customer | ops_analyst | compliance_officer | finance_controller | system_recovery | fw_ai (assistant) |
|---|---|---|---|---|---|---|
| Resolve exception-queue item | - | Owner only | - | Yes | - | - |
| Replay or discard dead letter | - | Yes | - | - | - | - |
| Request triage suggestion | - | Yes | - | Yes | - | Writes the suggestion only |
| Review suggestion (accept/reject) | - | Yes | - | Yes | - | No |
| Switch assistant off / change threshold | - | - | - | Yes | - | No |
| Approve write-off (posts journal) | - | - | - | Second controller only | - | No |
