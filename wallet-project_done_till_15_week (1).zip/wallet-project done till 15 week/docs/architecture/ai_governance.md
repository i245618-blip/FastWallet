# Exception-triage assistant: governance specification (Week 14)
Decision record: ADR-007. Code: `src/fastwallet/triage.py`. Evaluation: `infra/ai_triage_eval.py`.

## Purpose
Give the operations analyst or finance controller a first view of an open exception or reconciliation
break: a plain summary and one recommended next step with a confidence. It shortens analysis; it never acts.

## Allowed tools and data
| Allowed | Detail |
|---|---|
| Read `v_triage_item` | Item kind, owner, age, transaction reference, status and reason, amounts, enquiry count, last rail answer, statement line counts, journal types, compliance flag, screening reason codes |
| Read `ai_triage_config` | On/off, model version, abstention threshold, materiality threshold |
| Insert into `ai_triage_suggestion` | Append-only; cannot read back, update or delete |
| Write audit rows through `audit()` | Every suggestion |

## Prohibited actions (enforced, not just documented)
Moving money, posting or approving journals, approving write-offs or reversals, releasing or rejecting
compliance holds, KYC or sanctions decisions, changing beneficiaries, resubmitting to the rail, closing breaks
or exceptions, reading names, mobile numbers, national id tokens, beneficiary accounts or customer references.
Enforced by the `fw_ai` grants (three, checked by a test), the fixed catalogue (database CHECK constraint)
and the policy guard.

## Catalogue
| Action | Tier | Who carries it out |
|---|---|---|
| RUN_STATUS_ENQUIRY | Routine | Ops analyst |
| WAIT_FOR_AUTOMATED_RECOVERY | Routine | Ops analyst |
| RESOLVE_AS_MATCHED_LATE | Routine | Ops analyst |
| REQUEST_RAIL_CORRECTION | Routine | Finance controller |
| ESCALATE_FINANCE_REVIEW | Escalation | Finance controller |
| ESCALATE_COMPLIANCE_REVIEW | Escalation | Compliance officer |
| HUMAN_ANALYSIS_REQUIRED | Abstention | Owner of the item |

## Abstention rules
Material amount (>= Rs 150,000, same as R10); sanctions or compliance related (R07 or an open case);
missing transfer evidence; unknown pattern; confidence below 0.70. The policy guard turns any output that
breaks a rule into an abstention and counts it.

## Human approval boundary
Every non-abstained suggestion waits for a person (ops analyst or finance controller) to accept or reject it
with a comment. Acceptance is a record, not an action: the step is then taken through its own endpoint
under the person's role and controls (four eyes, maker-checker, officer-only release). An abstention cannot
be accepted. The kill switch and the threshold are finance-controller only.

## Audit logging
Each suggestion stores inputs, input hash, model version, output, confidence, abstention reason, latency,
requester and correlation id, and writes an audit row. Reviews and configuration changes are audited.
Rows are append-only (triggers) and covered by the audit hash chain.

## Evaluation (offline, 240 labelled synthetic cases)
| Metric | Target | Result |
|---|---|---|
| False approval rate | <= 2 % | 1.7 % (4 cases) |
| False escalation rate (of routine cases) | <= 25 % | 4.9 % |
| Resolution accuracy (answered cases) | >= 90 % | 97.1 % |
| Policy violations | 0 | 0 |
| Material / sanctions / incomplete cases abstained | all | 30 of 30 |
| Abstention rate | reported | 15.0 % |
| Decision latency p95 | <= 50 ms | 0.041 ms |

The false approvals all come from facts the assistant cannot see (for example a return the bank announced
by phone). Raising the threshold does not remove them (see the sweep in evidence/week14/ai_triage_eval.json),
which is the reason human review is mandatory.

## Monitoring in operation
Dashboard tiles and metrics: awaiting review, accepted, rejected, abstained, guard blocks, latency.
A rejection rate above 15 % for a model version, or any guard block, triggers a finance review and, if
needed, the kill switch. A new model version is evaluated offline on the same set before it is enabled.
