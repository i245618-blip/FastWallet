# Final evidence pack (Week 15)
Produced by one command on a fresh database: `DATABASE_URL=... FW_EVIDENCE_DIR=evidence/week15 ./infra/reproduce.sh`

| File | What it shows |
|---|---|
| pytest_output.txt | 95 automated tests, all passing |
| demo_run_1-3.txt, rehearsal_run_1-3.json | Final demonstration run three times, every check passing |
| demo_run_output.txt | Demonstration output used as the fallback during the defence |
| load_c*_*.json | Five load runs; latency, throughput, 0 server errors, ledger controls and audit chain true after each |
| ai_triage_eval.json | Triage assistant metrics, threshold sweep and sample disagreements |
| restore_drill.json | Backup and restore drill: RTO, identical copy, controls and audit chain on the restored database |

Earlier evidence: evidence/week12 (data layer), evidence/week13 (prototype, resilience, dashboards, logs,
metrics), evidence/week14 (review gate, Postman/Newman run, mutation check, dashboard after the demo).
