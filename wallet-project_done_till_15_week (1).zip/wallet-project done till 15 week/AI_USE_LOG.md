# AI Use Log

| Date | Tool | Task / prompt summary | Output used | Verification done | Rejected / changed |
|---|---|---|---|---|---|
