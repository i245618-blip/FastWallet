# FastWallet - wallet-to-bank transfer reference architecture
CS3017 Enterprise Systems and Applications, Semester Project, Fall 2026

FastWallet is a fictional wallet provider. Everything here is a proposed reference architecture built from
public information and synthetic data. It does not describe the internal systems of SadaPay, NayaPay or any
other firm, and nothing in the repository talks to a real payment service.

## Problem
A customer moves money from a wallet to a bank account (IBAN or Raast ID) over an instant-payment rail. The
system must stay correct when the rail times out, answers twice or fails halfway, and finance must be able
to reconcile every transfer against the rail statement. The rail is mocked locally.

## Architecture in short
A channel calls an API gateway, which passes the request to the Transaction Service. The service screens the
transfer (KYC/AML rules), posts to a double-entry ledger, submits to the rail, and records every state change
together with an outgoing event in one database transaction. Notification, reconciliation and reporting work
from those events and from the database. PostgreSQL holds transfers, ledger, idempotency keys, outbox and
audit data. Details are in the Word documents in `docs/milestones/`, the diagrams in
`docs/architecture/diagrams/` and the decision records in `docs/architecture/adr/`.

## Status
| Milestone | State |
|---|---|
| Week 10: journey, scope, API and event contracts, idempotency | Done |
| Week 12: data model, source of truth, ledger, reconciliation, KYC/AML controls | Done, data layer built and tested |
| Week 13: prototype, failure/resilience, security/observability | Done: services, mock rail, rules engine, worker, 78 tests |
| Week 14: architecture review: ADRs complete, demo rehearsed, AI extension bounded, repository reproducible | Done: 94 tests, ADR-001 to ADR-010, BPMN, triage assistant, one-command reproduction |
| Week 15: final defence | Repository, dossier, evidence pack, review deck, viva |

## Repository map
| Path | Contents |
|---|---|
| `docs/milestones/` | Week 10, 12, 13, 14 and 15 submissions (Word), architecture brief, review deck |
| `docs/architecture/` | ADR-001 to ADR-010, BPMN model, diagrams, threat model, RBAC matrix, SLO/SLI spec, recovery runbook, AI governance |
| `docs/demo/` | Demonstration talk track and rehearsal record |
| `src/fastwallet/` | API gateway / transaction service, rules engine, mock rail, worker, notification, reconciliation, triage assistant |
| `api/` | `openapi.yaml`, the event schema and the Postman collection |
| `src/db/` | PostgreSQL schema: tables, integrity rules, reconciliation, reference data, roles, Week 13 and Week 14 additions |
| `data/` | Synthetic seed data, demo helpers and the reconciliation scenario script |
| `tests/` | pytest suite: Week 12 data layer (38), Week 13 services (40), Week 14 review gate (17) |
| `infra/` | Docker Compose, configuration template, demo, load test, AI evaluation, restore drill, one-command reproduction |
| `evidence/` | Test output, demo runs, load results, AI evaluation, restore drill, mutation checks, Postman run |
| `AI_USE_LOG.md` | Generative-AI use log |

## Setup, test and demo
Needs PostgreSQL 16 (local or via Docker) and Python 3.10 or newer.

One command, from a clean checkout to every piece of evidence (tests, three demo runs, AI evaluation, load
runs, restore drill), written to `evidence/week14`:
```
DATABASE_URL=postgresql://fw:fw@localhost:5432/fw ./infra/reproduce.sh
```
Step by step:
```
pip install -r requirements.txt
export TEST_DATABASE_URL=postgresql://fw:fw@localhost:5432/fw
pytest -q                                    # 95 tests; service tests start the API and mock rail themselves

export DATABASE_URL=$TEST_DATABASE_URL
export FW_JWT_SECRET=<32+ random chars> FW_RAIL_ACK_SECRET=<32+ random chars>
./infra/run_demo.sh                          # final demo, seven segments (docs/demo/demo_script.md)
./infra/run_load.sh evidence/week14          # load runs (fresh database)
python infra/ai_triage_eval.py --sweep       # triage assistant evaluation
python infra/backup_restore_drill.py         # full-restore drill
```
Full stack in containers: `cp infra/.env.example infra/.env` (set the two secrets), then
`docker compose -f infra/docker-compose.yml --env-file infra/.env up -d --build`. API on :8000
(`/metrics`, `/ops/dashboard`), mock rail on :8100. Local tokens: `python -m fastwallet.tokens --sub CUST-0004 --role customer --mfa`.

The tests drop and recreate the `fw` schema, so point them at a disposable database.
Set `FW_TEST_PG_RESTART_CMD` (for example `pg_ctlcluster 16 main restart`) to include the database-restart test.

## Rules for working in this repository
- Synthetic data only. No real CNIC, account, card, wallet or credential data in code, data, screenshots or logs.
- No call to any real payment, bank or identity service.
- No secrets in the repository.
