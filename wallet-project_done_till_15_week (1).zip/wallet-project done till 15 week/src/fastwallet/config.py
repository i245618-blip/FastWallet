"""Runtime configuration, read from environment variables only (no secrets in code)."""
import os
from dataclasses import dataclass, field


def _f(name, default):
    return float(os.environ.get(name, default))


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: os.environ.get(
        "DATABASE_URL", "postgresql://fw:fw@localhost:5432/fw"))
    jwt_secret: str = field(default_factory=lambda: os.environ.get("FW_JWT_SECRET", ""))
    rail_url: str = field(default_factory=lambda: os.environ.get("FW_RAIL_URL", "http://localhost:8100"))
    rail_ack_secret: str = field(default_factory=lambda: os.environ.get("FW_RAIL_ACK_SECRET", ""))
    # ADR-001: the rail round trip is capped at 5 seconds, anything slower becomes PENDING
    rail_timeout_seconds: float = field(default_factory=lambda: _f("FW_RAIL_TIMEOUT_SECONDS", 5))
    # Week 10 section 8.3: enquiry backoff 5 s, 15 s, 45 s, 2 min, 5 min, then manual queue
    backoff_schedule: tuple = (5, 15, 45, 120, 300)
    backoff_scale: float = field(default_factory=lambda: _f("FW_BACKOFF_SCALE", 1))
    # a POSTED transfer with no rail outcome after this long is treated as stuck (crash after posting)
    stuck_posted_seconds: float = field(default_factory=lambda: _f("FW_STUCK_POSTED_SECONDS", 30))
    # Week 14, ADR-008: connections per process (0 = no pool, one connection per unit of work as in Week 13)
    db_pool_size: int = field(default_factory=lambda: int(os.environ.get("FW_DB_POOL_SIZE", "20")))
    db_pool_wait_seconds: float = field(default_factory=lambda: _f("FW_DB_POOL_WAIT_SECONDS", 5))
    log_file: str = field(default_factory=lambda: os.environ.get("FW_LOG_FILE", ""))
    service_name: str = field(default_factory=lambda: os.environ.get("FW_SERVICE_NAME", "fw-api"))
    # fault injection is for the resilience tests only and is refused unless explicitly enabled
    fault_injection: bool = field(default_factory=lambda: os.environ.get("FW_ENABLE_FAULT_INJECTION") == "1")


settings = Settings()
