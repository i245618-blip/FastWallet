"""Transaction Service core: create, screen, post, submit, apply rail outcomes, recover, decide.

Rules that hold everywhere in this module
  * A state change, its ledger posting, its state-history row and its outbox event commit together
    (the triggers in 02_integrity.sql write history and outbox; ledger_post() writes the journal).
  * The rail is called only outside a database transaction, with a 5-second budget. Any answer that is
    not definitive (timeout, 5xx, unreachable) leaves the transfer PENDING. Blind replay is never done:
    a resubmission happens only after a status enquiry says the rail has never seen the request.
  * Every rail answer is logged in rail_message_log in its own transaction before it is applied, so the
    evidence survives even when applying it fails (partial failure).
  * apply_outcome() is the single place where a rail answer changes state, whether the answer came from
    the inline submit, a rail acknowledgement, a status enquiry or an approved reversal.
"""
import hashlib
import json
import os
import time

import psycopg2

from . import db, rail_client
from .config import settings
from .errors import ApiError, problem_body
from .observability import (ACCEPT_LATENCY, IDEMPOTENCY_REJECTS, IDEMPOTENT_REPLAYS, POSTING_FAILURES, RAIL_DUPLICATE_ACKS,
                            RECOVERY, TRANSFERS, current_correlation_id, log_event)
from .rules import evaluate

FAULTS: set = set()          # active fault-injection points (tests only, see api.py /internal/faults)


def fault(point: str):
    if settings.fault_injection and point in FAULTS:
        log_event("fault_injected", point=point)
        if point == "crash_after_post":
            os._exit(137)            # simulate a process crash between commit and rail submission
        raise RuntimeError(f"FAULT_INJECTED: {point}")


# ---------------------------------------------------------------- helpers

def request_hash(method: str, path: str, body: dict) -> str:
    canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(f"{method} {path} {canonical}".encode()).hexdigest()


def audit(cur, actor, role, action, otype, oid, outcome, details=None):
    cur.execute("SELECT audit(%s, %s, %s, %s, %s, %s, %s, %s)",
                (actor, role, action, otype, str(oid) if oid else None, outcome,
                 current_correlation_id(), json.dumps(details) if details is not None else None))


def audit_denied(actor, role, action, otype=None, oid=None, details=None):
    """Denials are audited in their own transaction so the record survives the rollback of the request."""
    try:
        with db.tx("fw_txn", actor or "anonymous") as cur:
            audit(cur, actor or "anonymous", role, action, otype, oid, "DENIED", details)
    except psycopg2.Error as exc:
        log_event("audit_write_failed", level=40, action=action, error=str(exc)[:200])


def snapshot(cur, transfer_id) -> dict:
    cur.execute("""SELECT transfer_id, transaction_reference, status::text, status_reason, amount_minor,
                          beneficiary_scheme, beneficiary_identifier, beneficiary_name, rail_reference,
                          created_at, updated_at, correlation_id
                     FROM transfer WHERE transfer_id = %s""", (transfer_id,))
    t = cur.fetchone()
    if not t:
        raise ApiError(404, "NOT_FOUND", "transfer not found")
    body = {
        "transfer_id": str(t["transfer_id"]), "transaction_reference": t["transaction_reference"],
        "status": t["status"], "amount": {"currency": "PKR", "minor_units": t["amount_minor"]},
        "beneficiary": {"scheme": t["beneficiary_scheme"], "identifier": t["beneficiary_identifier"],
                        "name": t["beneficiary_name"]},
        "created_at": t["created_at"].isoformat(), "updated_at": t["updated_at"].isoformat(),
        "correlation_id": str(t["correlation_id"]),
    }
    if t["status_reason"]:
        body["status_reason"] = t["status_reason"]
    if t["rail_reference"]:
        body["rail_reference"] = t["rail_reference"]
    return body


def staff_user_id(cur, username: str):
    cur.execute("SELECT user_id FROM app_user WHERE username = %s AND active", (username,))
    row = cur.fetchone()
    if not row:
        raise ApiError(403, "FORBIDDEN_ROLE", "no active staff account for this subject")
    return row["user_id"]


def claim_idempotency(cur, client_id, key, req_hash, actor, role, action):
    """Week 10 section 8.1. Returns None when this request owns the key, else the response to replay.

    The IN_PROGRESS row is inserted in the same transaction as the business change. A concurrent request
    with the same key blocks on the primary key until the first one commits, then sees COMPLETED.
    """
    cur.execute("""INSERT INTO idempotency_record (client_id, idem_key, request_hash, state)
                   VALUES (%s, %s, %s, 'IN_PROGRESS') ON CONFLICT DO NOTHING RETURNING idem_key""",
                (client_id, key, req_hash))
    if cur.fetchone():
        return None
    cur.execute("SELECT * FROM idempotency_record WHERE client_id = %s AND idem_key = %s", (client_id, key))
    rec = cur.fetchone()
    if rec["request_hash"].strip() != req_hash:
        IDEMPOTENCY_REJECTS.inc()
        audit_denied(actor, role, action + "_KEY_REUSED", "idempotency_key", key)
        raise ApiError(422, "IDEMPOTENCY_KEY_REUSED", "same key, different request body")
    if rec["state"] != "COMPLETED":
        raise ApiError(409, "REQUEST_IN_PROGRESS", "retry later", headers={"Retry-After": "1"})
    IDEMPOTENT_REPLAYS.inc()
    return rec["response_status"], rec["response_body"]


def complete_idempotency(cur, client_id, key, status, body, transfer_id=None):
    cur.execute("""UPDATE idempotency_record SET state = 'COMPLETED', response_status = %s,
                          response_body = %s, transfer_id = %s
                    WHERE client_id = %s AND idem_key = %s""",
                (status, json.dumps(body), transfer_id, client_id, key))


def _sync_stored_response(cur, transfer_id):
    """Keep the stored response of a create-transfer key equal to the latest known status."""
    cur.execute("""UPDATE idempotency_record SET response_body = %s
                    WHERE transfer_id = %s AND response_status = 202 AND response_body ? 'transaction_reference'""",
                (json.dumps(snapshot(cur, transfer_id)), transfer_id))


def _post_or_fail(cur, transfer_id) -> str:
    """AUTHORISED -> POSTED, or FAILED when the wallet cannot cover it. Returns the new status."""
    cur.execute("SAVEPOINT post_attempt")
    try:
        cur.execute("SELECT ledger_post(%s, 'TRANSFER_POST')", (transfer_id,))
        cur.execute("UPDATE transfer SET status = 'POSTED', status_reason = NULL WHERE transfer_id = %s",
                    (transfer_id,))
        cur.execute("RELEASE SAVEPOINT post_attempt")
        return "POSTED"
    except psycopg2.Error as exc:
        if db.db_error_token(exc) != "INSUFFICIENT_FUNDS":
            raise
        cur.execute("ROLLBACK TO SAVEPOINT post_attempt")
        cur.execute("UPDATE transfer SET status = 'FAILED', status_reason = 'INSUFFICIENT_FUNDS' "
                    "WHERE transfer_id = %s", (transfer_id,))
        return "FAILED"


# ---------------------------------------------------------------- create

def create_transfer(principal, body: dict, idem_key: str):
    """POST /v1/transfers. Returns (http_status, response_body, replayed)."""
    actor = principal.sub
    if not principal.mfa:                                   # R09, SBP two-factor rule
        audit_denied(actor, "customer", "TRANSFER_CREATE_NO_SECOND_FACTOR", "wallet", body["source_wallet_id"])
        raise ApiError(401, "STEP_UP_REQUIRED", "complete the second factor and retry with the same key")

    h = request_hash("POST", "/v1/transfers", body)
    corr = current_correlation_id()
    started = time.perf_counter()
    with db.tx("fw_txn", actor) as cur:
        replay = claim_idempotency(cur, principal.client_id, idem_key, h, actor, "customer", "TRANSFER_CREATE")
        if replay:
            return replay[0], replay[1], True

        cur.execute("""SELECT w.wallet_id, w.status AS wallet_status, c.customer_id, c.customer_ref,
                              c.status AS customer_status
                         FROM wallet w JOIN customer c USING (customer_id) WHERE w.wallet_id = %s""",
                    (body["source_wallet_id"],))
        w = cur.fetchone()
        if not w or w["customer_ref"] != principal.sub:
            raise ApiError(404, "NOT_FOUND", "wallet not found")       # never reveal other customers' wallets
        if w["wallet_status"] != "ACTIVE" or w["customer_status"] != "ACTIVE":
            raise ApiError(422, "INVALID_STATE_TRANSITION", "wallet or customer is not active")
        cur.execute("""SELECT 1 FROM consent_record WHERE customer_id = %s AND purpose = 'TRANSACTION_PROCESSING'
                         AND withdrawn_at IS NULL""", (w["customer_id"],))
        if not cur.fetchone():
            raise ApiError(422, "CONSENT_REQUIRED", "TRANSACTION_PROCESSING consent is missing or withdrawn")

        b = body["beneficiary"]
        cur.execute("""INSERT INTO transfer (client_id, source_wallet_id, beneficiary_scheme, beneficiary_identifier,
                                             beneficiary_name, amount_minor, purpose, customer_note, correlation_id)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING transfer_id, transaction_reference""",
                    (principal.client_id, w["wallet_id"], b["scheme"], b["identifier"], b.get("name"),
                     body["amount"]["minor_units"], body["purpose"], body.get("customer_note"), corr))
        t = cur.fetchone()
        tid, ref = t["transfer_id"], t["transaction_reference"]

        d = evaluate(cur, tid, w["customer_id"], w["wallet_id"], body["amount"]["minor_units"],
                     b["identifier"], b.get("name"), second_factor=True)
        cur.execute("""INSERT INTO screening_decision (transfer_id, customer_id, rules_version, outcome, risk_score,
                                                       reason_codes, inputs)
                       VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING decision_id""",
                    (tid, w["customer_id"], d.rules_version, d.outcome, d.risk_score, d.reason_codes,
                     json.dumps(d.inputs)))
        decision_id = cur.fetchone()["decision_id"]

        if d.outcome == "BLOCK":
            cur.execute("UPDATE transfer SET status = 'FAILED', status_reason = %s WHERE transfer_id = %s",
                        ("LIMIT_EXCEEDED:" + ",".join(d.reason_codes), tid))
            status, resp = 422, problem_body(422, "LIMIT_EXCEEDED", "blocked by " + ", ".join(d.reason_codes),
                                             {"transfer_id": str(tid), "transaction_reference": ref,
                                              "reason_codes": d.reason_codes})
        elif d.outcome == "HOLD":
            cur.execute("UPDATE transfer SET status = 'HELD', status_reason = 'COMPLIANCE_HOLD' WHERE transfer_id = %s",
                        (tid,))
            cur.execute("INSERT INTO compliance_case (transfer_id, decision_id) VALUES (%s, %s)", (tid, decision_id))
            status, resp = 202, snapshot(cur, tid)
        else:
            cur.execute("UPDATE transfer SET status = 'AUTHORISED' WHERE transfer_id = %s", (tid,))
            if _post_or_fail(cur, tid) == "POSTED":
                status, resp = 202, snapshot(cur, tid)
            else:
                status, resp = 422, problem_body(422, "INSUFFICIENT_FUNDS", "wallet balance is too low",
                                                 {"transfer_id": str(tid), "transaction_reference": ref})

        complete_idempotency(cur, principal.client_id, idem_key, status, resp, tid)
        audit(cur, actor, "customer", "TRANSFER_CREATE", "transfer", tid, "ALLOWED",
              {"reference": ref, "screening": d.outcome, "reasons": d.reason_codes})
        new_status = snapshot(cur, tid)["status"]

    ACCEPT_LATENCY.observe(time.perf_counter() - started)
    TRANSFERS.labels(new_status).inc()
    log_event("transfer_created", transaction_reference=ref, status=new_status, screening=d.outcome,
              reasons=d.reason_codes, customer_ref=principal.sub)
    if new_status == "POSTED":
        fault("crash_after_post")
        return 202, submit_and_apply(tid), False
    return status, resp, False


# ---------------------------------------------------------------- rail interaction

def _log_rail(transfer_id, ref, operation, outcome, payload=None):
    with db.tx("fw_txn", "transaction-service") as cur:
        cur.execute("""INSERT INTO rail_message_log (transfer_id, rail_request_id, operation, outcome, payload,
                                                     correlation_id) VALUES (%s, %s, %s, %s, %s, %s)""",
                    (transfer_id, ref, operation, outcome, json.dumps(payload or {}), current_correlation_id()))


def _load(transfer_id):
    with db.tx("fw_txn", "transaction-service") as cur:
        cur.execute("""SELECT transfer_id, transaction_reference, status::text, amount_minor, beneficiary_scheme,
                              beneficiary_identifier, correlation_id, updated_at
                         FROM transfer WHERE transfer_id = %s""", (transfer_id,))
        return cur.fetchone()


def submit_and_apply(transfer_id) -> dict:
    t = _load(transfer_id)
    _log_rail(transfer_id, t["transaction_reference"], "SUBMIT", "SENT")
    result = rail_client.submit(t["transaction_reference"], t["amount_minor"], t["beneficiary_scheme"],
                                t["beneficiary_identifier"])
    return apply_outcome_safely(transfer_id, result, "submit")


def apply_outcome_safely(transfer_id, result: dict, source: str) -> dict:
    """Log the rail answer, then apply it. If applying fails, the answer stays logged, the transfer keeps its
    last committed state, an exception is queued and the recovery worker retries later."""
    t = _load(transfer_id)
    op = "ACK" if source in ("submit", "ack") else "ENQUIRY_RESULT"
    _log_rail(transfer_id, t["transaction_reference"], op, result.get("status", "UNKNOWN"), result)
    try:
        apply_outcome(transfer_id, result, source)
    except Exception as exc:  # noqa: BLE001 - any failure here is a partial failure we must survive
        POSTING_FAILURES.inc()
        log_event("posting_failed_after_rail_answer", level=40, transaction_reference=t["transaction_reference"],
                  rail_status=result.get("status"), error=str(exc)[:200])
        raise_exception(transfer_id, "POSTING_FAILED", "finance_controller",
                        f"rail said {result.get('status')} but posting failed: {str(exc)[:120]}")
    with db.tx("fw_txn", "transaction-service") as cur:
        return snapshot(cur, transfer_id)


def raise_exception(transfer_id, kind, owner, detail):
    with db.tx("fw_txn", "transaction-service") as cur:
        cur.execute("""INSERT INTO ops_exception (transfer_id, kind, owner_role, detail, correlation_id)
                       VALUES (%s, %s, %s, %s, %s) ON CONFLICT (transfer_id, kind) WHERE state = 'OPEN' DO NOTHING""",
                    (transfer_id, kind, owner, detail, current_correlation_id()))


def apply_outcome(transfer_id, result: dict, source: str) -> str:
    rail_status = result.get("status", "UNKNOWN")
    actor = {"submit": "transaction-service", "ack": "rail-ack", "enquiry": "recovery-worker",
             "reversal": "reversal-approval"}.get(source, source)
    with db.tx("fw_txn", actor) as cur:
        cur.execute("SELECT status::text, transaction_reference FROM transfer WHERE transfer_id = %s FOR UPDATE",
                    (transfer_id,))
        row = cur.fetchone()
        status, ref = row["status"], row["transaction_reference"]
        new = status

        if rail_status == "EXECUTED":
            if status in ("POSTED", "PENDING"):
                fault("fail_settle")
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_SETTLE')", (transfer_id,))
                reason = "RECOVERED_BY_ENQUIRY" if source == "enquiry" else None
                cur.execute("UPDATE transfer SET status = 'SETTLED', rail_reference = %s, status_reason = %s "
                            "WHERE transfer_id = %s", (result.get("rail_reference"), reason, transfer_id))
                cur.execute("""UPDATE ops_exception SET state = 'RESOLVED', resolved_by = %s, resolved_at = now()
                                WHERE transfer_id = %s AND state = 'OPEN' AND kind = 'POSTING_FAILED'""",
                            (actor, transfer_id))
                new = "SETTLED"
            elif status in ("SETTLED", "RECONCILED"):
                RAIL_DUPLICATE_ACKS.inc()
                log_event("duplicate_rail_answer_ignored", transaction_reference=ref, status=status, source=source)
            else:
                _conflict(cur, transfer_id, f"rail EXECUTED but transfer is {status}")

        elif rail_status == "REJECTED":
            if status in ("POSTED", "PENDING"):
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_REVERSE')", (transfer_id,))
                cur.execute("UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_REJECTED' "
                            "WHERE transfer_id = %s", (transfer_id,))
                new = "REVERSED"
            elif status == "REVERSED":
                RAIL_DUPLICATE_ACKS.inc()
            else:
                _conflict(cur, transfer_id, f"rail REJECTED but transfer is {status}")

        elif rail_status == "RETURNED":
            if status == "SETTLED":
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_RETURN')", (transfer_id,))
                cur.execute("UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_RETURN' "
                            "WHERE transfer_id = %s", (transfer_id,))
                cur.execute("UPDATE reversal_request SET state = 'POSTED' WHERE original_transfer_id = %s "
                            "AND state = 'APPROVED'", (transfer_id,))
                new = "REVERSED"
            elif status == "REVERSED":
                RAIL_DUPLICATE_ACKS.inc()
            elif status in ("POSTED", "PENDING"):           # settle first, then return
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_SETTLE')", (transfer_id,))
                cur.execute("UPDATE transfer SET status = 'SETTLED', rail_reference = %s WHERE transfer_id = %s",
                            (result.get("rail_reference"), transfer_id))
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_RETURN')", (transfer_id,))
                cur.execute("UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_RETURN' "
                            "WHERE transfer_id = %s", (transfer_id,))
                new = "REVERSED"
            elif status == "RECONCILED":
                # Week 14 rule (ADR-010): the rail's return is the evidence, so the customer is credited now and
                # finance is told, because the day this transfer belonged to was already reconciled and closed.
                cur.execute("SELECT ledger_post(%s, 'TRANSFER_RETURN')", (transfer_id,))
                cur.execute("UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_RETURN_AFTER_RECON' "
                            "WHERE transfer_id = %s", (transfer_id,))
                cur.execute("UPDATE reversal_request SET state = 'POSTED' WHERE original_transfer_id = %s "
                            "AND state = 'APPROVED'", (transfer_id,))
                cur.execute("""INSERT INTO ops_exception (transfer_id, kind, owner_role, detail, correlation_id)
                               VALUES (%s, 'LATE_RETURN_AFTER_RECON', 'finance_controller', %s, %s)
                               ON CONFLICT (transfer_id, kind) WHERE state = 'OPEN' DO NOTHING""",
                            (transfer_id, f"rail returned {ref} after it was reconciled; closed day changed",
                             current_correlation_id()))
                new = "REVERSED"
            else:
                _conflict(cur, transfer_id, f"rail RETURNED but transfer is {status}")

        elif rail_status == "UNKNOWN":
            if status == "POSTED":
                cur.execute("UPDATE transfer SET status = 'PENDING', status_reason = %s WHERE transfer_id = %s",
                            (result.get("reason", "RAIL_TIMEOUT"), transfer_id))
                new = "PENDING"

        if new != status:
            _sync_stored_response(cur, transfer_id)
            log_event("transfer_state_changed", transaction_reference=ref, from_status=status, to_status=new,
                      source=source)
    if new != status:
        TRANSFERS.labels(new).inc()
    return new


def _conflict(cur, transfer_id, detail):
    cur.execute("""INSERT INTO ops_exception (transfer_id, kind, owner_role, detail, correlation_id)
                   VALUES (%s, 'RAIL_OUTCOME_CONFLICT', 'finance_controller', %s, %s)
                   ON CONFLICT (transfer_id, kind) WHERE state = 'OPEN' DO NOTHING""",
                (transfer_id, detail, current_correlation_id()))
    log_event("rail_outcome_conflict", level=30, detail=detail)


# ---------------------------------------------------------------- recovery (status enquiry, never blind replay)

def recover_transfer(transfer_id, force: bool = False) -> str:
    t = _load(transfer_id)
    if t["status"] not in ("POSTED", "PENDING"):
        return "NOTHING_TO_DO"
    with db.tx("fw_txn", "recovery-worker") as cur:
        cur.execute("""SELECT count(*) AS n, max(logged_at) AS last,
                              extract(epoch FROM now() - coalesce(max(logged_at), %s)) AS since
                         FROM rail_message_log WHERE transfer_id = %s AND operation = 'ENQUIRY'""",
                    (t["updated_at"], transfer_id))
        e = cur.fetchone()
    attempts, since = int(e["n"]), float(e["since"])
    schedule = settings.backoff_schedule
    if not force:
        if attempts >= len(schedule):
            raise_exception(transfer_id, "RECOVERY_EXHAUSTED", "ops_analyst",
                            f"{attempts} status enquiries without a definitive answer")
            RECOVERY.labels("EXHAUSTED").inc()
            return "EXHAUSTED"
        if since < schedule[attempts] * settings.backoff_scale:
            return "NOT_DUE"

    _log_rail(transfer_id, t["transaction_reference"], "ENQUIRY", "SENT", {"attempt": attempts + 1})
    result = rail_client.enquire(t["transaction_reference"])
    if result.get("status") == "NOT_FOUND":
        # The rail has never seen this request id, so sending it now cannot pay twice. The reference is the
        # same immutable one, and the rail deduplicates on it.
        _log_rail(transfer_id, t["transaction_reference"], "ENQUIRY_RESULT", "NOT_FOUND")
        _log_rail(transfer_id, t["transaction_reference"], "SUBMIT", "RESUBMIT_AFTER_NOT_FOUND")
        result = rail_client.submit(t["transaction_reference"], t["amount_minor"], t["beneficiary_scheme"],
                                    t["beneficiary_identifier"])
        source_result = "RESUBMITTED"
    else:
        source_result = result.get("status", "UNKNOWN")
    snap = apply_outcome_safely(transfer_id, result, "enquiry")
    RECOVERY.labels(source_result).inc()
    log_event("recovery_attempt", transaction_reference=t["transaction_reference"], attempt=attempts + 1,
              rail_answer=source_result, status=snap["status"])
    return snap["status"]


def recover_all() -> dict:
    with db.tx("fw_txn", "recovery-worker") as cur:
        cur.execute("""SELECT transfer_id FROM transfer
                        WHERE status = 'PENDING'
                           OR (status = 'POSTED' AND updated_at < now() - make_interval(secs => %s))
                        ORDER BY updated_at""", (settings.stuck_posted_seconds,))
        ids = [r["transfer_id"] for r in cur.fetchall()]
    results = {}
    for tid in ids:
        results[str(tid)] = recover_transfer(tid)
    return results


# ---------------------------------------------------------------- compliance decision (human control)

def decide_case(principal, case_id, decision, rationale, idem_key):
    h = request_hash("POST", f"/v1/compliance/cases/{case_id}/decision", {"decision": decision, "rationale": rationale})
    with db.tx("fw_txn", principal.sub) as cur:
        replay = claim_idempotency(cur, principal.client_id, idem_key, h, principal.sub, principal.role,
                                   "CASE_DECISION")
        if replay:
            return replay[0], replay[1], True
        user_id = staff_user_id(cur, principal.sub)
        cur.execute("SELECT case_id, transfer_id, state FROM compliance_case WHERE case_id = %s FOR UPDATE", (case_id,))
        case = cur.fetchone()
        if not case:
            raise ApiError(404, "NOT_FOUND", "case not found")
        if case["state"] != "OPEN":
            raise ApiError(422, "INVALID_STATE_TRANSITION", f"case is already {case['state']}")
        cur.execute("INSERT INTO case_decision (case_id, decision, rationale, decided_by) VALUES (%s, %s, %s, %s)",
                    (case_id, decision, rationale, user_id))      # the database checks the officer role itself
        tid = case["transfer_id"]
        if decision == "RELEASE":
            cur.execute("UPDATE transfer SET status = 'AUTHORISED', status_reason = 'RELEASED_BY_OFFICER' "
                        "WHERE transfer_id = %s", (tid,))
            _post_or_fail(cur, tid)
        else:
            cur.execute("UPDATE transfer SET status = 'FAILED', status_reason = 'COMPLIANCE_REJECTED' "
                        "WHERE transfer_id = %s", (tid,))
        audit(cur, principal.sub, "compliance_officer", "CASE_DECISION", "compliance_case", case_id, "ALLOWED",
              {"decision": decision})
        resp = {"case_id": str(case_id), "decision": decision, "transfer": snapshot(cur, tid)}
        complete_idempotency(cur, principal.client_id, idem_key, 200, resp, tid)
    if resp["transfer"]["status"] == "POSTED":
        resp["transfer"] = submit_and_apply(tid)
    return 200, resp, False


# ---------------------------------------------------------------- reversal (maker / checker)

def _reversal_body(cur, reversal_id):
    cur.execute("""SELECT r.reversal_id, r.original_transfer_id, r.state, r.reason_code, r.requested_at,
                          ru.username AS requested_by, du.username AS decided_by
                     FROM reversal_request r JOIN app_user ru ON ru.user_id = r.requested_by
                     LEFT JOIN app_user du ON du.user_id = r.decided_by WHERE r.reversal_id = %s""", (reversal_id,))
    r = cur.fetchone()
    return {"reversal_id": str(r["reversal_id"]), "original_transfer_id": str(r["original_transfer_id"]),
            "state": r["state"], "reason_code": r["reason_code"], "requested_by": r["requested_by"],
            "decided_by": r["decided_by"], "created_at": r["requested_at"].isoformat()}


def request_reversal(principal, transfer_id, reason_code, reason_text, idem_key):
    h = request_hash("POST", f"/v1/transfers/{transfer_id}/reversals",
                     {"reason_code": reason_code, "reason_text": reason_text})
    with db.tx("fw_txn", principal.sub) as cur:
        replay = claim_idempotency(cur, principal.client_id, idem_key, h, principal.sub, principal.role,
                                   "REVERSAL_REQUEST")
        if replay:
            return replay[0], replay[1], True
        user_id = staff_user_id(cur, principal.sub)
        st = snapshot(cur, transfer_id)["status"]
        if st not in ("SETTLED", "RECONCILED"):
            raise ApiError(422, "INVALID_STATE_TRANSITION",
                           f"only SETTLED or RECONCILED transfers can be reversed by request (found {st})")
        cur.execute("""INSERT INTO reversal_request (original_transfer_id, reason_code, reason_text, requested_by)
                       VALUES (%s, %s, %s, %s) RETURNING reversal_id""",
                    (transfer_id, reason_code, reason_text, user_id))
        rid = cur.fetchone()["reversal_id"]
        audit(cur, principal.sub, principal.role, "REVERSAL_REQUEST", "transfer", transfer_id, "ALLOWED",
              {"reversal_id": str(rid), "reason_code": reason_code})
        body = _reversal_body(cur, rid)
        complete_idempotency(cur, principal.client_id, idem_key, 201, body, transfer_id)
    return 201, body, False


def decide_reversal(principal, reversal_id, decision, comment, idem_key):
    """Approval never moves money by itself. The compensating journal is posted only when the rail confirms
    the funds came back (RETURNED); until then the request stays APPROVED."""
    h = request_hash("POST", f"/v1/reversals/{reversal_id}/approval", {"decision": decision, "comment": comment})
    with db.tx("fw_txn", principal.sub) as cur:
        replay = claim_idempotency(cur, principal.client_id, idem_key, h, principal.sub, principal.role,
                                   "REVERSAL_DECISION")
        if replay:
            return replay[0], replay[1], True
        user_id = staff_user_id(cur, principal.sub)
        cur.execute("SELECT original_transfer_id, state FROM reversal_request WHERE reversal_id = %s FOR UPDATE",
                    (reversal_id,))
        r = cur.fetchone()
        if not r:
            raise ApiError(404, "NOT_FOUND", "reversal not found")
        if r["state"] != "PENDING_APPROVAL":
            raise ApiError(422, "INVALID_STATE_TRANSITION", f"reversal is already {r['state']}")
        new_state = "APPROVED" if decision == "APPROVE" else "REJECTED"
        cur.execute("UPDATE reversal_request SET state = %s, decided_by = %s, decided_at = now() "
                    "WHERE reversal_id = %s", (new_state, user_id, reversal_id))   # SoD checked by the database
        audit(cur, principal.sub, principal.role, "REVERSAL_DECISION", "reversal", reversal_id, "ALLOWED",
              {"decision": decision, "comment": comment})
        tid = r["original_transfer_id"]
        body = _reversal_body(cur, reversal_id)
        complete_idempotency(cur, principal.client_id, idem_key, 200, body, tid)
    if new_state == "APPROVED":
        _log_rail(tid, _load(tid)["transaction_reference"], "ENQUIRY", "SENT", {"purpose": "reversal"})
        result = rail_client.enquire(_load(tid)["transaction_reference"])
        if result.get("status") == "RETURNED":
            apply_outcome_safely(tid, result, "reversal")
        with db.tx("fw_txn", principal.sub) as cur:
            body = _reversal_body(cur, reversal_id)
            body["transfer"] = snapshot(cur, tid)
            if body["state"] == "APPROVED":
                body["note"] = "approved; ledger posting waits for the rail to confirm the return"
    return 200, body, False
