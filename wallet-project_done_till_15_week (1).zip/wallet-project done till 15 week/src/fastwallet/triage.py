"""Exception-triage assistant (bounded AI extension, ADR-007).

What it does: reads one open item from the operations exception queue or the reconciliation break list,
summarises it in plain words and recommends one next step from a fixed catalogue, with a confidence.
A person then accepts or rejects the suggestion. Accepting changes nothing by itself: the person still
carries out the step through the normal endpoint, under their own role, with the normal controls.

What it cannot do, by construction:
  * It runs as database role fw_ai, which can read v_triage_item and ai_triage_config and insert into
    ai_triage_suggestion. It cannot touch transfers, the ledger, breaks, cases, reversals or users.
  * Its catalogue has no money-moving, write-off, hold-release, KYC or beneficiary action.
  * v_triage_item holds references, statuses, amounts, counts and reason codes only. No names, mobile
    numbers, national id tokens, beneficiary accounts or customer references.

The decision model is deterministic (guidelines section 7 allows a mock AI decision service): weighted
evidence per catalogue action, turned into probabilities with a softmax. It abstains when the case is
material, sanctions-related, missing evidence, or when its confidence is below the configured threshold.
An independent policy guard checks every output before it is stored.
"""
import datetime as dt
import hashlib
import json
import uuid
import math
import re
import time

from . import db
from .errors import ApiError
from .observability import AI_GUARD_BLOCKS, AI_LATENCY, AI_SUGGESTIONS, current_correlation_id, log_event

ACTIONS = {
    # action                        tier         who would carry it out
    "RUN_STATUS_ENQUIRY":          ("ROUTINE",   "ops_analyst"),
    "WAIT_FOR_AUTOMATED_RECOVERY": ("ROUTINE",   "ops_analyst"),
    "RESOLVE_AS_MATCHED_LATE":     ("ROUTINE",   "ops_analyst"),
    "REQUEST_RAIL_CORRECTION":     ("ROUTINE",   "finance_controller"),
    "ESCALATE_FINANCE_REVIEW":     ("ESCALATE",  "finance_controller"),
    "ESCALATE_COMPLIANCE_REVIEW":  ("ESCALATE",  "compliance_officer"),
}
ABSTAIN = "HUMAN_ANALYSIS_REQUIRED"
# Never produced. Listed so the policy guard and the tests can check for them explicitly.
PROHIBITED = {"APPROVE_WRITE_OFF", "POST_JOURNAL", "RELEASE_HOLD", "REJECT_HOLD", "APPROVE_REVERSAL",
              "OVERRIDE_KYC", "CLEAR_SANCTIONS_MATCH", "CHANGE_BENEFICIARY", "RESUBMIT_TO_RAIL"}
PII_PATTERNS = [re.compile(r"PK\d{2}[A-Z0-9]{4}\d{6,}"), re.compile(r"\b03\d{9}\b"), re.compile(r"CUST-\d{4}"),
                re.compile(r"\b[0-9a-f]{64}\b")]

INPUT_FIELDS = ("item_type", "kind", "owner_role", "state", "age_minutes", "transaction_reference", "transfer_status",
                "status_reason", "transfer_age_minutes", "amount_minor", "internal_amount_minor",
                "external_amount_minor", "enquiry_attempts", "last_rail_outcome", "statement_executed_lines",
                "statement_returned", "journals", "has_compliance_case", "screening_reasons", "detail")
NEEDS_TRANSFER = {"UNMATCHED_INTERNAL", "STATUS_MISMATCH", "AMOUNT_MISMATCH", "DUPLICATE", "MISSING",
                  "RECOVERY_EXHAUSTED", "POSTING_FAILED", "RAIL_OUTCOME_CONFLICT", "LATE_RETURN_AFTER_RECON"}


# ---------------------------------------------------------------- the decision model (pure functions)

def evidence(f: dict) -> dict:
    """Weighted evidence for each catalogue action. Weights were set from the recovery runbook."""
    k, st = f.get("kind"), f.get("transfer_status")
    last = f.get("last_rail_outcome")
    ext, internal = f.get("external_amount_minor"), f.get("internal_amount_minor")
    age, t_age = f.get("age_minutes") or 0, f.get("transfer_age_minutes") or 0
    journals = set(f.get("journals") or [])
    executed = f.get("statement_executed_lines") or 0
    returned = bool(f.get("statement_returned"))
    w = {a: 0.0 for a in ACTIONS}

    if k == "UNMATCHED_INTERNAL":
        if st in ("POSTED", "PENDING"):
            w["RUN_STATUS_ENQUIRY"] += 2.5
            if st == "PENDING" and t_age < 15:
                w["WAIT_FOR_AUTOMATED_RECOVERY"] += 2.2
        elif st in ("SETTLED", "RECONCILED"):
            w["ESCALATE_FINANCE_REVIEW"] += 2.0            # we settled, the rail has no line: needs evidence
            w["RUN_STATUS_ENQUIRY"] += 1.2
    elif k == "STATUS_MISMATCH":
        if st in ("SETTLED", "RECONCILED") and executed >= 1 and not returned:
            w["RESOLVE_AS_MATCHED_LATE"] += 3.0
        if st == "REVERSED" and (returned or last in ("REJECTED", "RETURNED")):
            w["RESOLVE_AS_MATCHED_LATE"] += 2.5
        if st in ("POSTED", "PENDING") and (executed >= 1 or last == "EXECUTED"):
            w["RUN_STATUS_ENQUIRY"] += 2.0
            w["WAIT_FOR_AUTOMATED_RECOVERY"] += 1.0
        if st == "REVERSED" and executed >= 1 and not returned:
            w["ESCALATE_FINANCE_REVIEW"] += 3.0            # we gave the money back but the rail paid out
        if st in ("SETTLED", "RECONCILED") and returned:
            w["ESCALATE_FINANCE_REVIEW"] += 1.5
            w["RUN_STATUS_ENQUIRY"] += 1.5
    elif k == "AMOUNT_MISMATCH":
        if ext is not None and internal is not None and ext > internal:
            w["ESCALATE_FINANCE_REVIEW"] += 3.0            # a loss: only finance can decide a write-off
        elif ext is not None and internal is not None and ext < internal:
            w["REQUEST_RAIL_CORRECTION"] += 2.6
    elif k == "DUPLICATE":
        if executed > 1:
            w["REQUEST_RAIL_CORRECTION"] += 3.0
        w["ESCALATE_FINANCE_REVIEW"] += 0.8
    elif k == "UNMATCHED_EXTERNAL":
        w["ESCALATE_COMPLIANCE_REVIEW"] += 3.0
        w["ESCALATE_FINANCE_REVIEW"] += 1.0
    elif k == "MISSING":
        w["ESCALATE_FINANCE_REVIEW"] += 3.0
    elif k == "POSTING_FAILED":
        if age < 30:
            w["WAIT_FOR_AUTOMATED_RECOVERY"] += 2.5
        else:
            w["ESCALATE_FINANCE_REVIEW"] += 2.2
            w["RUN_STATUS_ENQUIRY"] += 1.0
    elif k == "RECOVERY_EXHAUSTED":
        if t_age < 240:
            w["RUN_STATUS_ENQUIRY"] += 2.4
        else:
            w["ESCALATE_FINANCE_REVIEW"] += 2.4
            w["RUN_STATUS_ENQUIRY"] += 0.8
    elif k == "RAIL_OUTCOME_CONFLICT":
        w["ESCALATE_FINANCE_REVIEW"] += 2.8
    elif k == "LATE_RETURN_AFTER_RECON":
        if "TRANSFER_RETURN" in journals and st == "REVERSED":
            w["ESCALATE_FINANCE_REVIEW"] += 2.6            # finance acknowledges the change to a closed day
        else:
            w["ESCALATE_FINANCE_REVIEW"] += 1.0
    return w


TEMPERATURE = 0.6      # sharpens the evidence into probabilities; set with the threshold on the evaluation set


def softmax(w: dict, temperature: float = TEMPERATURE) -> dict:
    m = max(w.values())
    e = {a: math.exp((v - m) / temperature) for a, v in w.items()}
    s = sum(e.values())
    return {a: v / s for a, v in e.items()}


def summarise(f: dict) -> str:
    def rs(v):
        return "n/a" if v is None else f"Rs {v / 100:,.2f}"
    parts = [f"{f.get('kind')} on {f.get('transaction_reference') or 'no internal transfer'}"]
    if f.get("transfer_status"):
        parts.append(f"internal status {f['transfer_status']}")
    parts.append(f"last rail answer {f.get('last_rail_outcome') or 'none'}")
    parts.append(f"{f.get('statement_executed_lines') or 0} executed statement line(s)"
                 + (", rail shows a return" if f.get("statement_returned") else ""))
    if f.get("internal_amount_minor") is not None or f.get("external_amount_minor") is not None:
        parts.append(f"ours {rs(f.get('internal_amount_minor'))} vs rail {rs(f.get('external_amount_minor'))}")
    elif f.get("amount_minor") is not None:
        parts.append(f"amount {rs(f['amount_minor'])}")
    parts.append(f"{f.get('enquiry_attempts') or 0} status enquiries so far")
    parts.append(f"open {f.get('age_minutes') or 0} min, owner {f.get('owner_role')}")
    return "; ".join(parts) + "."


def decide(f: dict, abstain_below: float, material_minor: int) -> dict:
    """Return the suggestion for one item (no database access). Deterministic for the same input."""
    probs = softmax(evidence(f))
    best = max(probs, key=probs.get)
    conf = round(probs[best], 3)
    reason = None
    amount = max(f.get("amount_minor") or 0, f.get("external_amount_minor") or 0, f.get("internal_amount_minor") or 0)
    if amount >= material_minor:
        reason = "MATERIAL_AMOUNT"
    elif f.get("has_compliance_case") or "R07" in (f.get("screening_reasons") or []):
        reason = "SANCTIONS_OR_COMPLIANCE_RELATED"
    elif f.get("kind") in NEEDS_TRANSFER and not f.get("transaction_reference"):
        reason = "INCOMPLETE_EVIDENCE"
    elif max(evidence(f).values()) <= 0:
        reason = "UNKNOWN_PATTERN"
    elif conf < abstain_below:
        reason = "LOW_CONFIDENCE"
    ranked = sorted(probs.items(), key=lambda kv: -kv[1])[:3]
    return {
        "category": f.get("kind") or "UNKNOWN",
        "recommended_action": ABSTAIN if reason else best,
        "confidence": conf,
        "abstained": bool(reason),
        "abstain_reason": reason,
        "summary": summarise(f),
        "evidence": {"ranked": [{"action": a, "probability": round(p, 3)} for a, p in ranked],
                     "would_be_owner": ACTIONS[best][1], "tier": ACTIONS[best][0]},
    }


def policy_guard(s: dict, f: dict, material_minor: int) -> list:
    """Independent checks on the output. Returns the list of violations (empty = allowed)."""
    v = []
    action = s["recommended_action"]
    if action in PROHIBITED or (action not in ACTIONS and action != ABSTAIN):
        v.append("ACTION_NOT_IN_CATALOGUE")
    if s["abstained"] != (action == ABSTAIN):
        v.append("ABSTENTION_INCONSISTENT")
    amount = max(f.get("amount_minor") or 0, f.get("external_amount_minor") or 0, f.get("internal_amount_minor") or 0)
    if amount >= material_minor and not s["abstained"]:
        v.append("MATERIAL_CASE_NOT_ABSTAINED")
    if "R07" in (f.get("screening_reasons") or []) and not s["abstained"]:
        v.append("SANCTIONS_CASE_NOT_ABSTAINED")
    text = s["summary"] + json.dumps(s["evidence"])
    if any(p.search(text) for p in PII_PATTERNS):
        v.append("PERSONAL_DATA_IN_OUTPUT")
    return v


def input_hash(f: dict) -> str:
    return hashlib.sha256(json.dumps(f, sort_keys=True, default=str).encode()).hexdigest()


# ---------------------------------------------------------------- service (runs as fw_ai)

def _features(row: dict) -> dict:
    out = {}
    for k in INPUT_FIELDS:
        v = row.get(k)
        out[k] = list(v) if isinstance(v, (list, tuple)) else v
    return out


def triage(item_type: str, item_id: str, requested_by: str) -> dict:
    started = time.perf_counter()
    with db.tx("fw_ai", "ai.triage") as cur:
        cur.execute("SELECT enabled, model_version, abstain_below, material_amount_minor FROM ai_triage_config")
        cfg = cur.fetchone()
        if not cfg["enabled"]:
            raise ApiError(503, "AI_DISABLED", "the triage assistant is switched off; continue with the manual runbook")
        cur.execute("SELECT * FROM v_triage_item WHERE item_type = %s AND item_id::text = %s", (item_type, item_id))
        row = cur.fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", "no open exception or break with this id")
        f = _features(row)
        s = decide(f, float(cfg["abstain_below"]), cfg["material_amount_minor"])
        violations = policy_guard(s, f, cfg["material_amount_minor"])
        if violations:                       # never store an output that breaks policy; hand it to a person
            AI_GUARD_BLOCKS.inc()
            s.update(recommended_action=ABSTAIN, abstained=True, abstain_reason="POLICY_GUARD:" + ",".join(violations))
        latency_ms = round((time.perf_counter() - started) * 1000, 2)
        h = input_hash(f)
        # id and time are made here: fw_ai may insert suggestions but not read them back (no RETURNING)
        ins = {"suggestion_id": uuid.uuid4(), "created_at": dt.datetime.now(dt.timezone.utc)}
        cur.execute("""INSERT INTO ai_triage_suggestion (suggestion_id, item_type, item_id, model_version, input_hash, inputs,
                                                          category, recommended_action, confidence, abstained,
                                                          abstain_reason, summary, evidence, latency_ms, requested_by,
                                                          correlation_id, created_at)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (ins["suggestion_id"], item_type, item_id, cfg["model_version"], h, json.dumps(f, default=str),
                     s["category"], s["recommended_action"], s["confidence"], s["abstained"], s["abstain_reason"],
                     s["summary"], json.dumps(s["evidence"]), latency_ms, requested_by, current_correlation_id(),
                     ins["created_at"]))
        cur.execute("SELECT audit(%s, %s, 'AI_TRIAGE_SUGGESTION', 'ai_triage_suggestion', %s, 'ALLOWED', %s, %s)",
                    ("ai.triage", "ai_assistant", str(ins["suggestion_id"]), current_correlation_id(),
                     json.dumps({"item_type": item_type, "item_id": item_id, "action": s["recommended_action"],
                                 "confidence": s["confidence"], "abstained": s["abstained"],
                                 "model_version": cfg["model_version"], "input_hash": h,
                                 "requested_by": requested_by})))
    AI_SUGGESTIONS.labels("ABSTAINED" if s["abstained"] else s["recommended_action"]).inc()
    AI_LATENCY.observe(latency_ms / 1000)
    log_event("ai_triage_suggestion", item_type=item_type, action=s["recommended_action"],
              confidence=s["confidence"], abstained=s["abstained"], model_version=cfg["model_version"])
    return {"suggestion_id": str(ins["suggestion_id"]), "item_type": item_type, "item_id": item_id,
            "model_version": cfg["model_version"], "input_hash": h, "latency_ms": latency_ms,
            "created_at": ins["created_at"].isoformat(), "advisory_only": True, **s}
