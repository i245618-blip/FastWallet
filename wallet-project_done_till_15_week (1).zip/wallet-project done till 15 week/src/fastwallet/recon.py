"""Reconciliation job: import the rail statement for a date, then run reconciliation (fw_recon role)."""
from . import db, rail_client
from .observability import log_event


def import_statement(statement_date: str) -> int:
    lines = rail_client.statement(statement_date)
    source = f"rail-statement-{statement_date}.json"
    new = 0
    with db.tx("fw_recon", "recon-service") as cur:
        # Week 14: intraday statements. A line already imported (same date, request id, status and rail
        # reference) is skipped, so re-importing a day only adds what is new and never doubles a line.
        for ln in lines:
            cur.execute("""SELECT 1 FROM rail_statement_line WHERE statement_date = %s AND rail_request_id = %s
                             AND rail_status = %s AND rail_reference IS NOT DISTINCT FROM %s""",
                        (statement_date, ln["request_id"], ln["rail_status"], ln.get("rail_reference")))
            if cur.fetchone():
                continue
            new += 1
            cur.execute("""INSERT INTO rail_statement_line (statement_date, rail_request_id, rail_reference,
                                                            amount_minor, rail_status, source_file)
                           VALUES (%s, %s, %s, %s, %s, %s)""",
                        (statement_date, ln["request_id"], ln.get("rail_reference"), ln["amount_minor"],
                         ln["rail_status"], source))
    log_event("statement_imported", statement_date=statement_date, lines=new)
    return new


def run(statement_date: str, run_by: str = "recon-service", stuck_after_seconds: int = 1800) -> dict:
    imported = import_statement(statement_date)
    with db.tx("fw_recon", run_by) as cur:
        cur.execute("SELECT run_reconciliation(%s, %s, make_interval(secs => %s)) AS run_id",
                    (statement_date, run_by, stuck_after_seconds))
        run_id = cur.fetchone()["run_id"]
        cur.execute("SELECT matched_count, new_break_count FROM recon_run WHERE run_id = %s", (run_id,))
        r = cur.fetchone()
        cur.execute("SELECT audit(%s, 'recon', 'RECON_RUN', 'recon_run', %s, 'ALLOWED', NULL, NULL)",
                    (run_by, str(run_id)))
    out = {"run_id": str(run_id), "statement_date": statement_date, "lines_imported": imported,
           "matched": r["matched_count"], "new_breaks": r["new_break_count"]}
    log_event("reconciliation_run", **out)
    return out
