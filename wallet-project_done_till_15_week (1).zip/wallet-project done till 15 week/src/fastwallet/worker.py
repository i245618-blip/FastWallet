"""Background worker: outbox relay + recovery of PENDING / stuck POSTED transfers.

    python -m fastwallet.worker            # loop forever (Docker service "worker")
    python -m fastwallet.worker --once     # one pass, used by the demo script
"""
import argparse
import time

import time as _time

from . import db, events, transfers
from .observability import log_event, set_correlation_id

_last_purge = 0.0


def run_once() -> dict:
    global _last_purge
    set_correlation_id(None)
    published = events.relay_once()
    recovered = transfers.recover_all()
    published += events.relay_once()          # announce whatever recovery changed
    if _time.monotonic() - _last_purge > 3600:  # old rate-limit windows, once an hour
        with db.tx("fw_txn", "worker") as cur:
            cur.execute("SELECT rate_limit_purge() AS n")
        _last_purge = _time.monotonic()
    return {"published": published, "recovered": recovered}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=float, default=1.0)
    a = ap.parse_args()
    if a.once:
        print(run_once())
        return
    while True:
        try:
            out = run_once()
            if out["published"] or out["recovered"]:
                log_event("worker_pass", **out)
        except Exception as exc:  # noqa: BLE001 - keep the loop alive; the next pass retries
            log_event("worker_pass_failed", level=40, error=str(exc)[:200])
        time.sleep(a.interval)


if __name__ == "__main__":
    main()
