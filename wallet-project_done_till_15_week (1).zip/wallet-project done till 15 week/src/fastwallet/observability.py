"""Structured JSON logs, correlation IDs and Prometheus metrics.

Every log line is one JSON object with a timestamp, service, event name and the correlation ID of the
request (or worker job) that produced it. Personal data never goes into logs: the helpers below only
accept references (transaction reference, customer_ref) and masked values.
"""
import contextvars
import json
import logging
import sys
import time
import uuid

from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram
from prometheus_client.core import GaugeMetricFamily

from .config import settings

_correlation = contextvars.ContextVar("correlation_id", default=None)


def new_correlation_id() -> str:
    return str(uuid.uuid4())


def set_correlation_id(value: str | None) -> str:
    try:
        cid = str(uuid.UUID(str(value))) if value else new_correlation_id()
    except ValueError:
        cid = new_correlation_id()
    _correlation.set(cid)
    return cid


def current_correlation_id() -> str | None:
    return _correlation.get()


class JsonFormatter(logging.Formatter):
    def format(self, record):
        out = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)) + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "service": settings.service_name,
            "event": record.getMessage(),
            "correlation_id": current_correlation_id(),
        }
        out.update(getattr(record, "fields", {}))
        if record.exc_info:
            out["error"] = self.formatException(record.exc_info).splitlines()[-1]
        return json.dumps(out, default=str)


def get_logger(name="fastwallet") -> logging.Logger:
    log = logging.getLogger(name)
    if not log.handlers:
        handler = logging.FileHandler(settings.log_file) if settings.log_file else logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        log.addHandler(handler)
        log.setLevel(logging.INFO)
        log.propagate = False
    return log


def log_event(event: str, level=logging.INFO, **fields):
    get_logger().log(level, event, extra={"fields": fields})


def mask(value: str | None, keep: int = 3) -> str | None:
    if not value:
        return value
    return "*" * max(len(value) - keep, 0) + value[-keep:]


# ---------------------------------------------------------------- metrics
REGISTRY = CollectorRegistry()

HTTP_REQUESTS = Counter("fw_http_requests_total", "HTTP requests by route and status code",
                        ["method", "route", "status"], registry=REGISTRY)
HTTP_LATENCY = Histogram("fw_http_request_seconds", "HTTP request latency", ["method", "route"],
                         buckets=(0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10), registry=REGISTRY)
ACCEPT_LATENCY = Histogram("fw_transfer_accept_seconds",
                           "Time to accept a transfer up to the committed POSTED/HELD/FAILED state, before the rail call",
                           buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.4, 0.5, 0.75, 1, 2.5), registry=REGISTRY)
TRANSFERS = Counter("fw_transfers_total", "Transfer requests by resulting status", ["status"], registry=REGISTRY)
IDEMPOTENT_REPLAYS = Counter("fw_idempotent_replays_total", "Requests answered from the idempotency store",
                             registry=REGISTRY)
IDEMPOTENCY_REJECTS = Counter("fw_idempotency_key_reused_total", "Same key with a different body",
                              registry=REGISTRY)
RAIL_CALLS = Counter("fw_rail_calls_total", "Calls to the payment rail by operation and outcome",
                     ["operation", "outcome"], registry=REGISTRY)
RAIL_LATENCY = Histogram("fw_rail_call_seconds", "Rail call latency", ["operation"],
                         buckets=(0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10), registry=REGISTRY)
RAIL_DUPLICATE_ACKS = Counter("fw_rail_duplicate_acks_total", "Rail acknowledgements ignored as duplicates",
                              registry=REGISTRY)
RECOVERY = Counter("fw_recovery_actions_total", "Recovery worker results", ["result"], registry=REGISTRY)
EVENTS_CONSUMED = Counter("fw_events_consumed_total", "Events handled by consumers", ["consumer", "result"],
                          registry=REGISTRY)
AUTH_DENIALS = Counter("fw_auth_denials_total", "Requests denied for authentication or role reasons",
                       ["code"], registry=REGISTRY)
POSTING_FAILURES = Counter("fw_posting_failures_total", "Ledger postings that failed after a rail answer",
                           registry=REGISTRY)
# Week 14
RATE_LIMITED = Counter("fw_rate_limited_total", "Requests refused by the rate limiter", ["scope"], registry=REGISTRY)
DLQ_ACTIONS = Counter("fw_dead_letter_actions_total", "Dead-letter replays and discards", ["action", "result"],
                      registry=REGISTRY)
AI_SUGGESTIONS = Counter("fw_ai_suggestions_total", "Triage suggestions by recommended action (ABSTAINED = handed to a person)",
                         ["action"], registry=REGISTRY)
AI_REVIEWS = Counter("fw_ai_reviews_total", "Human reviews of triage suggestions", ["decision"], registry=REGISTRY)
AI_GUARD_BLOCKS = Counter("fw_ai_policy_guard_blocks_total", "Triage outputs replaced by an abstention by the policy guard",
                          registry=REGISTRY)
AI_LATENCY = Histogram("fw_ai_triage_seconds", "Triage latency inside the service", buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5),
                       registry=REGISTRY)


class OpsHealthCollector:
    """Business gauges read from v_ops_health at scrape time, so they are true across processes."""

    GAUGES = [
        ("pending_count", "fw_transfers_pending", "Transfers waiting for a rail outcome"),
        ("pending_oldest_seconds", "fw_transfers_pending_oldest_seconds", "Age of the oldest PENDING transfer"),
        ("posted_stuck_count", "fw_transfers_posted_stuck", "POSTED transfers older than 60 s with no outcome"),
        ("outbox_unpublished", "fw_outbox_unpublished", "Outbox events not yet relayed"),
        ("outbox_oldest_seconds", "fw_outbox_lag_seconds", "Age of the oldest unpublished event"),
        ("dlq_open", "fw_dead_letters_open", "Events in the dead-letter table"),
        ("open_breaks", "fw_recon_breaks_open", "Open reconciliation breaks"),
        ("overdue_breaks", "fw_recon_breaks_overdue", "Reconciliation breaks past their due time"),
        ("open_cases", "fw_compliance_cases_open", "Compliance cases waiting for an officer"),
        ("open_exceptions", "fw_ops_exceptions_open", "Items in the manual exception queue"),
        ("audit_denials", "fw_audit_denials", "Denied actions recorded in the audit log"),
        ("settle_p95_seconds_24h", "fw_settle_p95_seconds", "p95 initiation-to-settlement time, last 24 h"),
        ("written_off_minor", "fw_written_off_minor", "Approved reconciliation write-offs, minor units"),
        ("rate_limited_last_hour", "fw_rate_limited_last_hour", "Requests over the limit in the last hour"),
        ("ai_awaiting_review", "fw_ai_awaiting_review", "Triage suggestions waiting for a person"),
        ("ai_accepted", "fw_ai_accepted", "Triage suggestions accepted by a person"),
        ("ai_rejected", "fw_ai_rejected", "Triage suggestions rejected by a person"),
        ("ai_abstained", "fw_ai_abstained", "Triage requests where the assistant abstained"),
    ]

    def collect(self):
        from . import db
        try:
            with db.tx("fw_report", "metrics") as cur:
                cur.execute("SELECT * FROM v_ops_health")
                row = cur.fetchone()
        except Exception:  # database down: expose that instead of failing the scrape
            g = GaugeMetricFamily("fw_database_up", "1 if the database answered the health query")
            g.add_metric([], 0)
            yield g
            return
        up = GaugeMetricFamily("fw_database_up", "1 if the database answered the health query")
        up.add_metric([], 1)
        yield up
        for col, name, doc in self.GAUGES:
            g = GaugeMetricFamily(name, doc)
            g.add_metric([], float(row[col] or 0))
            yield g
        for col, name in [("trial_balance_ok", "fw_ledger_trial_balance_ok"),
                          ("projection_ok", "fw_ledger_projection_ok"),
                          ("float_invariant_ok", "fw_ledger_float_invariant_ok"),
                          ("system_accounts_ok", "fw_ledger_system_accounts_ok")]:
            g = GaugeMetricFamily(name, "1 if the ledger control holds")
            g.add_metric([], 1.0 if row[col] else 0.0)
            yield g
        by_status = GaugeMetricFamily("fw_transfers_by_status", "Transfers currently in each status",
                                      labels=["status"])
        for status, n in (row["transfers_by_status"] or {}).items():
            by_status.add_metric([status], float(n))
        yield by_status


REGISTRY.register(OpsHealthCollector())
