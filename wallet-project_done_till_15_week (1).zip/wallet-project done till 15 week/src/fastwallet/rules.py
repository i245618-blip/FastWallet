"""Screening rules engine (R01-R10).

Reads its thresholds from screening_rule and tier_policy, so changing a limit is a data change, not a
code change. Returns the outcome, a 0-100 risk score, the reason codes and a snapshot of every input the
rules saw; the caller stores all of it in screening_decision (append only).

Order: blocking rules first (no point holding a transfer that cannot go ahead), then hold rules.
R09 (second factor) is checked by the API before anything is written; by the time the engine runs the
second factor has been completed, and the snapshot records that.
Outcome is decided by the rule hits alone. The risk score only helps the compliance officer.
"""
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

RISK_WEIGHTS = {"R05": 25, "R06": 25, "R07": 40, "R08": 20, "R10": 30}


@dataclass
class Decision:
    outcome: str                      # ALLOW, HOLD or BLOCK
    risk_score: int
    reason_codes: list = field(default_factory=list)
    inputs: dict = field(default_factory=dict)
    rules_version: str = ""


def _norm(name: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z ]", "", (name or "").lower())).strip()


def name_similarity(a: str, b: str) -> float:
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return 0.0
    plain = SequenceMatcher(None, a, b).ratio()
    sorted_tokens = SequenceMatcher(None, " ".join(sorted(a.split())), " ".join(sorted(b.split()))).ratio()
    return round(max(plain, sorted_tokens), 3)


def evaluate(cur, transfer_id, customer_id, wallet_id, amount_minor, beneficiary_identifier,
             beneficiary_name, second_factor: bool) -> Decision:
    cur.execute("SELECT rule_id, outcome_on_hit, params, version FROM screening_rule WHERE active ORDER BY rule_id")
    rules = {r["rule_id"]: r for r in cur.fetchall()}
    version = "rules-v" + str(max((r["version"] for r in rules.values()), default=1))

    cur.execute("SELECT c.kyc_tier, p.* FROM customer c JOIN tier_policy p ON p.tier = c.kyc_tier "
                "WHERE c.customer_id = %s", (customer_id,))
    tier = cur.fetchone()
    cur.execute("SELECT today_minor, month_minor FROM v_customer_outbound_usage WHERE customer_id = %s",
                (customer_id,))
    usage = cur.fetchone() or {"today_minor": 0, "month_minor": 0}
    cur.execute("SELECT extract(epoch FROM now() - opened_at) / 3600 AS age_h FROM wallet WHERE wallet_id = %s",
                (wallet_id,))
    wallet_age_h = float(cur.fetchone()["age_h"])

    p05 = rules.get("R05", {}).get("params", {}) or {}
    cur.execute("SELECT count(*) AS n FROM transfer WHERE source_wallet_id = %s AND transfer_id <> %s "
                "AND status <> 'FAILED' AND created_at > now() - make_interval(mins => %s)",
                (wallet_id, transfer_id, int(p05.get("window_minutes", 10))))
    recent = cur.fetchone()["n"]
    cur.execute("SELECT count(*) AS n FROM transfer WHERE source_wallet_id = %s AND transfer_id <> %s "
                "AND beneficiary_identifier = %s AND status NOT IN ('FAILED')",
                (wallet_id, transfer_id, beneficiary_identifier))
    new_beneficiary = cur.fetchone()["n"] == 0
    cur.execute("SELECT full_name FROM watchlist_entry")
    best_match = max((name_similarity(beneficiary_name or "", r["full_name"]) for r in cur.fetchall()), default=0.0)

    inputs = {
        "amount_minor": amount_minor, "tier": tier["kyc_tier"], "can_send_to_bank": tier["can_send_to_bank"],
        "per_txn_limit_minor": tier["per_txn_limit_minor"], "daily_limit_minor": tier["daily_limit_minor"],
        "monthly_limit_minor": tier["monthly_limit_minor"], "today_minor": int(usage["today_minor"]),
        "month_minor": int(usage["month_minor"]), "recent_transfers": int(recent),
        "new_beneficiary": new_beneficiary, "wallet_age_hours": round(wallet_age_h, 2),
        "watchlist_best_similarity": best_match, "second_factor": second_factor,
    }

    def active(rid):
        return rid in rules

    def param(rid, key, default):
        return (rules[rid]["params"] or {}).get(key, default)

    blocks, holds = [], []
    if active("R01") and not tier["can_send_to_bank"]:
        blocks.append("R01")
    if active("R02") and amount_minor > tier["per_txn_limit_minor"]:
        blocks.append("R02")
    if active("R03") and inputs["today_minor"] + amount_minor > tier["daily_limit_minor"]:
        blocks.append("R03")
    if active("R04") and inputs["month_minor"] + amount_minor > tier["monthly_limit_minor"]:
        blocks.append("R04")
    if blocks:
        return Decision("BLOCK", 100, blocks, inputs, version)

    if active("R05") and recent >= int(param("R05", "max_count", 5)):
        holds.append("R05")
    if active("R06") and new_beneficiary and amount_minor >= int(param("R06", "threshold_minor", 5_000_000)):
        holds.append("R06")
    if active("R07") and best_match >= float(param("R07", "min_similarity", 0.8)):
        holds.append("R07")
    if active("R08") and wallet_age_h < float(param("R08", "age_hours", 24)) \
            and amount_minor >= int(param("R08", "threshold_minor", 2_500_000)):
        holds.append("R08")
    if active("R10") and amount_minor >= int(param("R10", "threshold_minor", 15_000_000)):
        holds.append("R10")

    score = min(100, 5 + sum(RISK_WEIGHTS.get(r, 0) for r in holds))
    return Decision("HOLD" if holds else "ALLOW", score, holds, inputs, version)
