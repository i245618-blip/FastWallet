"""Mint a local test token.  Example:
    FW_JWT_SECRET=... python -m fastwallet.tokens --sub CUST-0004 --role customer --mfa
"""
import argparse

from .security import issue_token

p = argparse.ArgumentParser()
p.add_argument("--sub", required=True)
p.add_argument("--role", required=True, action="append")
p.add_argument("--client-id", default="fw-app")
p.add_argument("--mfa", action="store_true")
p.add_argument("--ttl", type=int, default=3600)
a = p.parse_args()
print(issue_token(a.sub, a.role, a.client_id, a.mfa, a.ttl))
