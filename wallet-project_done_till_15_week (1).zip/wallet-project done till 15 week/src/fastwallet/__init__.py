"""FastWallet Week 13 prototype: API gateway/transaction service, rules engine, mock rail,
recovery worker, outbox relay, notification consumer and reconciliation job.

Fictional system, synthetic data only. Nothing here talks to a real payment, bank or identity service.
"""
