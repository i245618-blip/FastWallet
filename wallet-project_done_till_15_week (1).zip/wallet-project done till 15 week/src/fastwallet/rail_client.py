"""Client for the (mock) payment rail. Every call is bounded by a timeout; a timeout or a server error is
reported as UNKNOWN, never as a failure, because the rail may have executed the payment anyway.
"""
import time

import httpx

from .config import settings
from .observability import RAIL_CALLS, RAIL_LATENCY, current_correlation_id, log_event


def _call(operation, method, path, **kw):
    started = time.perf_counter()
    headers = {"X-Correlation-ID": current_correlation_id() or ""}
    try:
        with httpx.Client(base_url=settings.rail_url, timeout=settings.rail_timeout_seconds) as c:
            resp = c.request(method, path, headers=headers, **kw)
        if resp.status_code == 404:
            result = {"status": "NOT_FOUND"}
        elif resp.status_code >= 500:
            result = {"status": "UNKNOWN", "reason": f"RAIL_HTTP_{resp.status_code}"}
        else:
            result = resp.json()
    except httpx.TimeoutException:
        result = {"status": "UNKNOWN", "reason": "RAIL_TIMEOUT"}
    except httpx.TransportError:
        result = {"status": "UNKNOWN", "reason": "RAIL_UNREACHABLE"}
    elapsed = time.perf_counter() - started
    RAIL_LATENCY.labels(operation).observe(elapsed)
    RAIL_CALLS.labels(operation, result["status"]).inc()
    log_event("rail_call", operation=operation, outcome=result["status"], reason=result.get("reason"),
              latency_ms=round(elapsed * 1000, 1))
    return result


def submit(transaction_reference, amount_minor, scheme, identifier):
    # the immutable transaction reference is the rail request id and is never regenerated on retry
    return _call("SUBMIT", "POST", "/rail/v1/payments", json={
        "request_id": transaction_reference, "amount_minor": amount_minor,
        "beneficiary_scheme": scheme, "beneficiary_identifier": identifier})


def enquire(transaction_reference):
    return _call("ENQUIRY", "GET", f"/rail/v1/payments/{transaction_reference}")


def statement(date_iso):
    with httpx.Client(base_url=settings.rail_url, timeout=10) as c:
        resp = c.get(f"/rail/v1/statements/{date_iso}")
        resp.raise_for_status()
        return resp.json()["lines"]
