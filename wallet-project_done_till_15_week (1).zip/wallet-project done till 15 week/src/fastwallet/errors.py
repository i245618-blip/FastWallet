"""RFC 7807 problem responses with the stable codes from api/openapi.yaml."""
from fastapi.responses import JSONResponse

from .observability import current_correlation_id

TITLES = {
    "VALIDATION_ERROR": "Request validation failed",
    "UNAUTHENTICATED": "Missing or invalid credentials",
    "STEP_UP_REQUIRED": "A second factor is required for this transfer",
    "FORBIDDEN_ROLE": "Role not permitted for this operation",
    "SOD_VIOLATION": "The same person cannot make and approve this request",
    "NOT_FOUND": "Resource not found",
    "REQUEST_IN_PROGRESS": "A request with this idempotency key is in progress",
    "IDEMPOTENCY_KEY_REUSED": "Idempotency key was used with a different request body",
    "LIMIT_EXCEEDED": "Transfer blocked by a limit or eligibility rule",
    "INSUFFICIENT_FUNDS": "Insufficient funds in the wallet",
    "CONSENT_REQUIRED": "Customer consent for transaction processing is missing",
    "INVALID_STATE_TRANSITION": "The resource is not in a state that allows this action",
    "DEPENDENCY_UNAVAILABLE": "A dependency is unavailable; nothing was changed",
}


class ApiError(Exception):
    def __init__(self, status: int, code: str, detail: str = "", extra: dict | None = None, headers=None):
        super().__init__(f"{code}: {detail}")
        self.status, self.code, self.detail = status, code, detail
        self.extra, self.headers = extra or {}, headers or {}


def problem_body(status: int, code: str, detail: str = "", extra: dict | None = None) -> dict:
    body = {
        "type": f"https://fastwallet.example/problems/{code.lower().replace('_', '-')}",
        "title": TITLES.get(code, code),
        "status": status,
        "code": code,
        "correlation_id": current_correlation_id(),
    }
    if detail:
        body["detail"] = detail
    body.update(extra or {})
    return body


def problem(status: int, code: str, detail: str = "", extra=None, headers=None) -> JSONResponse:
    return JSONResponse(problem_body(status, code, detail, extra), status_code=status,
                        media_type="application/problem+json", headers=headers)
