"""Database access. Every unit of work runs in one transaction under a least-privilege role.

The process logs in with the DATABASE_URL account and immediately switches to the service role with
SET LOCAL ROLE (fw_txn, fw_recon, fw_notify, fw_relay, fw_report or fw_ai), so the grants in
src/db/05_roles.sql, 06_week13.sql and 07_week14.sql apply to every statement the services run.

Week 14 (ADR-008): connections are pooled. Week 13 opened a new connection for every unit of work (about
8.5 ms each, several per request). The pool keeps up to FW_DB_POOL_SIZE connections per process and blocks
callers when all are busy. SET LOCAL ROLE and the fw.actor setting end with each transaction, so a pooled
connection never carries one request's role or actor into the next. After a database restart the pooled
connections are dead; the first statement on a dead connection fails before anything was sent, so the
connection is thrown away and the unit of work starts again on a fresh one, exactly once.
"""
import queue
import threading
from contextlib import contextmanager

import psycopg2
import psycopg2.extras

from .config import settings

ROLES = {"fw_txn", "fw_recon", "fw_notify", "fw_relay", "fw_report", "fw_ai"}
psycopg2.extras.register_uuid()


def connect():
    return psycopg2.connect(settings.database_url, connect_timeout=3)


class Pool:
    """Small blocking pool: a LIFO stack of idle connections and a semaphore for the maximum size."""

    def __init__(self, size: int, wait_seconds: float):
        self.size, self.wait_seconds = size, wait_seconds
        self._idle: queue.LifoQueue = queue.LifoQueue()
        self._slots = threading.BoundedSemaphore(size)

    def acquire(self):
        if not self._slots.acquire(timeout=self.wait_seconds):
            raise psycopg2.OperationalError("POOL_EXHAUSTED: no database connection free within the wait budget")
        try:
            try:
                conn = self._idle.get_nowait()
                if conn.closed:
                    raise queue.Empty
                return conn
            except queue.Empty:
                return connect()
        except Exception:
            self._slots.release()
            raise

    def release(self, conn, broken: bool = False):
        try:
            if broken or conn.closed:
                try:
                    conn.close()
                except psycopg2.Error:
                    pass
            else:
                self._idle.put(conn)
        finally:
            self._slots.release()

    def close_all(self):
        while True:
            try:
                self._idle.get_nowait().close()
            except queue.Empty:
                return


_pool = None
_pool_lock = threading.Lock()


def pool() -> Pool | None:
    global _pool
    if not settings.db_pool_size:
        return None
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                _pool = Pool(settings.db_pool_size, settings.db_pool_wait_seconds)
    return _pool


def _checkout():
    p = pool()
    return p.acquire() if p else connect()


def _checkin(conn, broken=False):
    p = pool()
    if p:
        p.release(conn, broken)
    else:
        conn.close()


def _begin(conn, role, actor):
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SET search_path = fw, public")
    cur.execute(f"SET LOCAL ROLE {role}")
    cur.execute("SELECT set_config('fw.actor', %s, true)", (actor,))
    return cur


@contextmanager
def tx(role: str, actor: str = "system"):
    """Yield a dict cursor inside a transaction running as `role`; commit on success, roll back on error."""
    if role not in ROLES:
        raise ValueError(f"unknown role {role}")
    conn = _checkout()
    try:
        cur = _begin(conn, role, actor)
    except (psycopg2.OperationalError, psycopg2.InterfaceError):
        # stale pooled connection (e.g. after a database restart): nothing was done yet, so retry once
        _checkin(conn, broken=True)
        if pool():
            pool().close_all()          # the other idle connections died with it
        conn = _checkout()
        try:
            cur = _begin(conn, role, actor)
        except Exception:
            _checkin(conn, broken=True)
            raise
    broken = False
    try:
        yield cur
        conn.commit()
    except Exception as exc:
        broken = isinstance(exc, (psycopg2.OperationalError, psycopg2.InterfaceError))
        try:
            conn.rollback()
        except psycopg2.Error:
            broken = True
        raise
    finally:
        _checkin(conn, broken)


def ping() -> bool:
    try:
        with tx("fw_report", "health") as cur:
            cur.execute("SELECT 1")
        return True
    except psycopg2.Error:
        return False


def db_error_token(exc: Exception) -> str:
    """The integrity rules raise messages that start with a stable token, e.g. INSUFFICIENT_FUNDS: ..."""
    msg = getattr(exc, "pgerror", None) or str(exc)
    msg = msg.replace("ERROR:", "").strip()
    return msg.split(":", 1)[0].strip()
