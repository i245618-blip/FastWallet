"""API gateway / service facade and Transaction Service HTTP layer (FastAPI).

Run:  uvicorn fastwallet.api:app --port 8000      (PYTHONPATH=src, env from infra/.env.example)

Gateway duties on every request: correlation ID (accept a valid UUID or create one, echo it), bearer
token validation, server-side role check with audited denials, Idempotency-Key validation on
state-changing POSTs, RFC 7807 errors, one structured log line and request metrics.
"""
import datetime as dt
import hashlib
import hmac
import html
import re
import time
from typing import Literal, Optional

import psycopg2
from fastapi import FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from pydantic import BaseModel, ConfigDict, Field

from . import db, events, recon, transfers, triage
from .config import settings
from .errors import ApiError, problem
from .observability import (ACCEPT_LATENCY, AI_REVIEWS, AUTH_DENIALS, HTTP_LATENCY, HTTP_REQUESTS, RATE_LIMITED,
                            REGISTRY, current_correlation_id, log_event, set_correlation_id)
from .security import Principal, decode

app = FastAPI(title="FastWallet Transfer API (synthetic)", version="1.0.0")
KEY_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


# ---------------------------------------------------------------- request models (mirror api/openapi.yaml)

class Money(BaseModel):
    model_config = ConfigDict(extra="forbid")
    currency: Literal["PKR"]
    minor_units: int = Field(ge=1, le=20_000_000)


class Beneficiary(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scheme: Literal["IBAN", "RAAST_ID"]
    identifier: str = Field(min_length=8, max_length=34)
    name: Optional[str] = Field(default=None, max_length=100)


class CreateTransfer(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_wallet_id: str = Field(pattern=r"^[0-9a-fA-F-]{36}$")
    beneficiary: Beneficiary
    amount: Money
    purpose: Literal["FAMILY_SUPPORT", "BILL_SHARE", "SAVINGS", "PURCHASE", "OTHER"]
    customer_note: Optional[str] = Field(default=None, max_length=140)


class CaseDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: Literal["RELEASE", "REJECT"]
    rationale: str = Field(min_length=10, max_length=1000)


class ReversalIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason_code: Literal["CUSTOMER_DISPUTE", "RAIL_RETURN", "OPERATIONAL_ERROR", "DUPLICATE_DETECTED"]
    reason_text: str = Field(min_length=10, max_length=500)


class ReversalDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: Literal["APPROVE", "REJECT"]
    comment: str = Field(min_length=10, max_length=500)


class BreakResolution(BaseModel):
    model_config = ConfigDict(extra="forbid")
    resolution_code: Literal["MATCHED_LATE", "COMPENSATED", "WRITTEN_OFF_APPROVED", "RAIL_CORRECTION_REQUESTED"]
    comment: str = Field(min_length=10, max_length=1000)
    approved_by: Optional[str] = None


class ExceptionResolution(BaseModel):
    model_config = ConfigDict(extra="forbid")
    comment: str = Field(min_length=10, max_length=1000)


class DiscardIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=10, max_length=500)


class TriageIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    item_type: Literal["EXCEPTION", "BREAK"]
    item_id: str = Field(pattern=r"^[0-9a-fA-F-]{36}$")


class TriageReview(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: Literal["ACCEPT", "REJECT"]
    comment: str = Field(min_length=10, max_length=1000)


class TriageConfigIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool
    abstain_below: Optional[float] = Field(default=None, ge=0.5, le=0.99)
    reason: str = Field(min_length=10, max_length=500)


class ReconRunIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    statement_date: Optional[str] = None
    stuck_after_seconds: int = Field(default=1800, ge=0)


# ---------------------------------------------------------------- gateway middleware and error mapping

@app.middleware("http")
async def gateway(request: Request, call_next):
    cid = set_correlation_id(request.headers.get("X-Correlation-ID"))
    started = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception as exc:  # noqa: BLE001
        log_event("unhandled_error", level=40, path=request.url.path, error=str(exc)[:200])
        response = problem(500, "DEPENDENCY_UNAVAILABLE", "unexpected error")
    elapsed = time.perf_counter() - started
    route = getattr(request.scope.get("route"), "path", "unmatched")
    response.headers["X-Correlation-ID"] = cid
    HTTP_REQUESTS.labels(request.method, route, str(response.status_code)).inc()
    HTTP_LATENCY.labels(request.method, route).observe(elapsed)
    if route not in ("/metrics", "/health/live"):
        log_event("http_request", method=request.method, route=route, status=response.status_code,
                  latency_ms=round(elapsed * 1000, 1), replayed=response.headers.get("Idempotent-Replayed") == "true")
    return response


@app.exception_handler(ApiError)
async def api_error(_req, exc: ApiError):
    if exc.status in (401, 403):
        AUTH_DENIALS.labels(exc.code).inc()
    return problem(exc.status, exc.code, exc.detail, exc.extra, exc.headers)


@app.exception_handler(RequestValidationError)
async def validation_error(_req, exc: RequestValidationError):
    errs = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
    return problem(400, "VALIDATION_ERROR", "request does not match the contract", {"errors": errs})


DB_TOKEN_MAP = {
    "ROLE_NOT_PERMITTED": (403, "FORBIDDEN_ROLE"), "SOD_VIOLATION": (403, "SOD_VIOLATION"),
    "INSUFFICIENT_FUNDS": (422, "INSUFFICIENT_FUNDS"), "INVALID_STATE_TRANSITION": (422, "INVALID_STATE_TRANSITION"),
    "INVALID_STATE_FOR_POSTING": (422, "INVALID_STATE_TRANSITION"), "NOT_FOUND": (404, "NOT_FOUND"),
    "WRITE_OFF_NOT_APPLICABLE": (422, "WRITE_OFF_NOT_APPLICABLE"),
}


@app.exception_handler(psycopg2.Error)
async def db_error(request: Request, exc: psycopg2.Error):
    if isinstance(exc, psycopg2.OperationalError):
        return problem(503, "DEPENDENCY_UNAVAILABLE", "database unavailable; nothing was changed")
    token = db.db_error_token(exc)
    if token in DB_TOKEN_MAP:
        status, code = DB_TOKEN_MAP[token]
        if status == 403:
            AUTH_DENIALS.labels(code).inc()
            transfers.audit_denied(getattr(request.state, "actor", None), getattr(request.state, "role", None),
                                   f"{request.method} {request.url.path}", details={"code": code})
        return problem(status, code, str(exc).split("\n")[0][:200])
    if isinstance(exc, psycopg2.errors.UniqueViolation) and "uq_open_reversal" in str(exc):
        return problem(422, "INVALID_STATE_TRANSITION", "an open reversal already exists for this transfer")
    log_event("database_error", level=40, error=str(exc)[:200])
    return problem(500, "DEPENDENCY_UNAVAILABLE", "database error")


def authorise(request: Request, authorization: Optional[str], roles: tuple, action: str) -> Principal:
    try:
        p = decode(authorization)
    except ApiError:
        transfers.audit_denied("anonymous", None, action, details={"code": "UNAUTHENTICATED"})
        raise
    request.state.actor, request.state.role = p.sub, p.role
    if not p.has(*roles):
        transfers.audit_denied(p.sub, p.role, action, details={"code": "FORBIDDEN_ROLE", "needs": list(roles)})
        raise ApiError(403, "FORBIDDEN_ROLE", f"needs one of {', '.join(roles)}")
    return p


def rate_limit(p: Principal, scope: str):
    """Fixed-window limit per subject, stored in PostgreSQL so every API process shares it (ADR-009).
    Only the first refusal in a window is audited, so a retry storm cannot flood the audit log."""
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("SELECT allowed, hits, max_requests, retry_after FROM rate_limit_take(%s, %s)", (scope, p.sub))
        r = cur.fetchone()
    if r["allowed"]:
        return
    RATE_LIMITED.labels(scope).inc()
    if r["hits"] == r["max_requests"] + 1:
        transfers.audit_denied(p.sub, p.role, "RATE_LIMITED", details={"scope": scope, "limit": r["max_requests"]})
    raise ApiError(429, "RATE_LIMITED", f"more than {r['max_requests']} requests in the window for {scope}",
                   headers={"Retry-After": str(r["retry_after"])})


def require_key(key: Optional[str]) -> str:
    if not key or not KEY_RE.match(key):
        raise ApiError(400, "VALIDATION_ERROR", "Idempotency-Key header is required (16-64 of A-Z a-z 0-9 _ -)")
    return key


def respond(status, body, replayed):
    headers = {"Idempotent-Replayed": "true"} if replayed else {}
    media = "application/problem+json" if status >= 400 else "application/json"
    return JSONResponse(body, status_code=status, headers=headers, media_type=media)


STAFF = ("ops_analyst", "finance_controller", "compliance_officer", "system_recovery")


# ---------------------------------------------------------------- health and metrics

@app.get("/health/live")
def live():
    return {"status": "ok"}


@app.get("/health/ready")
def ready():
    ok = db.ping()
    return JSONResponse({"status": "ok" if ok else "degraded", "database": ok}, status_code=200 if ok else 503)


@app.get("/metrics")
def metrics():
    return Response(generate_latest(REGISTRY), media_type=CONTENT_TYPE_LATEST)


# ---------------------------------------------------------------- transfers

@app.post("/v1/transfers")
def create_transfer(body: CreateTransfer, request: Request, authorization: Optional[str] = Header(None),
                    idempotency_key: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("customer",), "TRANSFER_CREATE")
    rate_limit(p, "transfer_create")
    key = require_key(idempotency_key)
    return respond(*transfers.create_transfer(p, body.model_dump(), key))


@app.get("/v1/transfers")
def list_transfers(request: Request, authorization: Optional[str] = Header(None), limit: int = 50):
    p = authorise(request, authorization, ("customer",) + STAFF, "TRANSFER_LIST")
    with db.tx("fw_txn", p.sub) as cur:
        if p.has("customer"):
            cur.execute("""SELECT t.transfer_id FROM transfer t JOIN wallet w ON w.wallet_id = t.source_wallet_id
                           JOIN customer c USING (customer_id) WHERE c.customer_ref = %s
                           ORDER BY t.created_at DESC LIMIT %s""", (p.sub, min(limit, 200)))
        else:
            cur.execute("SELECT transfer_id FROM transfer ORDER BY created_at DESC LIMIT %s", (min(limit, 200),))
        return {"items": [transfers.snapshot(cur, r["transfer_id"]) for r in cur.fetchall()]}


@app.get("/v1/transfers/{transfer_id}")
def get_transfer(transfer_id: str, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("customer",) + STAFF, "TRANSFER_READ")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("""SELECT c.customer_ref FROM transfer t JOIN wallet w ON w.wallet_id = t.source_wallet_id
                       JOIN customer c USING (customer_id) WHERE t.transfer_id::text = %s""", (transfer_id,))
        row = cur.fetchone()
        if not row or (p.has("customer") and not p.has(*STAFF) and row["customer_ref"] != p.sub):
            raise ApiError(404, "NOT_FOUND", "transfer not found")
        return transfers.snapshot(cur, transfer_id)


@app.post("/v1/transfers/{transfer_id}/status-enquiry")
def status_enquiry(transfer_id: str, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "system_recovery"), "STATUS_ENQUIRY")
    rate_limit(p, "staff_write")
    result = transfers.recover_transfer(transfer_id, force=True)
    with db.tx("fw_txn", p.sub) as cur:
        transfers.audit(cur, p.sub, p.role, "STATUS_ENQUIRY", "transfer", transfer_id, "ALLOWED", {"result": result})
        return {"result": result, "transfer": transfers.snapshot(cur, transfer_id)}


@app.post("/v1/transfers/{transfer_id}/reversals")
def request_reversal(transfer_id: str, body: ReversalIn, request: Request,
                     authorization: Optional[str] = Header(None), idempotency_key: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst",), "REVERSAL_REQUEST")
    rate_limit(p, "staff_write")
    return respond(*transfers.request_reversal(p, transfer_id, body.reason_code, body.reason_text,
                                               require_key(idempotency_key)))


@app.post("/v1/reversals/{reversal_id}/approval")
def decide_reversal(reversal_id: str, body: ReversalDecision, request: Request,
                    authorization: Optional[str] = Header(None), idempotency_key: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("finance_controller",), "REVERSAL_DECISION")
    rate_limit(p, "staff_write")
    return respond(*transfers.decide_reversal(p, reversal_id, body.decision, body.comment,
                                              require_key(idempotency_key)))


# ---------------------------------------------------------------- compliance

@app.get("/v1/compliance/cases")
def list_cases(request: Request, authorization: Optional[str] = Header(None), state: str = "OPEN"):
    p = authorise(request, authorization, ("compliance_officer",), "CASE_LIST")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("""SELECT k.case_id, k.state, k.due_at, t.transaction_reference, t.amount_minor,
                              d.reason_codes, d.risk_score, d.rules_version
                         FROM compliance_case k JOIN transfer t USING (transfer_id)
                         JOIN screening_decision d ON d.decision_id = k.decision_id
                        WHERE k.state = %s ORDER BY k.opened_at""", (state,))
        return {"items": [{**r, "case_id": str(r["case_id"]), "due_at": r["due_at"].isoformat()}
                          for r in cur.fetchall()]}


@app.post("/v1/compliance/cases/{case_id}/decision")
def decide_case(case_id: str, body: CaseDecision, request: Request, authorization: Optional[str] = Header(None),
                idempotency_key: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("compliance_officer",), "CASE_DECISION")
    rate_limit(p, "staff_write")
    return respond(*transfers.decide_case(p, case_id, body.decision, body.rationale, require_key(idempotency_key)))


# ---------------------------------------------------------------- reconciliation, exceptions, reports

@app.post("/v1/reconciliation/runs")
def recon_run(body: ReconRunIn, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "RECON_RUN")
    rate_limit(p, "staff_write")
    return recon.run(body.statement_date or dt.date.today().isoformat(), p.sub, body.stuck_after_seconds)


@app.get("/v1/reconciliation/breaks")
def list_breaks(request: Request, authorization: Optional[str] = Header(None), state: Optional[str] = None):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "BREAK_LIST")
    with db.tx("fw_recon", p.sub) as cur:
        cur.execute("""SELECT break_id, transfer_id, break_type::text, state, owner_role AS owner, internal_amount_minor,
                              external_amount_minor, opened_at, due_at, resolution_code, detail
                         FROM recon_break WHERE (%s::text IS NULL OR state = %s) ORDER BY opened_at""", (state, state))
        return {"items": [{k: (str(v) if k in ("break_id", "transfer_id") and v else
                               v.isoformat() if hasattr(v, "isoformat") else v) for k, v in r.items()}
                          for r in cur.fetchall()]}


@app.post("/v1/reconciliation/breaks/{break_id}/resolution")
def resolve_break(break_id: str, body: BreakResolution, request: Request,
                  authorization: Optional[str] = Header(None), idempotency_key: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "BREAK_RESOLUTION")
    rate_limit(p, "staff_write")
    require_key(idempotency_key)
    with db.tx("fw_txn", p.sub) as cur:
        user_id = transfers.staff_user_id(cur, p.sub)
        approver = transfers.staff_user_id(cur, body.approved_by) if body.approved_by else None
    with db.tx("fw_recon", p.sub) as cur:
        cur.execute("SELECT resolve_break(%s, %s, %s, %s, %s)",
                    (break_id, body.resolution_code, body.comment, user_id, approver))
        cur.execute("SELECT audit(%s, %s, 'BREAK_RESOLUTION', 'recon_break', %s, 'ALLOWED', %s, %s)",
                    (p.sub, p.role, break_id, current_correlation_id(),
                     '{"code": "%s"}' % body.resolution_code))
        cur.execute("SELECT break_id, break_type::text, state, owner_role AS owner, resolution_code, resolved_at "
                    "FROM recon_break WHERE break_id = %s", (break_id,))
        r = cur.fetchone()
    return {**r, "break_id": str(r["break_id"]), "resolved_at": r["resolved_at"].isoformat()}


@app.get("/v1/ops/exceptions")
def list_exceptions(request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "EXCEPTION_LIST")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("""SELECT e.exception_id, e.kind, e.owner_role, e.state, e.detail, e.opened_at, e.due_at,
                              t.transaction_reference FROM ops_exception e LEFT JOIN transfer t USING (transfer_id)
                        ORDER BY e.opened_at""")
        return {"items": [{**r, "exception_id": str(r["exception_id"]), "opened_at": r["opened_at"].isoformat(),
                           "due_at": r["due_at"].isoformat()} for r in cur.fetchall()]}


@app.post("/v1/ops/exceptions/{exception_id}/resolution")
def resolve_exception(exception_id: str, body: ExceptionResolution, request: Request,
                      authorization: Optional[str] = Header(None)):
    """Close an exception-queue item after the owner has dealt with it. Records a decision; moves no money."""
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "EXCEPTION_RESOLUTION")
    rate_limit(p, "staff_write")
    with db.tx("fw_txn", p.sub) as cur:
        transfers.staff_user_id(cur, p.sub)
        cur.execute("SELECT owner_role, state, kind FROM ops_exception WHERE exception_id::text = %s FOR UPDATE",
                    (exception_id,))
        e = cur.fetchone()
        if not e:
            raise ApiError(404, "NOT_FOUND", "exception not found")
        if e["state"] != "OPEN":
            raise ApiError(422, "INVALID_STATE_TRANSITION", "exception is already resolved")
        if p.role != e["owner_role"] and p.role != "finance_controller":
            transfers.audit_denied(p.sub, p.role, "EXCEPTION_RESOLUTION", "ops_exception", exception_id,
                                   {"code": "FORBIDDEN_ROLE", "owner": e["owner_role"]})
            raise ApiError(403, "FORBIDDEN_ROLE", f"exception is owned by {e['owner_role']}")
        cur.execute("UPDATE ops_exception SET state = 'RESOLVED', resolved_by = %s, resolved_at = now() "
                    "WHERE exception_id::text = %s", (p.sub, exception_id))
        transfers.audit(cur, p.sub, p.role, "EXCEPTION_RESOLUTION", "ops_exception", exception_id, "ALLOWED",
                        {"kind": e["kind"], "comment": body.comment})
    return {"exception_id": exception_id, "kind": e["kind"], "state": "RESOLVED", "resolved_by": p.sub}


@app.get("/v1/ops/dead-letters")
def list_dead_letters(request: Request, authorization: Optional[str] = Header(None), state: str = "OPEN"):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "DLQ_LIST")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("""SELECT dlq_id, consumer_name, event_id, error, attempts, state, first_failed_at, resolved_by,
                              resolution_note FROM dead_letter_event WHERE state = %s ORDER BY dlq_id""", (state,))
        return {"items": [{k: (v.isoformat() if hasattr(v, "isoformat") else str(v) if k == "event_id" and v else v)
                           for k, v in r.items()} for r in cur.fetchall()]}


@app.post("/v1/ops/dead-letters/{dlq_id}/replay")
def replay_dead_letter(dlq_id: int, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst",), "DLQ_REPLAY")
    rate_limit(p, "staff_write")
    out = events.replay_dead_letter(dlq_id, p.sub)
    with db.tx("fw_txn", p.sub) as cur:
        transfers.audit(cur, p.sub, p.role, "DLQ_REPLAY", "dead_letter_event", dlq_id, "ALLOWED", out)
    return out


@app.post("/v1/ops/dead-letters/{dlq_id}/discard")
def discard_dead_letter(dlq_id: int, body: DiscardIn, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst",), "DLQ_DISCARD")
    rate_limit(p, "staff_write")
    out = events.discard_dead_letter(dlq_id, p.sub, body.reason)
    with db.tx("fw_txn", p.sub) as cur:
        transfers.audit(cur, p.sub, p.role, "DLQ_DISCARD", "dead_letter_event", dlq_id, "ALLOWED",
                        {"reason": body.reason})
    return out


# ---------------------------------------------------------------- AI exception-triage assistant (advisory only)

@app.post("/v1/ai/triage", status_code=201)
def ai_triage(body: TriageIn, request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "AI_TRIAGE_REQUEST")
    rate_limit(p, "ai_triage")
    return JSONResponse(triage.triage(body.item_type, body.item_id, p.sub), status_code=201)


@app.get("/v1/ai/triage/suggestions")
def ai_suggestions(request: Request, authorization: Optional[str] = Header(None), item_id: Optional[str] = None,
                   limit: int = 50):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "AI_TRIAGE_LIST")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("""SELECT s.suggestion_id, s.item_type, s.item_id, s.model_version, s.category, s.recommended_action,
                              s.confidence, s.abstained, s.abstain_reason, s.summary, s.created_at,
                              r.decision AS review_decision, u.username AS reviewed_by
                         FROM ai_triage_suggestion s LEFT JOIN ai_triage_review r USING (suggestion_id)
                         LEFT JOIN app_user u ON u.user_id = r.reviewed_by
                        WHERE (%s::text IS NULL OR s.item_id::text = %s)
                        ORDER BY s.created_at DESC LIMIT %s""", (item_id, item_id, min(limit, 200)))
        return {"items": [{**r, "suggestion_id": str(r["suggestion_id"]), "item_id": str(r["item_id"]),
                           "confidence": float(r["confidence"]), "created_at": r["created_at"].isoformat()}
                          for r in cur.fetchall()]}


@app.post("/v1/ai/triage/suggestions/{suggestion_id}/review")
def ai_review(suggestion_id: str, body: TriageReview, request: Request, authorization: Optional[str] = Header(None)):
    """A person records whether the suggestion was right. Accepting executes nothing: the person still takes the
    step through its own endpoint, under their own role and its controls."""
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "AI_TRIAGE_REVIEW")
    rate_limit(p, "staff_write")
    with db.tx("fw_txn", p.sub) as cur:
        user_id = transfers.staff_user_id(cur, p.sub)
        cur.execute("SELECT abstained, recommended_action FROM ai_triage_suggestion WHERE suggestion_id::text = %s",
                    (suggestion_id,))
        s = cur.fetchone()
        if not s:
            raise ApiError(404, "NOT_FOUND", "suggestion not found")
        if s["abstained"]:
            raise ApiError(422, "INVALID_STATE_TRANSITION", "the assistant abstained; there is nothing to accept")
        cur.execute("SELECT 1 FROM ai_triage_review WHERE suggestion_id::text = %s", (suggestion_id,))
        if cur.fetchone():
            raise ApiError(422, "INVALID_STATE_TRANSITION", "this suggestion was already reviewed")
        cur.execute("INSERT INTO ai_triage_review (suggestion_id, decision, comment, reviewed_by) VALUES (%s, %s, %s, %s)",
                    (suggestion_id, body.decision, body.comment, user_id))
        transfers.audit(cur, p.sub, p.role, "AI_TRIAGE_REVIEW", "ai_triage_suggestion", suggestion_id, "ALLOWED",
                        {"decision": body.decision, "action": s["recommended_action"]})
    AI_REVIEWS.labels(body.decision).inc()
    return {"suggestion_id": suggestion_id, "decision": body.decision, "reviewed_by": p.sub,
            "executed": False, "note": "advisory only; carry out the step through its own endpoint"}


@app.put("/v1/ai/triage/config")
def ai_config(body: TriageConfigIn, request: Request, authorization: Optional[str] = Header(None)):
    """Kill switch and abstention threshold. Finance controller only; every change is audited."""
    p = authorise(request, authorization, ("finance_controller",), "AI_TRIAGE_CONFIG")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("UPDATE ai_triage_config SET enabled = %s, abstain_below = coalesce(%s, abstain_below), "
                    "updated_by = %s, updated_at = now() RETURNING enabled, abstain_below, model_version",
                    (body.enabled, body.abstain_below, p.sub))
        cfg = cur.fetchone()
        transfers.audit(cur, p.sub, p.role, "AI_TRIAGE_CONFIG", "ai_triage_config", "1", "ALLOWED",
                        {"enabled": body.enabled, "abstain_below": body.abstain_below, "reason": body.reason})
    return {**cfg, "abstain_below": float(cfg["abstain_below"])}


@app.get("/v1/ai/triage/quality")
def ai_quality(request: Request, authorization: Optional[str] = Header(None)):
    p = authorise(request, authorization, ("ops_analyst", "finance_controller"), "AI_TRIAGE_QUALITY")
    with db.tx("fw_txn", p.sub) as cur:
        cur.execute("SELECT * FROM v_ai_triage_quality")
        rows = [{k: float(v) if hasattr(v, "as_integer_ratio") and not isinstance(v, int) else v
                 for k, v in r.items()} for r in cur.fetchall()]
        cur.execute("SELECT enabled, model_version, abstain_below, material_amount_minor FROM ai_triage_config")
        cfg = cur.fetchone()
    return {"config": {**cfg, "abstain_below": float(cfg["abstain_below"])}, "by_model_version": rows}


@app.get("/v1/ops/health-summary")
def health_summary(request: Request, authorization: Optional[str] = Header(None)):
    authorise(request, authorization, ("ops_analyst", "finance_controller"), "OPS_HEALTH")
    with db.tx("fw_report", "dashboard") as cur:
        cur.execute("SELECT * FROM v_ops_health")
        row = dict(cur.fetchone())
    row["settle_p95_seconds_24h"] = float(row["settle_p95_seconds_24h"])
    row["written_off_minor"] = int(row["written_off_minor"] or 0)
    row["rate_limited_last_hour"] = int(row["rate_limited_last_hour"] or 0)
    return row


@app.get("/v1/reports/settlement")
def settlement_report(request: Request, authorization: Optional[str] = Header(None)):
    authorise(request, authorization, ("finance_controller",), "REPORT_SETTLEMENT")
    with db.tx("fw_report", "reporting") as cur:
        cur.execute("SELECT * FROM v_settlement_report ORDER BY business_date")
        return {"items": [{**r, "business_date": r["business_date"].isoformat()} for r in cur.fetchall()]}


@app.get("/v1/audit/verify")
def audit_verify(request: Request, authorization: Optional[str] = Header(None)):
    authorise(request, authorization, ("finance_controller",), "AUDIT_VERIFY")
    with db.tx("fw_report", "audit-check") as cur:
        cur.execute("SELECT chain_ok, first_bad_id FROM verify_audit_chain()")
        return cur.fetchone()


# ---------------------------------------------------------------- rail acknowledgements (signed callback)

@app.post("/internal/rail/acks")
async def rail_ack(request: Request, x_rail_signature: Optional[str] = Header(None)):
    raw = await request.body()
    expected = hmac.new(settings.rail_ack_secret.encode(), raw, hashlib.sha256).hexdigest()
    if not settings.rail_ack_secret or not x_rail_signature or not hmac.compare_digest(expected, x_rail_signature):
        transfers.audit_denied("rail", "rail", "RAIL_ACK_BAD_SIGNATURE")
        raise ApiError(401, "UNAUTHENTICATED", "rail acknowledgement signature invalid")
    import json as _json
    ack = _json.loads(raw)
    with db.tx("fw_txn", "rail-ack") as cur:
        cur.execute("SELECT transfer_id FROM transfer WHERE transaction_reference = %s", (ack["request_id"],))
        row = cur.fetchone()
    if not row:
        raise ApiError(404, "NOT_FOUND", "unknown request id")
    from starlette.concurrency import run_in_threadpool
    snap = await run_in_threadpool(transfers.apply_outcome_safely, row["transfer_id"], ack, "ack")
    return {"transaction_reference": snap["transaction_reference"], "status": snap["status"]}


# ---------------------------------------------------------------- fault injection (tests only)

@app.post("/internal/faults")
def faults(body: dict):
    if not settings.fault_injection:
        raise ApiError(404, "NOT_FOUND", "fault injection disabled")
    for f in body.get("enable", []):
        transfers.FAULTS.add(f)
    for f in body.get("disable", []):
        transfers.FAULTS.discard(f)
    if body.get("clear"):
        transfers.FAULTS.clear()
    return {"active": sorted(transfers.FAULTS)}


# ---------------------------------------------------------------- operations dashboard (metrics view)

def _hist_quantile(hist, q, label_values=None):
    """Estimate a quantile from a Prometheus histogram's cumulative buckets (upper bound of the bucket)."""
    buckets, total = [], 0
    for metric in hist.collect():
        for s in metric.samples:
            if s.name.endswith("_bucket") and (label_values is None or
                                               all(s.labels.get(k) == v for k, v in label_values.items())):
                buckets.append((float(s.labels["le"]), s.value))
            if s.name.endswith("_count") and (label_values is None or
                                              all(s.labels.get(k) == v for k, v in label_values.items())):
                total += s.value
    if not total:
        return None
    for le, cum in sorted(buckets):
        if cum >= q * total:
            return le
    return None


@app.get("/ops/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, authorization: Optional[str] = Header(None)):
    authorise(request, authorization, ("ops_analyst", "finance_controller"), "OPS_DASHBOARD")
    with db.tx("fw_report", "dashboard") as cur:
        cur.execute("SELECT * FROM v_ops_health")
        h = cur.fetchone()
        cur.execute("SELECT chain_ok FROM verify_audit_chain()")
        chain_ok = cur.fetchone()["chain_ok"]
    with db.tx("fw_txn", "dashboard") as cur:
        cur.execute("""SELECT transaction_reference, status::text, status_reason, amount_minor, updated_at
                         FROM transfer ORDER BY updated_at DESC LIMIT 10""")
        recent = cur.fetchall()
        cur.execute("""SELECT e.kind, e.owner_role, e.detail, t.transaction_reference FROM ops_exception e
                       LEFT JOIN transfer t USING (transfer_id) WHERE e.state = 'OPEN' ORDER BY e.opened_at LIMIT 8""")
        exceptions = cur.fetchall()
        cur.execute("""SELECT at, actor, action, outcome FROM audit_log WHERE outcome = 'DENIED'
                        ORDER BY audit_id DESC LIMIT 6""")
        denials = cur.fetchall()
    accept_p95 = _hist_quantile(ACCEPT_LATENCY, 0.95)
    total_posts = sum(s.value for m in HTTP_REQUESTS.collect() for s in m.samples
                      if s.name.endswith("_total") and s.labels.get("route") == "/v1/transfers"
                      and s.labels.get("method") == "POST")
    errors_5xx = sum(s.value for m in HTTP_REQUESTS.collect() for s in m.samples
                     if s.name.endswith("_total") and s.labels.get("route") == "/v1/transfers"
                     and s.labels.get("method") == "POST" and s.labels.get("status", "").startswith("5"))
    avail = 100.0 * (1 - errors_5xx / total_posts) if total_posts else None

    def ok(flag):
        return '<span class="ok">MET</span>' if flag else '<span class="bad">BREACH</span>'

    slos = [
        ("Accept latency p95 (before rail)", "&lt; 500 ms",
         f"{accept_p95 * 1000:.0f} ms (bucket bound)" if accept_p95 else "no traffic", accept_p95 is None or accept_p95 <= 0.5),
        ("Accept path availability", "&ge; 99.9 %", f"{avail:.2f} %" if avail is not None else "no traffic",
         avail is None or avail >= 99.9),
        ("Settlement time p95, 24 h", "&le; 10 s", f"{float(h['settle_p95_seconds_24h']):.2f} s",
         float(h["settle_p95_seconds_24h"]) <= 10),
        ("Oldest PENDING transfer", "&lt; 15 min", f"{h['pending_oldest_seconds']} s", h["pending_oldest_seconds"] < 900),
        ("Outbox lag (oldest unpublished)", "&lt; 5 s", f"{h['outbox_oldest_seconds']} s", h["outbox_oldest_seconds"] < 5),
        ("Overdue reconciliation breaks", "0", str(h["overdue_breaks"]), h["overdue_breaks"] == 0),
        ("Ledger controls (trial balance, projection, float, system accounts)", "always true",
         f"{h['trial_balance_ok']} / {h['projection_ok']} / {h['float_invariant_ok']} / {h['system_accounts_ok']}",
         h["trial_balance_ok"] and h["projection_ok"] and h["float_invariant_ok"] and h["system_accounts_ok"]),
        ("Audit chain intact", "always true", str(chain_ok), chain_ok),
    ]
    tiles = [("Pending", h["pending_count"]), ("Stuck POSTED", h["posted_stuck_count"]),
             ("Outbox unpublished", h["outbox_unpublished"]), ("Dead letters", h["dlq_open"]),
             ("Open breaks", h["open_breaks"]), ("Open cases", h["open_cases"]),
             ("Exception queue", h["open_exceptions"]), ("Audit denials", h["audit_denials"]),
             ("Rate-limited (1 h)", h["rate_limited_last_hour"]), ("AI awaiting review", h["ai_awaiting_review"]),
             ("AI accepted / rejected", f"{h['ai_accepted']} / {h['ai_rejected']}"), ("AI abstained", h["ai_abstained"]),
             ("Written off (Rs)", f"{(h['written_off_minor'] or 0) / 100:,.0f}")]
    e = html.escape
    rows_slo = "".join(f"<tr><td>{n}</td><td>{t}</td><td>{v}</td><td>{ok(f)}</td></tr>" for n, t, v, f in slos)
    rows_recent = "".join(f"<tr><td>{e(r['transaction_reference'])}</td><td><b>{e(r['status'])}</b></td>"
                          f"<td>{e(r['status_reason'] or '')}</td><td class='num'>{r['amount_minor'] / 100:,.2f}</td>"
                          f"<td>{r['updated_at']:%H:%M:%S}</td></tr>" for r in recent)
    rows_exc = "".join(f"<tr><td>{e(x['kind'])}</td><td>{e(x['owner_role'])}</td><td>{e(x['transaction_reference'] or '')}"
                       f"</td><td>{e(x['detail'][:70])}</td></tr>" for x in exceptions) or \
        "<tr><td colspan=4>none</td></tr>"
    rows_den = "".join(f"<tr><td>{d['at']:%H:%M:%S}</td><td>{e(d['actor'])}</td><td>{e(d['action'])}</td></tr>"
                       for d in denials) or "<tr><td colspan=3>none</td></tr>"
    status_chips = " ".join(f"<span class='chip'>{e(k)} <b>{v}</b></span>"
                            for k, v in sorted((h["transfers_by_status"] or {}).items()))
    tiles_html = "".join(f"<div class='tile'><div class='v'>{v}</div><div class='k'>{k}</div></div>" for k, v in tiles)
    page = f"""<!doctype html><html><head><meta charset="utf-8"><title>FastWallet operations</title>
<style>
body{{font-family:Arial,Helvetica,sans-serif;margin:24px;color:#1d2433;background:#f6f7f9}}
h1{{font-size:20px;margin:0 0 4px}} h2{{font-size:14px;margin:18px 0 8px;color:#3a4660}}
.sub{{color:#66708a;font-size:12px;margin-bottom:12px}}
.tiles{{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}}
.tile{{background:#fff;border:1px solid #dde1e8;border-radius:6px;padding:10px}}
.tile .v{{font-size:22px;font-weight:bold}} .tile .k{{font-size:11px;color:#66708a}}
table{{border-collapse:collapse;width:100%;background:#fff;font-size:12px}}
td,th{{border:1px solid #dde1e8;padding:5px 8px;text-align:left}} th{{background:#eef1f6}}
.num{{text-align:right}} .ok{{color:#11733a;font-weight:bold}} .bad{{color:#b3261e;font-weight:bold}}
.chip{{display:inline-block;background:#fff;border:1px solid #dde1e8;border-radius:12px;padding:2px 8px;margin:2px;font-size:12px}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
</style></head><body>
<h1>FastWallet operations dashboard</h1>
<div class="sub">Synthetic data. Generated {dt.datetime.now():%Y-%m-%d %H:%M:%S}. Live metrics for scraping: /metrics</div>
<div class="tiles">{tiles_html}</div>
<h2>Transfers by status</h2><div>{status_chips or 'none'}</div>
<h2>Service level objectives</h2>
<table><tr><th>SLI</th><th>Target</th><th>Current</th><th>State</th></tr>{rows_slo}</table>
<div class="grid"><div><h2>Latest transfers</h2>
<table><tr><th>Reference</th><th>Status</th><th>Reason</th><th>Rs</th><th>Updated</th></tr>{rows_recent}</table></div>
<div><h2>Manual exception queue</h2>
<table><tr><th>Kind</th><th>Owner</th><th>Transfer</th><th>Detail</th></tr>{rows_exc}</table>
<h2>Latest denied actions (audit log)</h2>
<table><tr><th>Time</th><th>Actor</th><th>Action</th></tr>{rows_den}</table></div></div>
</body></html>"""
    return HTMLResponse(page)
