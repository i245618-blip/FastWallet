"""Authentication and authorisation (mocked identity provider, real enforcement).

Tokens are HS256 JWTs signed with FW_JWT_SECRET (from the environment, never committed). Claims:
  sub        customer_ref for customers (CUST-0004) or the staff username (ops.demo1)
  roles      list, one of customer, ops_analyst, compliance_officer, finance_controller, system_recovery
  client_id  the calling application, scope for idempotency keys
  mfa        true when the second factor was completed in this session (SBP 2FA rule, R09)
Every denial is written to the hash-chained audit log and counted in fw_auth_denials_total.
"""
import time
from dataclasses import dataclass

import jwt

from .config import settings
from .errors import ApiError

ROLES = {"customer", "ops_analyst", "compliance_officer", "finance_controller", "system_recovery"}


@dataclass
class Principal:
    sub: str
    roles: list
    client_id: str
    mfa: bool

    @property
    def role(self) -> str:
        return self.roles[0] if self.roles else ""

    def has(self, *roles) -> bool:
        return any(r in self.roles for r in roles)


def _secret() -> str:
    if not settings.jwt_secret or len(settings.jwt_secret) < 32:
        raise RuntimeError("FW_JWT_SECRET must be set (32+ characters); see infra/.env.example")
    return settings.jwt_secret


def issue_token(sub: str, roles: list, client_id: str = "fw-app", mfa: bool = False, ttl: int = 3600) -> str:
    now = int(time.time())
    return jwt.encode({"sub": sub, "roles": roles, "client_id": client_id, "mfa": mfa,
                       "iat": now, "exp": now + ttl, "iss": "fw-mock-idp"}, _secret(), algorithm="HS256")


def decode(authorization: str | None) -> Principal:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise ApiError(401, "UNAUTHENTICATED", "bearer token required")
    try:
        claims = jwt.decode(authorization.split(" ", 1)[1], _secret(), algorithms=["HS256"],
                            options={"require": ["sub", "exp"]}, issuer="fw-mock-idp")
    except jwt.ExpiredSignatureError:
        raise ApiError(401, "UNAUTHENTICATED", "token expired")
    except jwt.PyJWTError:
        raise ApiError(401, "UNAUTHENTICATED", "token invalid")
    roles = [r for r in claims.get("roles", []) if r in ROLES]
    if not roles:
        raise ApiError(401, "UNAUTHENTICATED", "token carries no known role")
    return Principal(sub=str(claims["sub"]), roles=roles, client_id=str(claims.get("client_id", "unknown")),
                     mfa=bool(claims.get("mfa", False)))
