"""Mock instant-payment rail (proposed simplified contract, NOT real Raast messages).

Operations: submit, status enquiry, daily statement. The rail deduplicates on request_id, as a real rail
would on the end-to-end reference: submitting the same request id twice never pays twice.

Behaviour is scripted through /_control so tests and the demo can make the rail misbehave on purpose:
  SUCCESS               execute and answer at once
  REJECT                reject (beneficiary account closed)
  TIMEOUT_EXECUTED      execute, then answer too late (the caller times out; money did move)
  TIMEOUT_NOT_EXECUTED  answer too late and do NOT execute (the request was lost)
  UNAVAILABLE           answer 503 without executing
  DUPLICATE_ACK         execute, answer, then send the signed acknowledgement callback twice
Enquiries can be scripted too (ENQ_TIMEOUT answers too late). State is kept in a JSON file so the rail
survives restarts of our services (and of itself).
"""
import asyncio
import datetime as dt
import hashlib
import hmac
import json
import os
import pathlib
import threading

import httpx
from fastapi import FastAPI, Response

app = FastAPI(title="Mock payment rail (synthetic)")
STATE_FILE = pathlib.Path(os.environ.get("RAIL_STATE_FILE", "/tmp/fw_rail_state.json"))
SLOW_SECONDS = float(os.environ.get("RAIL_SLOW_SECONDS", "8"))
ACK_URL = os.environ.get("FW_ACK_URL", "")
ACK_SECRET = os.environ.get("FW_RAIL_ACK_SECRET", "")
_lock = threading.Lock()


def _empty():
    return {"payments": {}, "submit_counts": {}, "script": [], "enquiry_script": [], "extra_lines": [], "seq": 0}


def _load():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return _empty()


def _save(s):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(s))
    tmp.replace(STATE_FILE)


def _execute(s, req, status):
    s["seq"] += 1
    p = {"request_id": req["request_id"], "amount_minor": req["amount_minor"], "status": status,
         "rail_reference": f"RAIL-SYN-{s['seq']:06d}", "date": dt.date.today().isoformat(),
         "returned": False, "reason": "BENEFICIARY_ACCOUNT_CLOSED" if status == "REJECTED" else None}
    s["payments"][req["request_id"]] = p
    return p


def _public(p):
    status = "RETURNED" if p.get("returned") else p["status"]
    out = {"status": status, "rail_reference": p["rail_reference"], "amount_minor": p["amount_minor"]}
    if p.get("reason"):
        out["reason"] = p["reason"]
    return out


async def _send_acks(payment, times):
    body = json.dumps({"request_id": payment["request_id"], "status": _public(payment)["status"],
                       "rail_reference": payment["rail_reference"]}).encode()
    sig = hmac.new(ACK_SECRET.encode(), body, hashlib.sha256).hexdigest()
    async with httpx.AsyncClient(timeout=5) as c:
        for _ in range(times):
            try:
                await c.post(ACK_URL, content=body, headers={"X-Rail-Signature": sig,
                                                             "Content-Type": "application/json"})
            except httpx.HTTPError:
                pass


@app.post("/rail/v1/payments")
async def submit(req: dict, response: Response):
    with _lock:
        s = _load()
        rid = req["request_id"]
        s["submit_counts"][rid] = s["submit_counts"].get(rid, 0) + 1
        if rid in s["payments"]:                         # duplicate submit: same answer, no second payment
            _save(s)
            return {**_public(s["payments"][rid]), "duplicate": True}
        mode = s["script"].pop(0) if s["script"] else "SUCCESS"
        payment = None
        if mode in ("SUCCESS", "TIMEOUT_EXECUTED", "DUPLICATE_ACK"):
            payment = _execute(s, req, "EXECUTED")
        elif mode == "REJECT":
            payment = _execute(s, req, "REJECTED")
        _save(s)
    if mode in ("TIMEOUT_EXECUTED", "TIMEOUT_NOT_EXECUTED"):
        await asyncio.sleep(SLOW_SECONDS)
        if payment is None:
            response.status_code = 504
            return {"status": "UNKNOWN"}
    if mode == "UNAVAILABLE":
        response.status_code = 503
        return {"status": "UNKNOWN"}
    if mode == "DUPLICATE_ACK" and ACK_URL:
        asyncio.get_running_loop().create_task(_send_acks(payment, 2))
    return _public(payment)


@app.get("/rail/v1/payments/{request_id}")
async def enquiry(request_id: str, response: Response):
    with _lock:
        s = _load()
        mode = s["enquiry_script"].pop(0) if s["enquiry_script"] else "NORMAL"
        _save(s)
        p = s["payments"].get(request_id)
    if mode == "ENQ_TIMEOUT":
        await asyncio.sleep(SLOW_SECONDS)
    if not p:
        response.status_code = 404
        return {"status": "NOT_FOUND"}
    return _public(p)


@app.get("/rail/v1/statements/{date}")
def statement(date: str):
    s = _load()
    lines = []
    for p in s["payments"].values():
        if p.get("returned") and p.get("return_date") == date and p["date"] != date:
            lines.append({"request_id": p["request_id"], "rail_reference": p["rail_reference"],
                          "amount_minor": p["amount_minor"], "rail_status": "RETURNED"})
        if p["date"] != date:
            continue
        lines.append({"request_id": p["request_id"], "rail_reference": p["rail_reference"],
                      "amount_minor": p["amount_minor"], "rail_status": p["status"]})
        if p.get("returned") and p.get("return_date", p["date"]) == p["date"]:
            lines.append({"request_id": p["request_id"], "rail_reference": p["rail_reference"],
                          "amount_minor": p["amount_minor"], "rail_status": "RETURNED"})
    lines += [ln for ln in s["extra_lines"] if ln.get("date", date) == date]
    return {"date": date, "lines": lines}


# ---------------------------------------------------------------- control plane (tests and demo only)

@app.post("/_control/reset")
def reset():
    with _lock:
        _save(_empty())
    return {"ok": True}


@app.post("/_control/script")
def script(body: dict):
    with _lock:
        s = _load()
        s["script"] += body.get("modes", [])
        s["enquiry_script"] += body.get("enquiry_modes", [])
        _save(s)
    return {"script": s["script"], "enquiry_script": s["enquiry_script"]}


@app.post("/_control/return/{request_id}")
async def mark_returned(request_id: str, ack: bool = False, return_date: str | None = None):
    """The beneficiary bank sends the money back. With return_date the RETURNED line appears on that day's
    statement (a late return); with ack=true the rail also sends the signed RETURNED acknowledgement."""
    with _lock:
        s = _load()
        s["payments"][request_id]["returned"] = True
        if return_date:
            s["payments"][request_id]["return_date"] = return_date
        _save(s)
    p = s["payments"][request_id]
    if ack and ACK_URL:
        await _send_acks(p, 1)
    return _public(p)


@app.post("/_control/extra_line")
def extra_line(body: dict):
    with _lock:
        s = _load()
        s["extra_lines"].append(body)
        _save(s)
    return {"ok": True}


@app.get("/_control/stats")
def stats():
    s = _load()
    return {"submit_counts": s["submit_counts"], "payments": len(s["payments"]),
            "executed": sum(1 for p in s["payments"].values() if p["status"] == "EXECUTED")}


@app.get("/health")
def health():
    return {"ok": True}
