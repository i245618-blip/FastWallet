"""Outbox relay and the notification consumer (ADR-003).

Relay: reads unpublished outbox rows as fw_relay, hands each event to the registered consumers, then marks
it published. Delivery is at-least-once: a crash after dispatch and before the mark re-delivers the event.

Notification consumer (fw_notify): validates the event against the Week 10 schema, records the event id in
inbox_event first (duplicate-safe), ignores events older than the last one applied for that transfer,
checks SERVICE_NOTIFICATIONS consent and writes a notification_log row. Poison events go to
dead_letter_event. It never writes to transfers or the ledger: it holds no financial truth.
"""
import json
import pathlib

import psycopg2
from jsonschema import Draft202012Validator, FormatChecker

from . import db
from .errors import ApiError
from .observability import DLQ_ACTIONS, EVENTS_CONSUMED, log_event, mask, set_correlation_id

SCHEMA_PATH = pathlib.Path(__file__).resolve().parents[2] / "api/events/transfer-status-changed.v1.schema.json"
VALIDATOR = Draft202012Validator(json.loads(SCHEMA_PATH.read_text()), format_checker=FormatChecker())
CONSUMER = "notification"

MESSAGES = {
    "POSTED": "Your transfer {ref} of Rs {amt} is on its way.",
    "PENDING": "Your transfer {ref} is taking longer than usual. Your money is safe; we are confirming with the bank.",
    "SETTLED": "Your transfer {ref} of Rs {amt} has reached the bank.",
    "REVERSED": "Your transfer {ref} was returned. Rs {amt} is back in your wallet.",
    "FAILED": "Your transfer {ref} could not be completed. No money left your wallet.",
    "HELD": "Your transfer {ref} is being reviewed. We will update you shortly.",
}


def notify(event: dict) -> str:
    """Handle one transfer.status.changed event. Returns the result label."""
    errors = sorted(VALIDATOR.iter_errors(event), key=str)
    if errors:
        with db.tx("fw_notify", "notification-service") as cur:
            cur.execute("INSERT INTO dead_letter_event (consumer_name, event_id, payload, error) VALUES (%s, %s, %s, %s)",
                        (CONSUMER, _uuid_or_none(event.get("event_id")), json.dumps(event),
                         "SCHEMA_INVALID: " + errors[0].message[:200]))
        EVENTS_CONSUMED.labels(CONSUMER, "DEAD_LETTER").inc()
        log_event("event_dead_lettered", level=30, consumer=CONSUMER, reason=errors[0].message[:120])
        return "DEAD_LETTER"

    set_correlation_id(event["correlation_id"])
    with db.tx("fw_notify", "notification-service") as cur:
        # rowcount, not RETURNING: fw_notify may insert into the inbox but not read it back
        cur.execute("INSERT INTO inbox_event (consumer_name, event_id) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                    (CONSUMER, event["event_id"]))
        if cur.rowcount == 0:
            EVENTS_CONSUMED.labels(CONSUMER, "DUPLICATE").inc()
            log_event("event_duplicate_ignored", consumer=CONSUMER, event_id=event["event_id"])
            return "DUPLICATE"
        data, ref = event["data"], event["transaction_reference"]
        cur.execute("SELECT coalesce(max(sequence), 0) AS s FROM notification_log WHERE transfer_id = %s",
                    (event["transfer_id"],))
        last = cur.fetchone()["s"]
        cur.execute("""SELECT c.mobile_msisdn,
                              EXISTS (SELECT 1 FROM consent_record r WHERE r.customer_id = c.customer_id
                                        AND r.purpose = 'SERVICE_NOTIFICATIONS' AND r.withdrawn_at IS NULL) AS ok
                         FROM customer c WHERE c.customer_ref = %s""", (data.get("customer_ref"),))
        cust = cur.fetchone()
        if event["sequence"] <= last:
            outcome, msg = "SKIPPED_STALE", None
        elif data["status"] not in MESSAGES:
            outcome, msg = "NOT_NOTIFIABLE", None
        elif not cust or not cust["ok"]:
            outcome, msg = "SUPPRESSED_NO_CONSENT", None
        else:
            outcome = "SENT"
            msg = MESSAGES[data["status"]].format(ref=ref, amt=f"{data['amount']['minor_units'] / 100:,.2f}")
        cur.execute("""INSERT INTO notification_log (event_id, transfer_id, customer_ref, sequence, status, outcome,
                                                     masked_msisdn, message, correlation_id)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (event["event_id"], event["transfer_id"], data.get("customer_ref") or "unknown",
                     event["sequence"], data["status"], outcome,
                     mask(cust["mobile_msisdn"]) if cust and outcome == "SENT" else None, msg, event["correlation_id"]))
    EVENTS_CONSUMED.labels(CONSUMER, outcome).inc()
    log_event("notification_processed", consumer=CONSUMER, transaction_reference=ref, status=data["status"],
              outcome=outcome, sequence=event["sequence"])
    return outcome


def _uuid_or_none(v):
    import uuid
    try:
        return str(uuid.UUID(str(v)))
    except (ValueError, TypeError):
        return None


CONSUMERS = [notify]


# ---------------------------------------------------------------- dead-letter replay and discard (Week 14)

def _dlq_row(cur, dlq_id):
    cur.execute("SELECT dlq_id, consumer_name, event_id, payload, error, attempts, state FROM dead_letter_event "
                "WHERE dlq_id = %s FOR UPDATE", (dlq_id,))
    row = cur.fetchone()
    if not row:
        raise ApiError(404, "NOT_FOUND", "dead letter not found")
    if row["state"] != "OPEN":
        raise ApiError(422, "INVALID_STATE_TRANSITION", f"dead letter is already {row['state']}")
    return row


def replay_dead_letter(dlq_id: int, actor: str) -> dict:
    """Run the consumer again on a dead-lettered event (after the cause was fixed). The event is never edited.

    Still invalid -> stays OPEN with one more attempt. Valid -> handed to the normal consumer, which is
    duplicate-safe, so a replay can never send the same notification twice. Marked REPLAYED.
    """
    with db.tx("fw_notify", actor) as cur:
        row = _dlq_row(cur, dlq_id)
        errors = sorted(VALIDATOR.iter_errors(row["payload"]), key=str)
        if errors:
            cur.execute("UPDATE dead_letter_event SET attempts = attempts + 1, last_attempt_at = now() WHERE dlq_id = %s",
                        (dlq_id,))
            DLQ_ACTIONS.labels("replay", "STILL_INVALID").inc()
            return {"dlq_id": dlq_id, "result": "STILL_INVALID", "state": "OPEN", "attempts": row["attempts"] + 1,
                    "error": errors[0].message[:200]}
    outcome = notify(row["payload"])           # its own transaction, inbox-deduplicated
    with db.tx("fw_notify", actor) as cur:
        cur.execute("""UPDATE dead_letter_event SET state = 'REPLAYED', attempts = attempts + 1, last_attempt_at = now(),
                              resolved_by = %s, resolved_at = now(), resolution_note = %s
                        WHERE dlq_id = %s AND state = 'OPEN'""", (actor, f"replayed: consumer result {outcome}", dlq_id))
    DLQ_ACTIONS.labels("replay", outcome).inc()
    log_event("dead_letter_replayed", dlq_id=dlq_id, result=outcome)
    return {"dlq_id": dlq_id, "result": outcome, "state": "REPLAYED", "attempts": row["attempts"] + 1}


def discard_dead_letter(dlq_id: int, actor: str, reason: str) -> dict:
    with db.tx("fw_notify", actor) as cur:
        _dlq_row(cur, dlq_id)
        cur.execute("""UPDATE dead_letter_event SET state = 'DISCARDED', resolved_by = %s, resolved_at = now(),
                              resolution_note = %s WHERE dlq_id = %s""", (actor, reason, dlq_id))
    DLQ_ACTIONS.labels("discard", "DISCARDED").inc()
    log_event("dead_letter_discarded", dlq_id=dlq_id)
    return {"dlq_id": dlq_id, "result": "DISCARDED", "state": "DISCARDED"}


def relay_once(limit: int = 200) -> int:
    """Publish up to `limit` events in commit order. Returns the number published."""
    with db.tx("fw_relay", "outbox-relay") as cur:
        cur.execute("""SELECT event_id, payload FROM outbox_event WHERE published_at IS NULL
                        ORDER BY created_at, sequence LIMIT %s FOR UPDATE SKIP LOCKED""", (limit,))
        rows = cur.fetchall()
        published = 0
        for r in rows:
            try:
                for consumer in CONSUMERS:
                    consumer(r["payload"])
                cur.execute("UPDATE outbox_event SET published_at = now(), publish_attempts = publish_attempts + 1 "
                            "WHERE event_id = %s", (r["event_id"],))
                published += 1
            except psycopg2.Error as exc:     # consumer store unavailable: leave unpublished, retry next round
                cur.execute("UPDATE outbox_event SET publish_attempts = publish_attempts + 1 WHERE event_id = %s",
                            (r["event_id"],))
                log_event("relay_delivery_failed", level=30, event_id=str(r["event_id"]), error=str(exc)[:120])
    return published
