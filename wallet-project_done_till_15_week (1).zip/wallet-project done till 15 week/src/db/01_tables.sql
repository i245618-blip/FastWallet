-- FastWallet data layer, PostgreSQL 16
-- CS3017 semester project, Week 12 (data / control gate)
-- Synthetic model only. No real customer, CNIC, account or card data belongs in any of these tables.
--
-- Apply order: 01_tables.sql, 02_integrity.sql, 03_reconciliation.sql, 04_reference_data.sql

DROP SCHEMA IF EXISTS fw CASCADE;
CREATE SCHEMA fw;
SET search_path = fw, public;

-- ---------------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------------
CREATE TYPE transfer_status AS ENUM
  ('INITIATED','HELD','AUTHORISED','POSTED','PENDING','SETTLED','RECONCILED','REVERSED','FAILED');
CREATE TYPE entry_direction AS ENUM ('DEBIT','CREDIT');
CREATE TYPE account_type    AS ENUM ('ASSET','LIABILITY','REVENUE','EXPENSE');
CREATE TYPE journal_type    AS ENUM
  ('FUNDING','TRANSFER_POST','TRANSFER_SETTLE','TRANSFER_REVERSE','TRANSFER_RETURN','RECON_ADJUSTMENT');
CREATE TYPE break_type      AS ENUM
  ('UNMATCHED_INTERNAL','UNMATCHED_EXTERNAL','DUPLICATE','MISSING','AMOUNT_MISMATCH','STATUS_MISMATCH');

-- ---------------------------------------------------------------------------
-- Identity, consent and KYC
-- ---------------------------------------------------------------------------
CREATE TABLE tier_policy (
  tier                 smallint PRIMARY KEY,
  name                 text    NOT NULL,
  can_send_to_bank     boolean NOT NULL,
  per_txn_limit_minor  bigint  NOT NULL CHECK (per_txn_limit_minor  >= 0),
  daily_limit_minor    bigint  NOT NULL CHECK (daily_limit_minor    >= 0),
  monthly_limit_minor  bigint  NOT NULL CHECK (monthly_limit_minor  >= 0),
  verification_needed  text    NOT NULL
);

CREATE TABLE customer (
  customer_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_ref      text NOT NULL UNIQUE,                  -- opaque reference used in events and logs
  full_name         text NOT NULL,                         -- synthetic
  mobile_msisdn     text NOT NULL UNIQUE,                  -- synthetic
  national_id_token text NOT NULL UNIQUE,                  -- salted hash or vault token, never the raw number
  kyc_tier          smallint NOT NULL REFERENCES tier_policy(tier),
  status            text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED','CLOSED')),
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE consent_record (
  consent_id     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id    uuid NOT NULL REFERENCES customer(customer_id),
  purpose        text NOT NULL CHECK (purpose IN
                   ('KYC_VERIFICATION','TRANSACTION_PROCESSING','SERVICE_NOTIFICATIONS','AUTOMATED_ASSISTANCE')),
  notice_version text NOT NULL,
  channel        text NOT NULL DEFAULT 'APP',
  granted_at     timestamptz NOT NULL DEFAULT now(),
  withdrawn_at   timestamptz,
  CHECK (withdrawn_at IS NULL OR withdrawn_at >= granted_at)
);

CREATE TABLE kyc_decision (
  kyc_decision_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id        uuid NOT NULL REFERENCES customer(customer_id),
  method             text NOT NULL CHECK (method IN ('OTP_CALLBACK','BIOMETRIC_SIMULATED','MANUAL_REVIEW')),
  result             text NOT NULL CHECK (result IN ('PASSED','FAILED','REFER')),
  tier_granted       smallint REFERENCES tier_policy(tier),
  watchlist_prescreen text NOT NULL CHECK (watchlist_prescreen IN ('CLEAR','POTENTIAL_MATCH')),
  evidence           jsonb NOT NULL,
  decided_by         text NOT NULL,
  decided_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE watchlist_entry (            -- synthetic names only, used by rule R07
  entry_id    bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  list_source text NOT NULL DEFAULT 'SYNTHETIC',
  full_name   text NOT NULL
);

CREATE TABLE app_user (
  user_id  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE,
  role     text NOT NULL CHECK (role IN ('ops_analyst','compliance_officer','finance_controller','system_recovery')),
  active   boolean NOT NULL DEFAULT true
);

-- ---------------------------------------------------------------------------
-- Ledger
-- ---------------------------------------------------------------------------
CREATE TABLE ledger_account (
  account_id     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code           text NOT NULL UNIQUE,
  name           text NOT NULL,
  account_type   account_type NOT NULL,
  normal_side    entry_direction NOT NULL,
  allow_negative boolean NOT NULL DEFAULT false,
  CHECK ((account_type IN ('ASSET','EXPENSE')    AND normal_side = 'DEBIT')
      OR (account_type IN ('LIABILITY','REVENUE') AND normal_side = 'CREDIT'))
);

CREATE TABLE wallet (
  wallet_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id       uuid NOT NULL UNIQUE REFERENCES customer(customer_id),
  ledger_account_id uuid NOT NULL UNIQUE REFERENCES ledger_account(account_id),
  currency          char(3) NOT NULL DEFAULT 'PKR' CHECK (currency = 'PKR'),
  status            text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','FROZEN','CLOSED')),
  opened_at         timestamptz NOT NULL DEFAULT now()
);

-- Projection of entries, maintained by trigger in the same transaction as the entry.
-- Always rebuildable from ledger_entry (see v_balance_projection_check).
CREATE TABLE account_balance (
  account_id    uuid PRIMARY KEY REFERENCES ledger_account(account_id),
  balance_minor bigint NOT NULL DEFAULT 0,      -- signed in the account's normal direction
  last_entry_id bigint,
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Transfers
-- ---------------------------------------------------------------------------
CREATE SEQUENCE transfer_ref_seq;

CREATE TABLE transfer (
  transfer_id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_reference  text NOT NULL UNIQUE
        DEFAULT ('FW-' || to_char(now(), 'YYYYMMDD') || '-' || lpad(nextval('transfer_ref_seq')::text, 6, '0'))
        CHECK (transaction_reference ~ '^FW-[0-9]{8}-[0-9]{6}$'),
  client_id              text NOT NULL,
  source_wallet_id       uuid NOT NULL REFERENCES wallet(wallet_id),
  beneficiary_scheme     text NOT NULL CHECK (beneficiary_scheme IN ('IBAN','RAAST_ID')),
  beneficiary_identifier text NOT NULL,
  beneficiary_name       text,
  amount_minor           bigint NOT NULL CHECK (amount_minor > 0 AND amount_minor <= 20000000),
  currency               char(3) NOT NULL DEFAULT 'PKR' CHECK (currency = 'PKR'),
  purpose                text NOT NULL CHECK (purpose IN ('FAMILY_SUPPORT','BILL_SHARE','SAVINGS','PURCHASE','OTHER')),
  customer_note          text CHECK (char_length(customer_note) <= 140),
  status                 transfer_status NOT NULL DEFAULT 'INITIATED',
  status_reason          text,
  rail_reference         text,
  correlation_id         uuid NOT NULL,
  version                integer NOT NULL DEFAULT 1,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_transfer_wallet_created ON transfer (source_wallet_id, created_at);
CREATE INDEX ix_transfer_status         ON transfer (status);

CREATE TABLE allowed_transition (
  from_status transfer_status NOT NULL,
  to_status   transfer_status NOT NULL,
  PRIMARY KEY (from_status, to_status)
);

CREATE TABLE transfer_state_history (
  transfer_id    uuid NOT NULL REFERENCES transfer(transfer_id),
  sequence       integer NOT NULL,
  from_status    transfer_status,
  to_status      transfer_status NOT NULL,
  reason         text,
  actor          text NOT NULL,
  correlation_id uuid NOT NULL,
  changed_at     timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (transfer_id, sequence)
);

CREATE TABLE idempotency_record (
  client_id       text NOT NULL,
  idem_key        text NOT NULL,
  request_hash    char(64) NOT NULL,
  state           text NOT NULL CHECK (state IN ('IN_PROGRESS','COMPLETED')),
  transfer_id     uuid REFERENCES transfer(transfer_id),
  response_status integer,
  response_body   jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  expires_at      timestamptz NOT NULL DEFAULT now() + interval '72 hours',
  PRIMARY KEY (client_id, idem_key)
);

CREATE TABLE journal_entry (
  journal_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id         uuid REFERENCES transfer(transfer_id),
  journal_type        journal_type NOT NULL,
  funding_reference   text,
  description         text,
  reverses_journal_id uuid REFERENCES journal_entry(journal_id),
  correlation_id      uuid,
  posted_at           timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK ((journal_type = 'FUNDING') = (funding_reference IS NOT NULL)),
  CHECK (journal_type = 'FUNDING' OR transfer_id IS NOT NULL)
);
-- one journal of each type per transfer, and at most one reversal-style journal
CREATE UNIQUE INDEX uq_journal_per_transfer_type ON journal_entry (transfer_id, journal_type)
  WHERE transfer_id IS NOT NULL;
CREATE UNIQUE INDEX uq_journal_single_reversal ON journal_entry (transfer_id)
  WHERE journal_type IN ('TRANSFER_REVERSE','TRANSFER_RETURN');
CREATE UNIQUE INDEX uq_journal_funding_ref ON journal_entry (funding_reference)
  WHERE funding_reference IS NOT NULL;

CREATE TABLE ledger_entry (
  entry_id     bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  journal_id   uuid NOT NULL REFERENCES journal_entry(journal_id),
  leg_no       smallint NOT NULL,
  account_id   uuid NOT NULL REFERENCES ledger_account(account_id),
  direction    entry_direction NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0),
  posted_at    timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (journal_id, leg_no)
);
CREATE INDEX ix_ledger_entry_account ON ledger_entry (account_id);

-- ---------------------------------------------------------------------------
-- Events (transactional outbox, inbox, dead letters)
-- ---------------------------------------------------------------------------
CREATE TABLE outbox_event (
  event_id         uuid PRIMARY KEY,
  aggregate_type   text NOT NULL,
  aggregate_id     uuid NOT NULL,
  sequence         integer NOT NULL,
  event_type       text NOT NULL,
  schema_version   text NOT NULL,
  correlation_id   uuid NOT NULL,
  payload          jsonb NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT clock_timestamp(),
  published_at     timestamptz,
  publish_attempts integer NOT NULL DEFAULT 0,
  UNIQUE (aggregate_id, sequence)
);
CREATE INDEX ix_outbox_unpublished ON outbox_event (created_at) WHERE published_at IS NULL;

CREATE TABLE inbox_event (
  consumer_name text NOT NULL,
  event_id      uuid NOT NULL,
  processed_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (consumer_name, event_id)
);

CREATE TABLE dead_letter_event (
  dlq_id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  consumer_name   text NOT NULL,
  event_id        uuid,
  payload         jsonb NOT NULL,
  error           text NOT NULL,
  attempts        integer NOT NULL DEFAULT 1,
  state           text NOT NULL DEFAULT 'OPEN' CHECK (state IN ('OPEN','REPLAYED','DISCARDED')),
  first_failed_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Rail interaction log and statement
-- ---------------------------------------------------------------------------
CREATE TABLE rail_message_log (
  msg_id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  transfer_id    uuid REFERENCES transfer(transfer_id),
  rail_request_id text NOT NULL,
  operation      text NOT NULL CHECK (operation IN ('SUBMIT','ACK','ENQUIRY','ENQUIRY_RESULT')),
  outcome        text NOT NULL,
  payload        jsonb,
  correlation_id uuid,
  logged_at      timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE rail_statement_line (
  line_id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  statement_date  date NOT NULL,
  rail_request_id text NOT NULL,
  rail_reference  text,
  amount_minor    bigint NOT NULL CHECK (amount_minor > 0),
  rail_status     text NOT NULL CHECK (rail_status IN ('EXECUTED','REJECTED','RETURNED')),
  source_file     text,
  imported_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_statement_request ON rail_statement_line (rail_request_id);

-- ---------------------------------------------------------------------------
-- Compliance
-- ---------------------------------------------------------------------------
CREATE TABLE screening_rule (
  rule_id     text PRIMARY KEY,
  name        text NOT NULL,
  description text NOT NULL,
  outcome_on_hit text NOT NULL CHECK (outcome_on_hit IN ('STEP_UP','HOLD','BLOCK')),
  params      jsonb NOT NULL DEFAULT '{}'::jsonb,
  active      boolean NOT NULL DEFAULT true,
  version     integer NOT NULL DEFAULT 1
);

CREATE TABLE screening_decision (
  decision_id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id   uuid NOT NULL UNIQUE REFERENCES transfer(transfer_id),
  customer_id   uuid NOT NULL REFERENCES customer(customer_id),
  rules_version text NOT NULL,
  outcome       text NOT NULL CHECK (outcome IN ('ALLOW','STEP_UP','HOLD','BLOCK')),
  risk_score    smallint NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
  reason_codes  text[] NOT NULL DEFAULT '{}',
  inputs        jsonb NOT NULL,                -- snapshot of what the rules saw
  decided_by    text NOT NULL DEFAULT 'rules-engine',
  created_at    timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE compliance_case (
  case_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id  uuid NOT NULL UNIQUE REFERENCES transfer(transfer_id),
  decision_id  uuid NOT NULL REFERENCES screening_decision(decision_id),
  state        text NOT NULL DEFAULT 'OPEN' CHECK (state IN ('OPEN','RELEASED','REJECTED')),
  opened_at    timestamptz NOT NULL DEFAULT now(),
  due_at       timestamptz NOT NULL DEFAULT now() + interval '4 hours'
);

CREATE TABLE case_decision (
  case_decision_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id          uuid NOT NULL UNIQUE REFERENCES compliance_case(case_id),
  decision         text NOT NULL CHECK (decision IN ('RELEASE','REJECT')),
  rationale        text NOT NULL CHECK (char_length(rationale) >= 10),
  decided_by       uuid NOT NULL REFERENCES app_user(user_id),
  decided_at       timestamptz NOT NULL DEFAULT clock_timestamp()
);

-- ---------------------------------------------------------------------------
-- Reversals (maker / checker)
-- ---------------------------------------------------------------------------
CREATE TABLE reversal_request (
  reversal_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_transfer_id uuid NOT NULL REFERENCES transfer(transfer_id),
  reason_code          text NOT NULL CHECK (reason_code IN
                         ('CUSTOMER_DISPUTE','RAIL_RETURN','OPERATIONAL_ERROR','DUPLICATE_DETECTED')),
  reason_text          text NOT NULL CHECK (char_length(reason_text) >= 10),
  state                text NOT NULL DEFAULT 'PENDING_APPROVAL'
                         CHECK (state IN ('PENDING_APPROVAL','APPROVED','REJECTED','POSTED')),
  requested_by         uuid NOT NULL REFERENCES app_user(user_id),
  requested_at         timestamptz NOT NULL DEFAULT now(),
  decided_by           uuid REFERENCES app_user(user_id),
  decided_at           timestamptz,
  CHECK (decided_by IS NULL OR decided_by <> requested_by),
  CHECK ((state = 'PENDING_APPROVAL') = (decided_by IS NULL))
);
CREATE UNIQUE INDEX uq_open_reversal ON reversal_request (original_transfer_id)
  WHERE state IN ('PENDING_APPROVAL','APPROVED','POSTED');

-- ---------------------------------------------------------------------------
-- Reconciliation
-- ---------------------------------------------------------------------------
CREATE TABLE break_policy (
  break_type         break_type PRIMARY KEY,
  default_owner_role text NOT NULL,
  sla_hours          integer NOT NULL,
  auto_recoverable   boolean NOT NULL,
  description        text NOT NULL
);

CREATE TABLE recon_run (
  run_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  statement_date date NOT NULL,
  run_by         text NOT NULL,
  started_at     timestamptz NOT NULL DEFAULT clock_timestamp(),
  finished_at    timestamptz,
  matched_count  integer NOT NULL DEFAULT 0,
  new_break_count integer NOT NULL DEFAULT 0
);

CREATE TABLE recon_match (
  run_id          uuid NOT NULL REFERENCES recon_run(run_id),
  transfer_id     uuid NOT NULL REFERENCES transfer(transfer_id),
  rail_request_id text NOT NULL,
  matched_status  text NOT NULL,
  PRIMARY KEY (run_id, transfer_id)
);

CREATE TABLE recon_break (
  break_id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id                uuid NOT NULL REFERENCES recon_run(run_id),
  break_key             text NOT NULL,
  break_type            break_type NOT NULL,
  transfer_id           uuid REFERENCES transfer(transfer_id),
  rail_request_id       text,
  statement_line_id     bigint REFERENCES rail_statement_line(line_id),
  internal_amount_minor bigint,
  external_amount_minor bigint,
  detail                text,
  owner_role            text NOT NULL,
  state                 text NOT NULL DEFAULT 'OPEN' CHECK (state IN ('OPEN','IN_REVIEW','RESOLVED')),
  opened_at             timestamptz NOT NULL DEFAULT now(),
  due_at                timestamptz NOT NULL,
  resolution_code       text CHECK (resolution_code IN
                          ('MATCHED_LATE','COMPENSATED','WRITTEN_OFF_APPROVED','RAIL_CORRECTION_REQUESTED')),
  resolution_comment    text,
  resolved_by           uuid REFERENCES app_user(user_id),
  approved_by           uuid REFERENCES app_user(user_id),
  resolved_at           timestamptz,
  CHECK (state <> 'RESOLVED' OR (resolution_code IS NOT NULL AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL)),
  CHECK (resolution_code IS DISTINCT FROM 'WRITTEN_OFF_APPROVED'
         OR (approved_by IS NOT NULL AND approved_by <> resolved_by))
);
-- the same open break is never raised twice, so a re-run of reconciliation is harmless
CREATE UNIQUE INDEX uq_open_break ON recon_break (break_key) WHERE state <> 'RESOLVED';

-- ---------------------------------------------------------------------------
-- Audit (hash chained, append only)
-- ---------------------------------------------------------------------------
CREATE TABLE audit_log (
  audit_id       bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  at             timestamptz NOT NULL DEFAULT clock_timestamp(),
  actor          text NOT NULL,
  actor_role     text,
  action         text NOT NULL,
  object_type    text,
  object_id      text,
  outcome        text NOT NULL CHECK (outcome IN ('ALLOWED','DENIED','ERROR')),
  correlation_id uuid,
  details        jsonb,
  prev_hash      bytea,
  row_hash       bytea NOT NULL
);
