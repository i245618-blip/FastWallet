-- Integrity rules enforced inside the database.
-- Error messages start with a stable token (UNBALANCED_JOURNAL, INSUFFICIENT_FUNDS, ...) so the
-- Transaction Service can map them to the API error codes defined in api/openapi.yaml.
SET search_path = fw, public;

-- ---------------------------------------------------------------------------
-- Append-only tables
-- ---------------------------------------------------------------------------
CREATE FUNCTION forbid_mutation() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  RAISE EXCEPTION 'IMMUTABLE_RECORD: % on %.% is not allowed', TG_OP, TG_TABLE_SCHEMA, TG_TABLE_NAME;
END $$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['ledger_entry','journal_entry','transfer_state_history','kyc_decision',
                           'screening_decision','case_decision','rail_message_log','audit_log']
  LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_immutable BEFORE UPDATE OR DELETE ON %I
                    FOR EACH ROW EXECUTE FUNCTION forbid_mutation()', t, t);
    EXECUTE format('CREATE TRIGGER trg_%s_no_truncate BEFORE TRUNCATE ON %I
                    FOR EACH STATEMENT EXECUTE FUNCTION forbid_mutation()', t, t);
  END LOOP;
END $$;

-- outbox rows may only be marked as published
CREATE FUNCTION outbox_guard() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD: outbox rows are never deleted';
  END IF;
  IF (NEW.event_id, NEW.aggregate_id, NEW.sequence, NEW.payload, NEW.event_type, NEW.created_at)
     IS DISTINCT FROM (OLD.event_id, OLD.aggregate_id, OLD.sequence, OLD.payload, OLD.event_type, OLD.created_at) THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD: only published_at and publish_attempts may change on outbox_event';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_outbox_guard BEFORE UPDATE OR DELETE ON outbox_event
  FOR EACH ROW EXECUTE FUNCTION outbox_guard();

-- ---------------------------------------------------------------------------
-- Double entry: every journal balances, checked at commit
-- ---------------------------------------------------------------------------
CREATE FUNCTION assert_journal_balanced() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_diff bigint; v_n int;
BEGIN
  SELECT coalesce(sum(CASE direction WHEN 'DEBIT' THEN amount_minor ELSE -amount_minor END), 0), count(*)
    INTO v_diff, v_n
    FROM ledger_entry WHERE journal_id = NEW.journal_id;
  IF v_n < 2 OR v_diff <> 0 THEN
    RAISE EXCEPTION 'UNBALANCED_JOURNAL: journal % has % legs and a net difference of % minor units',
      NEW.journal_id, v_n, v_diff;
  END IF;
  RETURN NULL;
END $$;

CREATE CONSTRAINT TRIGGER trg_ledger_entry_balanced AFTER INSERT ON ledger_entry
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION assert_journal_balanced();
CREATE CONSTRAINT TRIGGER trg_journal_has_entries AFTER INSERT ON journal_entry
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION assert_journal_balanced();

-- ---------------------------------------------------------------------------
-- Balance projection and overdraft protection
-- ---------------------------------------------------------------------------
CREATE FUNCTION apply_entry_to_balance() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_side entry_direction; v_allow boolean; v_code text; v_delta bigint; v_new bigint;
BEGIN
  SELECT normal_side, allow_negative, code INTO v_side, v_allow, v_code
    FROM ledger_account WHERE account_id = NEW.account_id;
  v_delta := CASE WHEN NEW.direction = v_side THEN NEW.amount_minor ELSE -NEW.amount_minor END;

  INSERT INTO account_balance (account_id, balance_minor, last_entry_id)
  VALUES (NEW.account_id, v_delta, NEW.entry_id)
  ON CONFLICT (account_id) DO UPDATE
    SET balance_minor = account_balance.balance_minor + EXCLUDED.balance_minor,
        last_entry_id = EXCLUDED.last_entry_id,
        updated_at    = now()
  RETURNING balance_minor INTO v_new;

  IF v_new < 0 AND NOT v_allow THEN
    RAISE EXCEPTION 'INSUFFICIENT_FUNDS: account % would go to % minor units', v_code, v_new;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER trg_ledger_entry_balance AFTER INSERT ON ledger_entry
  FOR EACH ROW EXECUTE FUNCTION apply_entry_to_balance();

-- ---------------------------------------------------------------------------
-- Transfer state machine
-- ---------------------------------------------------------------------------
CREATE FUNCTION transfer_before_update() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  IF (NEW.transfer_id, NEW.transaction_reference, NEW.client_id, NEW.source_wallet_id,
      NEW.beneficiary_scheme, NEW.beneficiary_identifier, NEW.amount_minor, NEW.currency,
      NEW.correlation_id, NEW.created_at)
     IS DISTINCT FROM
     (OLD.transfer_id, OLD.transaction_reference, OLD.client_id, OLD.source_wallet_id,
      OLD.beneficiary_scheme, OLD.beneficiary_identifier, OLD.amount_minor, OLD.currency,
      OLD.correlation_id, OLD.created_at) THEN
    RAISE EXCEPTION 'IMMUTABLE_FIELD: reference, amount, beneficiary, wallet and correlation id cannot change';
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF NOT EXISTS (SELECT 1 FROM allowed_transition
                   WHERE from_status = OLD.status AND to_status = NEW.status) THEN
      RAISE EXCEPTION 'INVALID_STATE_TRANSITION: % -> % is not allowed', OLD.status, NEW.status;
    END IF;

    -- the status may only claim what the ledger already shows
    IF NEW.status IN ('POSTED') AND NOT EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_POST') THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: POSTED requires a TRANSFER_POST journal';
    END IF;
    IF NEW.status = 'SETTLED' AND NOT EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_SETTLE') THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: SETTLED requires a TRANSFER_SETTLE journal';
    END IF;
    IF NEW.status = 'REVERSED' THEN
      IF OLD.status = 'SETTLED' AND NOT EXISTS
         (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_RETURN') THEN
        RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: reversing a settled transfer requires a TRANSFER_RETURN journal';
      ELSIF OLD.status IN ('POSTED','PENDING') AND NOT EXISTS
         (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_REVERSE') THEN
        RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: reversing an unsettled transfer requires a TRANSFER_REVERSE journal';
      END IF;
    END IF;
    IF NEW.status = 'FAILED' AND EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id) THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: FAILED means nothing was posted';
    END IF;
    NEW.version := OLD.version + 1;
  END IF;
  NEW.updated_at := clock_timestamp();
  RETURN NEW;
END $$;
CREATE TRIGGER trg_transfer_before_update BEFORE UPDATE ON transfer
  FOR EACH ROW EXECUTE FUNCTION transfer_before_update();

-- history row and outbox event in the same transaction as the state change
CREATE FUNCTION transfer_after_change() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE
  v_prev  transfer_status;
  v_actor text := coalesce(nullif(current_setting('fw.actor', true), ''), 'system');
  v_cust  text;
  v_data  jsonb;
  v_event uuid := gen_random_uuid();
BEGIN
  IF TG_OP = 'UPDATE' THEN v_prev := OLD.status; END IF;
  SELECT c.customer_ref INTO v_cust
    FROM wallet w JOIN customer c USING (customer_id) WHERE w.wallet_id = NEW.source_wallet_id;

  INSERT INTO transfer_state_history (transfer_id, sequence, from_status, to_status, reason, actor, correlation_id)
  VALUES (NEW.transfer_id, NEW.version, v_prev, NEW.status, NEW.status_reason, v_actor, NEW.correlation_id);

  v_data := jsonb_build_object(
              'status', NEW.status::text,
              'previous_status', CASE WHEN v_prev IS NULL THEN 'null'::jsonb ELSE to_jsonb(v_prev::text) END,
              'amount', jsonb_build_object('currency', NEW.currency::text, 'minor_units', NEW.amount_minor),
              'customer_ref', v_cust)
         || CASE WHEN NEW.status_reason IS NULL THEN '{}'::jsonb
                 ELSE jsonb_build_object('status_reason', NEW.status_reason) END
         || CASE WHEN NEW.rail_reference IS NULL THEN '{}'::jsonb
                 ELSE jsonb_build_object('rail_reference', NEW.rail_reference) END;

  INSERT INTO outbox_event (event_id, aggregate_type, aggregate_id, sequence, event_type,
                            schema_version, correlation_id, payload)
  VALUES (v_event, 'transfer', NEW.transfer_id, NEW.version, 'transfer.status.changed',
          '1.0', NEW.correlation_id,
          jsonb_build_object(
            'event_id', v_event,
            'event_type', 'transfer.status.changed',
            'schema_version', '1.0',
            'occurred_at', to_char(clock_timestamp() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
            'correlation_id', NEW.correlation_id,
            'transfer_id', NEW.transfer_id,
            'transaction_reference', NEW.transaction_reference,
            'sequence', NEW.version,
            'data', v_data));
  RETURN NULL;
END $$;

CREATE TRIGGER trg_transfer_after_insert AFTER INSERT ON transfer
  FOR EACH ROW EXECUTE FUNCTION transfer_after_change();
CREATE TRIGGER trg_transfer_after_status AFTER UPDATE ON transfer
  FOR EACH ROW WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION transfer_after_change();

-- ---------------------------------------------------------------------------
-- Role checks for human decisions (segregation of duties)
-- ---------------------------------------------------------------------------
CREATE FUNCTION assert_role(p_user uuid, p_role text) RETURNS void LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_role text; v_active boolean;
BEGIN
  SELECT role, active INTO v_role, v_active FROM app_user WHERE user_id = p_user;
  IF v_role IS DISTINCT FROM p_role OR v_active IS NOT TRUE THEN
    RAISE EXCEPTION 'ROLE_NOT_PERMITTED: user % must be an active %', p_user, p_role;
  END IF;
END $$;

CREATE FUNCTION reversal_request_guard() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM assert_role(NEW.requested_by, 'ops_analyst');
  END IF;
  IF NEW.decided_by IS NOT NULL THEN
    IF NEW.decided_by = NEW.requested_by THEN
      RAISE EXCEPTION 'SOD_VIOLATION: the requester cannot approve their own reversal';
    END IF;
    PERFORM assert_role(NEW.decided_by, 'finance_controller');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_reversal_guard BEFORE INSERT OR UPDATE ON reversal_request
  FOR EACH ROW EXECUTE FUNCTION reversal_request_guard();

CREATE FUNCTION case_decision_guard() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  PERFORM assert_role(NEW.decided_by, 'compliance_officer');
  RETURN NEW;
END $$;
CREATE TRIGGER trg_case_decision_guard BEFORE INSERT ON case_decision
  FOR EACH ROW EXECUTE FUNCTION case_decision_guard();

CREATE FUNCTION case_decision_apply() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  UPDATE compliance_case
     SET state = CASE NEW.decision WHEN 'RELEASE' THEN 'RELEASED' ELSE 'REJECTED' END
   WHERE case_id = NEW.case_id;
  RETURN NULL;
END $$;
CREATE TRIGGER trg_case_decision_apply AFTER INSERT ON case_decision
  FOR EACH ROW EXECUTE FUNCTION case_decision_apply();

-- ---------------------------------------------------------------------------
-- Audit log: hash chain
-- ---------------------------------------------------------------------------
CREATE FUNCTION audit_row_hash(p_prev bytea, p_at timestamptz, p_actor text, p_role text, p_action text,
                               p_otype text, p_oid text, p_outcome text, p_corr uuid, p_details jsonb)
RETURNS bytea LANGUAGE sql IMMUTABLE AS $$
  SELECT sha256(convert_to(
    coalesce(encode(p_prev, 'hex'), '') || '|' ||
    to_char(p_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US') || '|' ||
    p_actor || '|' || coalesce(p_role, '') || '|' || p_action || '|' || coalesce(p_otype, '') || '|' ||
    coalesce(p_oid, '') || '|' || p_outcome || '|' || coalesce(p_corr::text, '') || '|' ||
    coalesce(p_details::text, ''), 'UTF8'))
$$;

CREATE FUNCTION audit_before_insert() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_prev bytea;
BEGIN
  PERFORM pg_advisory_xact_lock(727001);
  SELECT row_hash INTO v_prev FROM audit_log ORDER BY audit_id DESC LIMIT 1;
  NEW.prev_hash := v_prev;
  NEW.row_hash  := audit_row_hash(v_prev, NEW.at, NEW.actor, NEW.actor_role, NEW.action,
                                  NEW.object_type, NEW.object_id, NEW.outcome, NEW.correlation_id, NEW.details);
  RETURN NEW;
END $$;
CREATE TRIGGER trg_audit_chain BEFORE INSERT ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_before_insert();

CREATE FUNCTION audit(p_actor text, p_role text, p_action text, p_otype text, p_oid text,
                      p_outcome text, p_corr uuid DEFAULT NULL, p_details jsonb DEFAULT NULL)
RETURNS bigint LANGUAGE sql SECURITY DEFINER SET search_path = fw, public AS $$
  INSERT INTO audit_log (actor, actor_role, action, object_type, object_id, outcome, correlation_id, details)
  VALUES (p_actor, p_role, p_action, p_otype, p_oid, p_outcome, p_corr, p_details)
  RETURNING audit_id
$$;

CREATE FUNCTION verify_audit_chain(OUT chain_ok boolean, OUT first_bad_id bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE r record; v_prev bytea := NULL;
BEGIN
  chain_ok := true; first_bad_id := NULL;
  FOR r IN SELECT * FROM audit_log ORDER BY audit_id LOOP
    IF r.prev_hash IS DISTINCT FROM v_prev
       OR r.row_hash <> audit_row_hash(v_prev, r.at, r.actor, r.actor_role, r.action, r.object_type,
                                       r.object_id, r.outcome, r.correlation_id, r.details) THEN
      chain_ok := false; first_bad_id := r.audit_id; RETURN;
    END IF;
    v_prev := r.row_hash;
  END LOOP;
END $$;

-- ---------------------------------------------------------------------------
-- Ledger posting rules (the only place where journal lines are defined)
-- ---------------------------------------------------------------------------
CREATE FUNCTION ledger_post(p_transfer_id uuid, p_type journal_type) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE
  t           transfer%ROWTYPE;
  v_wallet    uuid;
  v_transit   uuid;
  v_clearing  uuid;
  v_journal   uuid := gen_random_uuid();
  v_post      uuid;
  v_desc      text;
BEGIN
  SELECT * INTO t FROM transfer WHERE transfer_id = p_transfer_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND: transfer %', p_transfer_id; END IF;

  SELECT ledger_account_id INTO v_wallet FROM wallet WHERE wallet_id = t.source_wallet_id;
  SELECT account_id INTO v_transit  FROM ledger_account WHERE code = '2200';
  SELECT account_id INTO v_clearing FROM ledger_account WHERE code = '1100';
  SELECT journal_id INTO v_post FROM journal_entry
   WHERE transfer_id = p_transfer_id AND journal_type = 'TRANSFER_POST';

  IF p_type = 'TRANSFER_POST' THEN
    IF t.status <> 'AUTHORISED' THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_POST needs AUTHORISED, found %', t.status; END IF;
    v_desc := 'Wallet debit, funds moved to payments in transit';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_transit, 'CREDIT', t.amount_minor),
      (v_journal, 2, v_wallet,  'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_SETTLE' THEN
    IF t.status NOT IN ('POSTED','PENDING') THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_SETTLE needs POSTED or PENDING, found %', t.status; END IF;
    v_desc := 'Rail confirmed, in-transit cleared against settlement float';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_clearing, 'CREDIT', t.amount_minor),
      (v_journal, 2, v_transit,  'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_REVERSE' THEN
    IF t.status NOT IN ('POSTED','PENDING') THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_REVERSE needs POSTED or PENDING, found %', t.status; END IF;
    v_desc := 'Compensation before settlement, wallet credited back from in-transit';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, reverses_journal_id, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, v_post, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_wallet,  'CREDIT', t.amount_minor),
      (v_journal, 2, v_transit, 'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_RETURN' THEN
    IF t.status <> 'SETTLED' THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_RETURN needs SETTLED, found %', t.status; END IF;
    v_desc := 'Funds returned by the rail after settlement, wallet credited, float restored';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, reverses_journal_id, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, v_post, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_wallet,   'CREDIT', t.amount_minor),
      (v_journal, 2, v_clearing, 'DEBIT',  t.amount_minor);
  ELSE
    RAISE EXCEPTION 'UNSUPPORTED_JOURNAL_TYPE: %', p_type;
  END IF;
  RETURN v_journal;
END $$;

CREATE FUNCTION fund_wallet(p_wallet_id uuid, p_amount_minor bigint, p_reference text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_journal uuid := gen_random_uuid(); v_wallet uuid; v_clearing uuid;
BEGIN
  SELECT ledger_account_id INTO v_wallet FROM wallet WHERE wallet_id = p_wallet_id;
  SELECT account_id INTO v_clearing FROM ledger_account WHERE code = '1100';
  INSERT INTO journal_entry (journal_id, journal_type, funding_reference, description)
    VALUES (v_journal, 'FUNDING', p_reference, 'Wallet funding (synthetic cash-in)');
  INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
    (v_journal, 1, v_wallet,   'CREDIT', p_amount_minor),
    (v_journal, 2, v_clearing, 'DEBIT',  p_amount_minor);
  RETURN v_journal;
END $$;
