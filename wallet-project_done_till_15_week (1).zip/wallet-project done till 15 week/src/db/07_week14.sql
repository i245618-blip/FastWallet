-- Week 14 additions (architecture review gate). Apply after 06_week13.sql and before the seed data.
--   1. Sharded balances for the two system accounts every transfer touches (ADR-008)
--   2. Late rail returns after reconciliation (ADR-010)
--   3. Write-off posting and stable re-runs of reconciliation (ADR-010)
--   4. Rate limiting store (ADR-009)
--   5. Dead-letter replay and discard
--   6. Exception-triage assistant: read-only input view, suggestion and review records, fw_ai role (ADR-007)
--   7. Operations health view with the new controls
SET search_path = fw, public;

-- ===========================================================================
-- 1. Sharded balances for high-volume system accounts
-- ===========================================================================
-- Every transfer posts to 2200 (in transit) and every settlement to 1100 (float). With one balance row per
-- account, every transfer in the system queued on those two rows (Week 13 load test, 20 concurrent
-- requests: p95 1.8 s, almost all of it row-lock waits inside ledger_post). Customer wallets keep one row
-- each, because their overdraft check must see the whole balance. The two system accounts spread their
-- running balance over 16 rows and are checked by the control view instead of row by row.
ALTER TABLE ledger_account ADD COLUMN balance_shards smallint NOT NULL DEFAULT 1 CHECK (balance_shards BETWEEN 1 AND 64);
UPDATE ledger_account SET balance_shards = 16 WHERE code IN ('1100', '2200');

ALTER TABLE account_balance RENAME TO account_balance_base;

CREATE TABLE account_balance_shard (
  account_id    uuid NOT NULL REFERENCES ledger_account(account_id),
  shard         smallint NOT NULL,
  balance_minor bigint NOT NULL DEFAULT 0,
  last_entry_id bigint,
  updated_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (account_id, shard)
);

-- Readers keep using account_balance; it now adds the base row and the shards together.
CREATE VIEW account_balance AS
SELECT account_id, sum(balance_minor)::bigint AS balance_minor, max(last_entry_id) AS last_entry_id,
       max(updated_at) AS updated_at
  FROM (SELECT account_id, balance_minor, last_entry_id, updated_at FROM account_balance_base
        UNION ALL
        SELECT account_id, balance_minor, last_entry_id, updated_at FROM account_balance_shard) x
 GROUP BY account_id;

CREATE OR REPLACE FUNCTION apply_entry_to_balance() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_side entry_direction; v_allow boolean; v_code text; v_shards smallint; v_delta bigint; v_new bigint;
BEGIN
  SELECT normal_side, allow_negative, code, balance_shards INTO v_side, v_allow, v_code, v_shards
    FROM ledger_account WHERE account_id = NEW.account_id;
  v_delta := CASE WHEN NEW.direction = v_side THEN NEW.amount_minor ELSE -NEW.amount_minor END;

  IF v_shards > 1 THEN
    -- one shard per entry, chosen by entry id, so concurrent postings rarely meet on the same row
    INSERT INTO account_balance_shard (account_id, shard, balance_minor, last_entry_id)
    VALUES (NEW.account_id, (NEW.entry_id % v_shards)::smallint, v_delta, NEW.entry_id)
    ON CONFLICT (account_id, shard) DO UPDATE
      SET balance_minor = account_balance_shard.balance_minor + EXCLUDED.balance_minor,
          last_entry_id = EXCLUDED.last_entry_id, updated_at = now();
    RETURN NULL;
  END IF;

  INSERT INTO account_balance_base (account_id, balance_minor, last_entry_id)
  VALUES (NEW.account_id, v_delta, NEW.entry_id)
  ON CONFLICT (account_id) DO UPDATE
    SET balance_minor = account_balance_base.balance_minor + EXCLUDED.balance_minor,
        last_entry_id = EXCLUDED.last_entry_id, updated_at = now()
  RETURNING balance_minor INTO v_new;

  IF v_new < 0 AND NOT v_allow THEN
    RAISE EXCEPTION 'INSUFFICIENT_FUNDS: account % would go to % minor units', v_code, v_new;
  END IF;
  RETURN NULL;
END $$;

-- same definition as Week 12, re-created so it reads the combined balance
CREATE OR REPLACE VIEW v_balance_projection_check AS
SELECT a.code,
       coalesce(b.balance_minor, 0) AS projected_minor,
       coalesce(sum(CASE WHEN e.direction = a.normal_side THEN e.amount_minor ELSE -e.amount_minor END), 0) AS recomputed_minor
  FROM ledger_account a
  LEFT JOIN account_balance b USING (account_id)
  LEFT JOIN ledger_entry e USING (account_id)
 GROUP BY a.code, a.normal_side, b.balance_minor
HAVING coalesce(b.balance_minor, 0) <>
       coalesce(sum(CASE WHEN e.direction = a.normal_side THEN e.amount_minor ELSE -e.amount_minor END), 0);

-- ===========================================================================
-- 2. Late rail return after a transfer was already reconciled
-- ===========================================================================
-- Rule: the rail's signed RETURNED answer is the evidence. The customer gets the money back at once
-- (TRANSFER_RETURN journal, status REVERSED), and finance is told through the exception queue because
-- the day it belonged to was already closed. The next reconciliation matches REVERSED against RETURNED.
INSERT INTO allowed_transition (from_status, to_status) VALUES ('RECONCILED', 'REVERSED');

CREATE OR REPLACE FUNCTION transfer_before_update() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
BEGIN
  IF (NEW.transfer_id, NEW.transaction_reference, NEW.client_id, NEW.source_wallet_id,
      NEW.beneficiary_scheme, NEW.beneficiary_identifier, NEW.amount_minor, NEW.currency,
      NEW.correlation_id, NEW.created_at)
     IS DISTINCT FROM
     (OLD.transfer_id, OLD.transaction_reference, OLD.client_id, OLD.source_wallet_id,
      OLD.beneficiary_scheme, OLD.beneficiary_identifier, OLD.amount_minor, OLD.currency,
      OLD.correlation_id, OLD.created_at) THEN
    RAISE EXCEPTION 'IMMUTABLE_FIELD: reference, amount, beneficiary, wallet and correlation id cannot change';
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF NOT EXISTS (SELECT 1 FROM allowed_transition
                   WHERE from_status = OLD.status AND to_status = NEW.status) THEN
      RAISE EXCEPTION 'INVALID_STATE_TRANSITION: % -> % is not allowed', OLD.status, NEW.status;
    END IF;
    IF NEW.status IN ('POSTED') AND NOT EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_POST') THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: POSTED requires a TRANSFER_POST journal';
    END IF;
    IF NEW.status = 'SETTLED' AND NOT EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_SETTLE') THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: SETTLED requires a TRANSFER_SETTLE journal';
    END IF;
    IF NEW.status = 'REVERSED' THEN
      IF OLD.status IN ('SETTLED', 'RECONCILED') AND NOT EXISTS
         (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_RETURN') THEN
        RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: reversing a settled transfer requires a TRANSFER_RETURN journal';
      ELSIF OLD.status IN ('POSTED','PENDING') AND NOT EXISTS
         (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id AND journal_type = 'TRANSFER_REVERSE') THEN
        RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: reversing an unsettled transfer requires a TRANSFER_REVERSE journal';
      END IF;
    END IF;
    IF NEW.status = 'FAILED' AND EXISTS
       (SELECT 1 FROM journal_entry WHERE transfer_id = NEW.transfer_id) THEN
      RAISE EXCEPTION 'STATE_LEDGER_MISMATCH: FAILED means nothing was posted';
    END IF;
    NEW.version := OLD.version + 1;
  END IF;
  NEW.updated_at := clock_timestamp();
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION ledger_post(p_transfer_id uuid, p_type journal_type) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE
  t           transfer%ROWTYPE;
  v_wallet    uuid;
  v_transit   uuid;
  v_clearing  uuid;
  v_journal   uuid := gen_random_uuid();
  v_post      uuid;
  v_desc      text;
BEGIN
  SELECT * INTO t FROM transfer WHERE transfer_id = p_transfer_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND: transfer %', p_transfer_id; END IF;

  SELECT ledger_account_id INTO v_wallet FROM wallet WHERE wallet_id = t.source_wallet_id;
  SELECT account_id INTO v_transit  FROM ledger_account WHERE code = '2200';
  SELECT account_id INTO v_clearing FROM ledger_account WHERE code = '1100';
  SELECT journal_id INTO v_post FROM journal_entry
   WHERE transfer_id = p_transfer_id AND journal_type = 'TRANSFER_POST';

  IF p_type = 'TRANSFER_POST' THEN
    IF t.status <> 'AUTHORISED' THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_POST needs AUTHORISED, found %', t.status; END IF;
    v_desc := 'Wallet debit, funds moved to payments in transit';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_transit, 'CREDIT', t.amount_minor),
      (v_journal, 2, v_wallet,  'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_SETTLE' THEN
    IF t.status NOT IN ('POSTED','PENDING') THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_SETTLE needs POSTED or PENDING, found %', t.status; END IF;
    v_desc := 'Rail confirmed, in-transit cleared against settlement float';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_clearing, 'CREDIT', t.amount_minor),
      (v_journal, 2, v_transit,  'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_REVERSE' THEN
    IF t.status NOT IN ('POSTED','PENDING') THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_REVERSE needs POSTED or PENDING, found %', t.status; END IF;
    v_desc := 'Compensation before settlement, wallet credited back from in-transit';
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, reverses_journal_id, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, v_post, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_wallet,  'CREDIT', t.amount_minor),
      (v_journal, 2, v_transit, 'DEBIT',  t.amount_minor);

  ELSIF p_type = 'TRANSFER_RETURN' THEN
    IF t.status NOT IN ('SETTLED', 'RECONCILED') THEN
      RAISE EXCEPTION 'INVALID_STATE_FOR_POSTING: TRANSFER_RETURN needs SETTLED or RECONCILED, found %', t.status; END IF;
    v_desc := CASE WHEN t.status = 'RECONCILED'
                   THEN 'Late return after reconciliation, wallet credited, float restored'
                   ELSE 'Funds returned by the rail after settlement, wallet credited, float restored' END;
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, reverses_journal_id, correlation_id)
      VALUES (v_journal, t.transfer_id, p_type, v_desc, v_post, t.correlation_id);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_wallet,   'CREDIT', t.amount_minor),
      (v_journal, 2, v_clearing, 'DEBIT',  t.amount_minor);
  ELSE
    RAISE EXCEPTION 'UNSUPPORTED_JOURNAL_TYPE: %', p_type;
  END IF;
  RETURN v_journal;
END $$;

ALTER TABLE ops_exception DROP CONSTRAINT ops_exception_kind_check;
ALTER TABLE ops_exception ADD CONSTRAINT ops_exception_kind_check CHECK (kind IN
  ('RECOVERY_EXHAUSTED', 'RAIL_OUTCOME_CONFLICT', 'POSTING_FAILED',
   'LATE_RETURN_AFTER_RECON'));            -- informational: a closed day changed, finance acknowledges

-- ===========================================================================
-- 3. Write-off posting and stable reconciliation re-runs
-- ===========================================================================
-- Week 12 recorded an approved write-off but posted nothing. Now the approval posts a RECON_ADJUSTMENT
-- journal for the loss (rail paid more than our ledger shows): debit 5100 write-off expense, credit 1100
-- float, so the float in our books matches the money really left at the sponsor bank. Only losses are
-- written off; a gain or a break with no transfer must be corrected another way.
CREATE OR REPLACE FUNCTION resolve_break(p_break uuid, p_code text, p_comment text, p_user uuid,
                                         p_approver uuid DEFAULT NULL) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_owner text; v_role text; b recon_break%ROWTYPE; v_loss bigint; v_journal uuid := gen_random_uuid();
        v_float uuid; v_expense uuid; v_corr uuid;
BEGIN
  SELECT * INTO b FROM recon_break WHERE break_id = p_break AND state <> 'RESOLVED' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND: no open break %', p_break; END IF;
  v_owner := b.owner_role;
  SELECT role INTO v_role FROM app_user WHERE user_id = p_user AND active;
  IF v_role IS NULL OR (v_role <> v_owner AND v_role <> 'finance_controller') THEN
    RAISE EXCEPTION 'ROLE_NOT_PERMITTED: break is owned by %', v_owner;
  END IF;
  IF p_code = 'WRITTEN_OFF_APPROVED' THEN
    IF p_approver IS NULL OR p_approver = p_user THEN
      RAISE EXCEPTION 'SOD_VIOLATION: a write-off needs a second person to approve';
    END IF;
    PERFORM assert_role(p_approver, 'finance_controller');
    v_loss := coalesce(b.external_amount_minor, 0) - coalesce(b.internal_amount_minor, 0);
    IF b.transfer_id IS NULL OR v_loss <= 0 THEN
      RAISE EXCEPTION 'WRITE_OFF_NOT_APPLICABLE: only a loss on a known transfer can be written off (loss % minor units)', v_loss;
    END IF;
    SELECT account_id INTO v_float   FROM ledger_account WHERE code = '1100';
    SELECT account_id INTO v_expense FROM ledger_account WHERE code = '5100';
    SELECT correlation_id INTO v_corr FROM transfer WHERE transfer_id = b.transfer_id;
    INSERT INTO journal_entry (journal_id, transfer_id, journal_type, description, correlation_id)
      VALUES (v_journal, b.transfer_id, 'RECON_ADJUSTMENT',
              'Approved write-off of ' || b.break_type::text || ' break ' || b.break_id::text, v_corr);
    INSERT INTO ledger_entry (journal_id, leg_no, account_id, direction, amount_minor) VALUES
      (v_journal, 1, v_expense, 'DEBIT',  v_loss),
      (v_journal, 2, v_float,   'CREDIT', v_loss);
  END IF;
  UPDATE recon_break
     SET state = 'RESOLVED', resolution_code = p_code, resolution_comment = p_comment,
         resolved_by = p_user, approved_by = p_approver, resolved_at = now()
   WHERE break_id = p_break;
END $$;

-- The journal-balance check is a deferred constraint trigger: it fires at COMMIT as the session role, not
-- inside ledger_post()/resolve_break(). fw_txn could read ledger_entry, fw_recon cannot, so the first
-- write-off posted by the reconciliation role failed at commit. The check now runs with its owner's rights
-- instead of granting fw_recon read access to the ledger.
ALTER FUNCTION assert_journal_balanced() SECURITY DEFINER;

-- A break that was resolved is not raised again for the same evidence (same key and amounts), so
-- re-running a day's reconciliation after a duplicate was written off does not reopen it.
CREATE OR REPLACE FUNCTION raise_break(p_run uuid, p_type break_type, p_transfer uuid, p_rail_req text,
                                       p_line bigint, p_internal bigint, p_external bigint, p_detail text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_owner text; v_sla int; v_key text;
BEGIN
  SELECT default_owner_role, sla_hours INTO v_owner, v_sla FROM break_policy WHERE break_type = p_type;
  v_key := p_type::text || ':' ||
           coalesce(p_rail_req, (SELECT transaction_reference FROM transfer WHERE transfer_id = p_transfer));
  IF p_type IN ('DUPLICATE', 'AMOUNT_MISMATCH', 'UNMATCHED_EXTERNAL') AND EXISTS (
       SELECT 1 FROM recon_break WHERE break_key = v_key AND state = 'RESOLVED'
          AND internal_amount_minor IS NOT DISTINCT FROM p_internal
          AND external_amount_minor IS NOT DISTINCT FROM p_external) THEN
    RETURN;
  END IF;
  INSERT INTO recon_break (run_id, break_key, break_type, transfer_id, rail_request_id, statement_line_id,
                           internal_amount_minor, external_amount_minor, detail, owner_role, due_at)
  VALUES (p_run, v_key, p_type, p_transfer, p_rail_req, p_line, p_internal, p_external, p_detail,
          v_owner, now() + make_interval(hours => v_sla))
  ON CONFLICT (break_key) WHERE state <> 'RESOLVED' DO NOTHING;
END $$;

-- ===========================================================================
-- 4. Rate limiting (fixed window per subject, shared by every API process)
-- ===========================================================================
CREATE TABLE rate_limit_policy (
  scope          text PRIMARY KEY,
  max_requests   integer NOT NULL CHECK (max_requests > 0),
  window_seconds integer NOT NULL CHECK (window_seconds > 0),
  description    text NOT NULL
);
INSERT INTO rate_limit_policy VALUES
 ('transfer_create', 30, 60, 'POST /v1/transfers per customer'),
 ('staff_write',     120, 60, 'State-changing staff calls per staff user'),
 ('ai_triage',       60, 60, 'Triage requests per staff user');

CREATE TABLE rate_limit_counter (
  scope        text NOT NULL REFERENCES rate_limit_policy(scope),
  subject      text NOT NULL,
  window_start timestamptz NOT NULL,
  hits         integer NOT NULL,
  PRIMARY KEY (scope, subject, window_start)
);

CREATE FUNCTION rate_limit_take(p_scope text, p_subject text,
                                OUT allowed boolean, OUT hits integer, OUT max_requests integer, OUT retry_after integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_win integer; v_start timestamptz;
BEGIN
  SELECT p.max_requests, p.window_seconds INTO max_requests, v_win FROM rate_limit_policy p WHERE p.scope = p_scope;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND: rate limit scope %', p_scope; END IF;
  v_start := to_timestamp(floor(extract(epoch FROM clock_timestamp()) / v_win) * v_win);
  INSERT INTO rate_limit_counter AS c (scope, subject, window_start, hits) VALUES (p_scope, p_subject, v_start, 1)
  ON CONFLICT (scope, subject, window_start) DO UPDATE SET hits = c.hits + 1
  RETURNING c.hits INTO hits;
  allowed := hits <= max_requests;
  retry_after := greatest(1, ceil(extract(epoch FROM v_start + make_interval(secs => v_win) - clock_timestamp()))::int);
END $$;

CREATE FUNCTION rate_limit_purge() RETURNS integer LANGUAGE sql SECURITY DEFINER SET search_path = fw, public AS $$
  WITH d AS (DELETE FROM rate_limit_counter WHERE window_start < now() - interval '1 day' RETURNING 1)
  SELECT count(*)::int FROM d
$$;

-- ===========================================================================
-- 5. Dead-letter replay and discard (human decision, audited by the API)
-- ===========================================================================
ALTER TABLE dead_letter_event
  ADD COLUMN last_attempt_at  timestamptz,
  ADD COLUMN resolved_by      text,
  ADD COLUMN resolved_at      timestamptz,
  ADD COLUMN resolution_note  text,
  ADD CONSTRAINT dlq_resolution_recorded CHECK (state = 'OPEN' OR (resolved_by IS NOT NULL AND resolved_at IS NOT NULL));

-- ===========================================================================
-- 6. Exception-triage assistant (bounded AI extension, ADR-007)
-- ===========================================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'fw_ai') THEN CREATE ROLE fw_ai NOLOGIN; END IF;
END $$;

CREATE TABLE ai_triage_config (
  id                   boolean PRIMARY KEY DEFAULT true CHECK (id),
  enabled              boolean NOT NULL DEFAULT true,          -- kill switch, finance controller only
  model_version        text NOT NULL,
  abstain_below        numeric(4,3) NOT NULL CHECK (abstain_below BETWEEN 0.5 AND 0.99),
  material_amount_minor bigint NOT NULL,                       -- same threshold as screening rule R10
  updated_by           text NOT NULL DEFAULT 'install',
  updated_at           timestamptz NOT NULL DEFAULT now()
);
INSERT INTO ai_triage_config (model_version, abstain_below, material_amount_minor)
VALUES ('triage-rules-1.2', 0.700, 15000000);

-- The only data the assistant can read: one row per open exception or break. References, statuses,
-- amounts, counts and reason codes. No names, mobile numbers, national id tokens, beneficiary accounts
-- or customer references.
CREATE VIEW v_triage_item AS
WITH items AS (
  SELECT 'EXCEPTION'::text AS item_type, e.exception_id AS item_id, e.kind, e.owner_role, e.state,
         e.opened_at, e.transfer_id, NULL::bigint AS internal_amount_minor, NULL::bigint AS external_amount_minor,
         e.detail
    FROM ops_exception e WHERE e.state = 'OPEN'
  UNION ALL
  SELECT 'BREAK', b.break_id, b.break_type::text, b.owner_role, b.state, b.opened_at, b.transfer_id,
         b.internal_amount_minor, b.external_amount_minor, b.detail
    FROM recon_break b WHERE b.state <> 'RESOLVED')
SELECT i.item_type, i.item_id, i.kind, i.owner_role, i.state, i.opened_at,
       (extract(epoch FROM now() - i.opened_at) / 60)::int                       AS age_minutes,
       t.transaction_reference, t.status::text                                    AS transfer_status,
       t.status_reason,
       (extract(epoch FROM now() - t.updated_at) / 60)::int                       AS transfer_age_minutes,
       t.amount_minor, i.internal_amount_minor, i.external_amount_minor,
       (SELECT count(*) FROM rail_message_log m WHERE m.transfer_id = t.transfer_id
           AND m.operation = 'ENQUIRY')::int                                      AS enquiry_attempts,
       (SELECT m.outcome FROM rail_message_log m WHERE m.transfer_id = t.transfer_id
           AND m.operation IN ('ACK','ENQUIRY_RESULT') ORDER BY m.msg_id DESC LIMIT 1) AS last_rail_outcome,
       (SELECT count(*) FROM rail_statement_line l WHERE l.rail_request_id = coalesce(t.transaction_reference, '')
           AND l.rail_status = 'EXECUTED')::int                                   AS statement_executed_lines,
       (SELECT bool_or(l.rail_status = 'RETURNED') FROM rail_statement_line l
         WHERE l.rail_request_id = coalesce(t.transaction_reference, ''))         AS statement_returned,
       coalesce((SELECT array_agg(j.journal_type::text ORDER BY j.posted_at) FROM journal_entry j
                  WHERE j.transfer_id = t.transfer_id), '{}')                      AS journals,
       EXISTS (SELECT 1 FROM compliance_case k WHERE k.transfer_id = t.transfer_id) AS has_compliance_case,
       coalesce((SELECT d.reason_codes FROM screening_decision d WHERE d.transfer_id = t.transfer_id
                  ORDER BY d.created_at DESC LIMIT 1), '{}')                       AS screening_reasons,
       left(i.detail, 160)                                                         AS detail
  FROM items i LEFT JOIN transfer t ON t.transfer_id = i.transfer_id;

CREATE TABLE ai_triage_suggestion (
  suggestion_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_type          text NOT NULL CHECK (item_type IN ('EXCEPTION','BREAK')),
  item_id            uuid NOT NULL,
  model_version      text NOT NULL,
  input_hash         char(64) NOT NULL,
  inputs             jsonb NOT NULL,
  category           text NOT NULL,
  recommended_action text NOT NULL CHECK (recommended_action IN
                       ('RUN_STATUS_ENQUIRY','WAIT_FOR_AUTOMATED_RECOVERY','RESOLVE_AS_MATCHED_LATE',
                        'REQUEST_RAIL_CORRECTION','ESCALATE_FINANCE_REVIEW','ESCALATE_COMPLIANCE_REVIEW',
                        'HUMAN_ANALYSIS_REQUIRED')),
  confidence         numeric(4,3) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  abstained          boolean NOT NULL,
  abstain_reason     text,
  summary            text NOT NULL,
  evidence           jsonb NOT NULL,
  latency_ms         numeric(8,2) NOT NULL,
  requested_by       text NOT NULL,
  correlation_id     uuid,
  created_at         timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK (abstained = (recommended_action = 'HUMAN_ANALYSIS_REQUIRED')),
  CHECK (NOT abstained OR abstain_reason IS NOT NULL)
);
CREATE INDEX ix_ai_suggestion_item ON ai_triage_suggestion (item_type, item_id, created_at);

CREATE TABLE ai_triage_review (
  suggestion_id uuid PRIMARY KEY REFERENCES ai_triage_suggestion(suggestion_id),
  decision      text NOT NULL CHECK (decision IN ('ACCEPT','REJECT')),
  comment       text NOT NULL CHECK (length(comment) >= 10),
  reviewed_by   uuid NOT NULL REFERENCES app_user(user_id),
  reviewed_at   timestamptz NOT NULL DEFAULT clock_timestamp()
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['ai_triage_suggestion','ai_triage_review'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%s_immutable BEFORE UPDATE OR DELETE ON %I
                    FOR EACH ROW EXECUTE FUNCTION forbid_mutation()', t, t);
    EXECUTE format('CREATE TRIGGER trg_%s_no_truncate BEFORE TRUNCATE ON %I
                    FOR EACH STATEMENT EXECUTE FUNCTION forbid_mutation()', t, t);
  END LOOP;
END $$;

CREATE VIEW v_ai_triage_quality AS
SELECT s.model_version,
       count(*)                                                     AS suggestions,
       count(*) FILTER (WHERE s.abstained)                          AS abstained,
       count(r.*)                                                   AS reviewed,
       count(*) FILTER (WHERE r.decision = 'ACCEPT')                AS accepted,
       count(*) FILTER (WHERE r.decision = 'REJECT')                AS rejected,
       count(*) FILTER (WHERE r.suggestion_id IS NULL AND NOT s.abstained) AS awaiting_review,
       coalesce(percentile_cont(0.95) WITHIN GROUP (ORDER BY s.latency_ms), 0)::numeric(8,2) AS latency_p95_ms
  FROM ai_triage_suggestion s LEFT JOIN ai_triage_review r USING (suggestion_id)
 GROUP BY s.model_version;

-- ===========================================================================
-- 7. Operations health, with the Week 14 controls added at the end
-- ===========================================================================
CREATE OR REPLACE VIEW v_ops_health AS
WITH bal AS (
  SELECT a.code, coalesce(b.balance_minor, 0) AS bal
    FROM ledger_account a LEFT JOIN account_balance b USING (account_id)),
settle AS (
  SELECT extract(epoch FROM (s.changed_at - i.changed_at)) AS secs
    FROM transfer_state_history s
    JOIN transfer_state_history i ON i.transfer_id = s.transfer_id AND i.sequence = 1
   WHERE s.to_status = 'SETTLED' AND s.changed_at > now() - interval '24 hours')
SELECT
  (SELECT coalesce(jsonb_object_agg(status, n), '{}'::jsonb)
     FROM (SELECT status::text, count(*) AS n FROM transfer GROUP BY status) x)          AS transfers_by_status,
  (SELECT count(*) FROM transfer WHERE status = 'PENDING')                               AS pending_count,
  (SELECT coalesce(max(extract(epoch FROM now() - updated_at)), 0)::int
     FROM transfer WHERE status = 'PENDING')                                             AS pending_oldest_seconds,
  (SELECT count(*) FROM transfer WHERE status = 'POSTED'
      AND updated_at < now() - interval '60 seconds')                                    AS posted_stuck_count,
  (SELECT count(*) FROM outbox_event WHERE published_at IS NULL)                         AS outbox_unpublished,
  (SELECT coalesce(max(extract(epoch FROM now() - created_at)), 0)::int
     FROM outbox_event WHERE published_at IS NULL)                                       AS outbox_oldest_seconds,
  (SELECT count(*) FROM dead_letter_event WHERE state = 'OPEN')                          AS dlq_open,
  (SELECT count(*) FROM recon_break WHERE state <> 'RESOLVED')                           AS open_breaks,
  (SELECT count(*) FROM recon_break WHERE state <> 'RESOLVED' AND due_at < now())        AS overdue_breaks,
  (SELECT count(*) FROM compliance_case WHERE state = 'OPEN')                            AS open_cases,
  (SELECT count(*) FROM compliance_case WHERE state = 'OPEN' AND due_at < now())         AS overdue_cases,
  (SELECT count(*) FROM ops_exception WHERE state = 'OPEN')                              AS open_exceptions,
  (SELECT count(*) FROM audit_log WHERE outcome = 'DENIED')                              AS audit_denials,
  (SELECT sum(debit_total_minor) = sum(credit_total_minor) FROM v_trial_balance)         AS trial_balance_ok,
  (SELECT count(*) = 0 FROM v_balance_projection_check)                                  AS projection_ok,
  -- float = customer wallets + in transit - approved write-offs (write-offs reduce the float, not wallets)
  ((SELECT bal FROM bal WHERE code = '1100') + coalesce((SELECT bal FROM bal WHERE code = '5100'), 0) =
   (SELECT coalesce(sum(bal), 0) FROM bal WHERE code LIKE 'W-CUST-%') +
   (SELECT bal FROM bal WHERE code = '2200'))                                            AS float_invariant_ok,
  (SELECT count(*) FROM settle)                                                          AS settled_24h,
  (SELECT coalesce(percentile_cont(0.95) WITHIN GROUP (ORDER BY secs), 0)::numeric(10,3)
     FROM settle)                                                                        AS settle_p95_seconds_24h,
  -- Week 14
  ((SELECT bal FROM bal WHERE code = '1100') >= 0 AND (SELECT bal FROM bal WHERE code = '2200') >= 0) AS system_accounts_ok,
  (SELECT coalesce((SELECT bal FROM bal WHERE code = '5100'), 0))                        AS written_off_minor,
  (SELECT coalesce(sum(hits - max_requests), 0) FROM rate_limit_counter c JOIN rate_limit_policy p USING (scope)
    WHERE c.hits > p.max_requests AND c.window_start > now() - interval '1 hour')        AS rate_limited_last_hour,
  (SELECT count(*) FROM ai_triage_suggestion s WHERE NOT s.abstained
      AND NOT EXISTS (SELECT 1 FROM ai_triage_review r WHERE r.suggestion_id = s.suggestion_id)) AS ai_awaiting_review,
  (SELECT count(*) FROM ai_triage_review WHERE decision = 'REJECT')                      AS ai_rejected,
  (SELECT count(*) FROM ai_triage_review WHERE decision = 'ACCEPT')                      AS ai_accepted,
  (SELECT count(*) FROM ai_triage_suggestion WHERE abstained)                            AS ai_abstained;

-- ===========================================================================
-- Grants
-- ===========================================================================
REVOKE ALL ON account_balance_base, account_balance_shard, account_balance, rate_limit_policy, rate_limit_counter,
              ai_triage_config, v_triage_item, ai_triage_suggestion, ai_triage_review, v_ai_triage_quality FROM PUBLIC;
REVOKE ALL ON FUNCTION rate_limit_take(text, text), rate_limit_purge() FROM PUBLIC;

GRANT SELECT ON account_balance, account_balance_base, account_balance_shard TO fw_txn;
GRANT SELECT ON rate_limit_policy TO fw_txn;
GRANT EXECUTE ON FUNCTION rate_limit_take(text, text), rate_limit_purge() TO fw_txn;

-- notification consumer can now replay or discard its own dead letters
GRANT SELECT ON dead_letter_event TO fw_notify;
GRANT UPDATE (state, attempts, last_attempt_at, resolved_by, resolved_at, resolution_note) ON dead_letter_event TO fw_notify;
GRANT SELECT ON dead_letter_event TO fw_txn;

-- AI assistant: reads its view and its configuration, writes suggestions, nothing else.
GRANT USAGE ON SCHEMA fw TO fw_ai;
GRANT SELECT ON v_triage_item, ai_triage_config TO fw_ai;
GRANT INSERT ON ai_triage_suggestion TO fw_ai;
GRANT EXECUTE ON FUNCTION audit(text, text, text, text, text, text, uuid, jsonb) TO fw_ai;

-- humans review suggestions through the Transaction Service role; finance controls the kill switch
GRANT SELECT ON ai_triage_suggestion, ai_triage_config, v_ai_triage_quality TO fw_txn;
GRANT INSERT ON ai_triage_review TO fw_txn;
GRANT SELECT ON ai_triage_review TO fw_txn;
GRANT UPDATE (enabled, abstain_below, updated_by, updated_at) ON ai_triage_config TO fw_txn;
GRANT SELECT ON v_ai_triage_quality TO fw_report;

-- ===========================================================================
-- 8. Audit chain order under concurrency (defect found by the Week 15 restore drill)
-- ===========================================================================
-- audit_id is assigned when the row is built, before the trigger takes the chain lock. Two concurrent
-- writers could take the lock in the opposite order of their ids, so the chain was correct in lock order
-- but verify_audit_chain() walked it in id order and reported a break. The chain now has its own sequence,
-- drawn while the lock is held (the lock lasts until commit, so lock order is commit order).
CREATE SEQUENCE audit_chain_seq;
ALTER TABLE audit_log ADD COLUMN chain_seq bigint;
CREATE UNIQUE INDEX uq_audit_chain_seq ON audit_log (chain_seq);

CREATE OR REPLACE FUNCTION audit_before_insert() RETURNS trigger LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_prev bytea;
BEGIN
  PERFORM pg_advisory_xact_lock(727001);
  NEW.chain_seq := nextval('audit_chain_seq');
  SELECT row_hash INTO v_prev FROM audit_log ORDER BY chain_seq DESC NULLS LAST LIMIT 1;
  NEW.prev_hash := v_prev;
  NEW.row_hash  := audit_row_hash(v_prev, NEW.at, NEW.actor, NEW.actor_role, NEW.action,
                                  NEW.object_type, NEW.object_id, NEW.outcome, NEW.correlation_id, NEW.details);
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION verify_audit_chain(OUT chain_ok boolean, OUT first_bad_id bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE r record; v_prev bytea := NULL;
BEGIN
  chain_ok := true; first_bad_id := NULL;
  FOR r IN SELECT * FROM audit_log ORDER BY chain_seq LOOP
    IF r.prev_hash IS DISTINCT FROM v_prev
       OR r.row_hash <> audit_row_hash(v_prev, r.at, r.actor, r.actor_role, r.action, r.object_type,
                                       r.object_id, r.outcome, r.correlation_id, r.details) THEN
      chain_ok := false; first_bad_id := r.audit_id; RETURN;
    END IF;
    v_prev := r.row_hash;
  END LOOP;
END $$;
