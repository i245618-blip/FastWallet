-- Reference and configuration data. Needed by the application in every environment.
-- Limits are synthetic design values for the project, not published SBP figures.
SET search_path = fw, public;

INSERT INTO tier_policy VALUES
 (0, 'Tier 0 - basic, remotely opened', false,         0,         0,          0, 'Mobile OTP and CNIC pre-screen only'),
 (1, 'Tier 1 - biometric verified',     true,   2500000,   5000000,   20000000, 'Biometric verification (simulated)'),
 (2, 'Tier 2 - full KYC',               true,  20000000,  40000000,  200000000, 'Full due diligence, documents reviewed');
-- amounts are paisa: Tier 1 = Rs 25,000 per transfer, Rs 50,000 per day, Rs 200,000 per month;
--                    Tier 2 = Rs 200,000 per transfer, Rs 400,000 per day, Rs 2,000,000 per month.

INSERT INTO ledger_account (code, name, account_type, normal_side) VALUES
 ('1100', 'Settlement float held at sponsor bank',  'ASSET',     'DEBIT'),
 ('2200', 'Payments in transit (suspense)',         'LIABILITY', 'CREDIT'),
 ('4100', 'Transfer fee revenue (extension, unused)','REVENUE',  'CREDIT');
INSERT INTO ledger_account (code, name, account_type, normal_side, allow_negative) VALUES
 ('5100', 'Reconciliation write-off expense',       'EXPENSE',   'DEBIT', true);

INSERT INTO allowed_transition (from_status, to_status) VALUES
 ('INITIATED','HELD'), ('INITIATED','AUTHORISED'), ('INITIATED','FAILED'),
 ('HELD','AUTHORISED'), ('HELD','FAILED'),
 ('AUTHORISED','POSTED'), ('AUTHORISED','FAILED'),
 ('POSTED','SETTLED'), ('POSTED','PENDING'), ('POSTED','REVERSED'),
 ('PENDING','SETTLED'), ('PENDING','REVERSED'),
 ('SETTLED','RECONCILED'), ('SETTLED','REVERSED');

INSERT INTO break_policy VALUES
 ('UNMATCHED_INTERNAL', 'ops_analyst',        4, true,  'Internal record with no statement line. Usually fixed by a status enquiry.'),
 ('UNMATCHED_EXTERNAL', 'ops_analyst',        4, false, 'Statement line with no internal transfer. Treated as a possible control issue.'),
 ('DUPLICATE',          'finance_controller', 8, false, 'More than one executed line for one request. Needs a return request to the rail.'),
 ('MISSING',            'finance_controller', 4, false, 'Status not backed by journals or events. Internal integrity break.'),
 ('AMOUNT_MISMATCH',    'finance_controller', 8, false, 'Amounts differ between our ledger and the rail.'),
 ('STATUS_MISMATCH',    'ops_analyst',        4, true,  'Internal status disagrees with the rail outcome.');

INSERT INTO screening_rule (rule_id, name, description, outcome_on_hit, params) VALUES
 ('R01','TIER_CANNOT_SEND',     'Customer tier does not allow transfers to bank accounts',           'BLOCK', '{}'),
 ('R02','PER_TXN_LIMIT',        'Amount above the tier limit for one transfer',                      'BLOCK', '{}'),
 ('R03','DAILY_LIMIT',          'Today''s outbound total plus this transfer above the daily limit',  'BLOCK', '{}'),
 ('R04','MONTHLY_LIMIT',        'Month outbound total plus this transfer above the monthly limit',   'BLOCK', '{}'),
 ('R05','VELOCITY',             'Too many transfers in a short window',                              'HOLD',  '{"max_count":5,"window_minutes":10}'),
 ('R06','NEW_BENEFICIARY_HIGH', 'First transfer to this beneficiary and amount at or above threshold','HOLD', '{"threshold_minor":5000000}'),
 ('R07','WATCHLIST_NAME_MATCH', 'Beneficiary name resembles an entry on the synthetic watchlist',    'HOLD',  '{"min_similarity":0.8}'),
 ('R08','NEW_ACCOUNT_HIGH',     'Wallet younger than 24 hours and amount at or above threshold',     'HOLD',  '{"threshold_minor":2500000,"age_hours":24}'),
 ('R09','SECOND_FACTOR',        'Every outbound transfer needs a second factor before it is allowed','STEP_UP','{}'),
 ('R10','MATERIAL_AMOUNT',      'Amount at or above the materiality threshold needs human review',   'HOLD',  '{"threshold_minor":15000000}');
