-- Reconciliation logic and reporting views.
SET search_path = fw, public;

-- ---------------------------------------------------------------------------
-- Raise (or skip, if already open) one break. Owner and due time come from break_policy.
-- ---------------------------------------------------------------------------
CREATE FUNCTION raise_break(p_run uuid, p_type break_type, p_transfer uuid, p_rail_req text,
                            p_line bigint, p_internal bigint, p_external bigint, p_detail text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_owner text; v_sla int; v_key text;
BEGIN
  SELECT default_owner_role, sla_hours INTO v_owner, v_sla FROM break_policy WHERE break_type = p_type;
  v_key := p_type::text || ':' ||
           coalesce(p_rail_req, (SELECT transaction_reference FROM transfer WHERE transfer_id = p_transfer));
  INSERT INTO recon_break (run_id, break_key, break_type, transfer_id, rail_request_id, statement_line_id,
                           internal_amount_minor, external_amount_minor, detail, owner_role, due_at)
  VALUES (p_run, v_key, p_type, p_transfer, p_rail_req, p_line, p_internal, p_external, p_detail,
          v_owner, now() + make_interval(hours => v_sla))
  ON CONFLICT (break_key) WHERE state <> 'RESOLVED' DO NOTHING;
END $$;

-- ---------------------------------------------------------------------------
-- Daily reconciliation of internal transfers against the rail statement.
-- Match key: transfer.transaction_reference = rail_statement_line.rail_request_id
-- ---------------------------------------------------------------------------
CREATE FUNCTION run_reconciliation(p_statement_date date,
                                   p_run_by text DEFAULT 'recon-service',
                                   p_stuck_after interval DEFAULT interval '30 minutes')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE
  v_run     uuid := gen_random_uuid();
  v_matched int := 0;
  v_breaks  int;
  r         record;
  v_amount_bad boolean;
  v_status_bad boolean;
  v_dup boolean;
BEGIN
  PERFORM set_config('fw.actor', p_run_by, true);
  INSERT INTO recon_run (run_id, statement_date, run_by) VALUES (v_run, p_statement_date, p_run_by);

  -- 1. DUPLICATE: more than one EXECUTED line for the same request id
  PERFORM raise_break(v_run, 'DUPLICATE', t.transfer_id, l.rail_request_id, min(l.line_id),
                      t.amount_minor, sum(l.amount_minor)::bigint,
                      count(*)::text || ' EXECUTED lines for one request id')
    FROM rail_statement_line l
    LEFT JOIN transfer t ON t.transaction_reference = l.rail_request_id
   WHERE l.statement_date = p_statement_date AND l.rail_status = 'EXECUTED'
   GROUP BY l.rail_request_id, t.transfer_id, t.amount_minor
  HAVING count(*) > 1;

  -- 2. UNMATCHED_EXTERNAL: statement line without an internal transfer
  PERFORM raise_break(v_run, 'UNMATCHED_EXTERNAL', NULL, l.rail_request_id, min(l.line_id),
                      NULL, sum(l.amount_minor)::bigint, 'statement line has no internal transfer')
    FROM rail_statement_line l
   WHERE l.statement_date = p_statement_date
     AND NOT EXISTS (SELECT 1 FROM transfer t WHERE t.transaction_reference = l.rail_request_id)
   GROUP BY l.rail_request_id;

  -- 3. Internal transfers against the effective rail outcome
  FOR r IN
    WITH rail AS (
      SELECT rail_request_id,
             CASE WHEN bool_or(rail_status = 'RETURNED') THEN 'RETURNED'
                  WHEN bool_or(rail_status = 'EXECUTED') THEN 'EXECUTED'
                  ELSE 'REJECTED' END                                       AS eff_status,
             coalesce(max(amount_minor) FILTER (WHERE rail_status = 'EXECUTED'), max(amount_minor)) AS eff_amount,
             min(line_id)                                                   AS first_line
        FROM rail_statement_line
       WHERE statement_date <= p_statement_date
       GROUP BY rail_request_id)
    SELECT t.transfer_id, t.transaction_reference AS ref, t.status, t.amount_minor, t.updated_at,
           rl.eff_status, rl.eff_amount, rl.first_line
      FROM transfer t
      LEFT JOIN rail rl ON rl.rail_request_id = t.transaction_reference
     WHERE t.status IN ('SETTLED','POSTED','PENDING','REVERSED','FAILED')
  LOOP
    v_amount_bad := false; v_status_bad := false;
    v_dup := EXISTS (SELECT 1 FROM recon_break b WHERE b.transfer_id = r.transfer_id
                        AND b.break_type = 'DUPLICATE' AND b.state <> 'RESOLVED');

    IF r.eff_status IS NULL THEN
      IF r.status = 'SETTLED' THEN
        PERFORM raise_break(v_run, 'UNMATCHED_INTERNAL', r.transfer_id, NULL, NULL, r.amount_minor, NULL,
                            'SETTLED internally but the statement has no line for it');
      ELSIF r.status IN ('POSTED','PENDING') AND r.updated_at < clock_timestamp() - p_stuck_after THEN
        PERFORM raise_break(v_run, 'UNMATCHED_INTERNAL', r.transfer_id, NULL, NULL, r.amount_minor, NULL,
                            'STUCK_PENDING: no statement line and no resolution, run a status enquiry');
      END IF;
    ELSE
      IF r.eff_status IN ('EXECUTED','RETURNED') AND r.eff_amount <> r.amount_minor THEN
        v_amount_bad := true;
        PERFORM raise_break(v_run, 'AMOUNT_MISMATCH', r.transfer_id, NULL, r.first_line,
                            r.amount_minor, r.eff_amount, 'internal and rail amounts differ');
      END IF;
      IF NOT ((r.status = 'SETTLED'  AND r.eff_status = 'EXECUTED')
           OR (r.status = 'REVERSED' AND r.eff_status IN ('RETURNED','REJECTED'))) THEN
        v_status_bad := true;
        PERFORM raise_break(v_run, 'STATUS_MISMATCH', r.transfer_id, NULL, r.first_line,
                            r.amount_minor, r.eff_amount,
                            'internal=' || r.status || ', rail=' || r.eff_status);
      END IF;

      IF NOT v_amount_bad AND NOT v_status_bad AND NOT v_dup THEN
        INSERT INTO recon_match (run_id, transfer_id, rail_request_id, matched_status)
        VALUES (v_run, r.transfer_id, r.ref, r.eff_status);
        v_matched := v_matched + 1;
        IF r.status = 'SETTLED' THEN
          UPDATE transfer SET status = 'RECONCILED',
                              status_reason = 'MATCHED_STATEMENT_' || to_char(p_statement_date, 'YYYYMMDD')
           WHERE transfer_id = r.transfer_id;
        END IF;
      END IF;
    END IF;
  END LOOP;

  -- 4. MISSING: the status claims something the ledger or event log does not back up
  PERFORM raise_break(v_run, 'MISSING', t.transfer_id, NULL, NULL, t.amount_minor, NULL,
                      'status ' || t.status || ' is not backed by journals and events')
    FROM transfer t
   WHERE (t.status IN ('POSTED','PENDING','SETTLED','RECONCILED','REVERSED')
          AND NOT EXISTS (SELECT 1 FROM journal_entry j WHERE j.transfer_id = t.transfer_id
                             AND j.journal_type = 'TRANSFER_POST'))
      OR (t.status IN ('SETTLED','RECONCILED')
          AND NOT EXISTS (SELECT 1 FROM journal_entry j WHERE j.transfer_id = t.transfer_id
                             AND j.journal_type = 'TRANSFER_SETTLE'))
      OR (t.status = 'REVERSED'
          AND NOT EXISTS (SELECT 1 FROM journal_entry j WHERE j.transfer_id = t.transfer_id
                             AND j.journal_type IN ('TRANSFER_REVERSE','TRANSFER_RETURN')))
      OR NOT EXISTS (SELECT 1 FROM outbox_event o WHERE o.aggregate_id = t.transfer_id AND o.sequence = t.version);

  SELECT count(*) INTO v_breaks FROM recon_break WHERE run_id = v_run;
  UPDATE recon_run SET finished_at = clock_timestamp(), matched_count = v_matched, new_break_count = v_breaks
   WHERE run_id = v_run;
  RETURN v_run;
END $$;

-- ---------------------------------------------------------------------------
-- Resolution: records who resolved a break, enforces owner role and four eyes for write-offs.
-- Ledger history is never edited; any correction is a separate, linked journal.
-- ---------------------------------------------------------------------------
CREATE FUNCTION resolve_break(p_break uuid, p_code text, p_comment text, p_user uuid,
                              p_approver uuid DEFAULT NULL) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = fw, public AS $$
DECLARE v_owner text; v_role text;
BEGIN
  SELECT owner_role INTO v_owner FROM recon_break WHERE break_id = p_break AND state <> 'RESOLVED';
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND: no open break %', p_break; END IF;
  SELECT role INTO v_role FROM app_user WHERE user_id = p_user AND active;
  IF v_role IS NULL OR (v_role <> v_owner AND v_role <> 'finance_controller') THEN
    RAISE EXCEPTION 'ROLE_NOT_PERMITTED: break is owned by %', v_owner;
  END IF;
  IF p_code = 'WRITTEN_OFF_APPROVED' THEN
    IF p_approver IS NULL OR p_approver = p_user THEN
      RAISE EXCEPTION 'SOD_VIOLATION: a write-off needs a second person to approve';
    END IF;
    PERFORM assert_role(p_approver, 'finance_controller');
  END IF;
  UPDATE recon_break
     SET state = 'RESOLVED', resolution_code = p_code, resolution_comment = p_comment,
         resolved_by = p_user, approved_by = p_approver, resolved_at = now()
   WHERE break_id = p_break;
END $$;

-- ---------------------------------------------------------------------------
-- Views used by finance, operations and the audit checks
-- ---------------------------------------------------------------------------
CREATE VIEW v_trial_balance AS
SELECT a.code, a.name, a.account_type,
       coalesce(sum(e.amount_minor) FILTER (WHERE e.direction = 'DEBIT'),  0) AS debit_total_minor,
       coalesce(sum(e.amount_minor) FILTER (WHERE e.direction = 'CREDIT'), 0) AS credit_total_minor
  FROM ledger_account a LEFT JOIN ledger_entry e USING (account_id)
 GROUP BY a.code, a.name, a.account_type;

-- empty result = projection agrees with entries
CREATE VIEW v_balance_projection_check AS
SELECT a.code,
       coalesce(b.balance_minor, 0) AS projected_minor,
       coalesce(sum(CASE WHEN e.direction = a.normal_side THEN e.amount_minor ELSE -e.amount_minor END), 0) AS recomputed_minor
  FROM ledger_account a
  LEFT JOIN account_balance b USING (account_id)
  LEFT JOIN ledger_entry e USING (account_id)
 GROUP BY a.code, a.normal_side, b.balance_minor
HAVING coalesce(b.balance_minor, 0) <>
       coalesce(sum(CASE WHEN e.direction = a.normal_side THEN e.amount_minor ELSE -e.amount_minor END), 0);

CREATE VIEW v_transfer_lineage AS
SELECT t.transaction_reference, t.status, t.amount_minor, t.correlation_id,
       (SELECT string_agg(j.journal_type::text, ', ' ORDER BY j.posted_at)
          FROM journal_entry j WHERE j.transfer_id = t.transfer_id) AS journals,
       (SELECT count(*) FROM transfer_state_history h WHERE h.transfer_id = t.transfer_id) AS state_changes,
       (SELECT count(*) FROM outbox_event o WHERE o.aggregate_id = t.transfer_id) AS events
  FROM transfer t;

CREATE VIEW v_open_breaks AS
SELECT b.break_type, b.owner_role, b.state, b.due_at, b.detail,
       t.transaction_reference, b.rail_request_id, b.internal_amount_minor, b.external_amount_minor
  FROM recon_break b LEFT JOIN transfer t USING (transfer_id)
 WHERE b.state <> 'RESOLVED';

-- spend per customer, used by the limit rules
CREATE VIEW v_customer_outbound_usage AS
SELECT w.customer_id,
       coalesce(sum(t.amount_minor) FILTER (WHERE t.created_at >= date_trunc('day', now())), 0)   AS today_minor,
       coalesce(sum(t.amount_minor) FILTER (WHERE t.created_at >= date_trunc('month', now())), 0) AS month_minor
  FROM wallet w
  LEFT JOIN transfer t ON t.source_wallet_id = w.wallet_id
                      AND t.status IN ('POSTED','PENDING','SETTLED','RECONCILED')
 GROUP BY w.customer_id;

-- simple settlement and control report for finance
CREATE VIEW v_settlement_report AS
SELECT d.business_date,
       d.transfers, d.total_minor, d.in_flight_minor, d.settled_unreconciled_minor,
       d.reconciled_minor, d.reversed_minor, d.failed_count,
       coalesce(b.open_breaks, 0) AS open_breaks
  FROM (SELECT t.created_at::date AS business_date,
               count(*)                                                            AS transfers,
               sum(t.amount_minor)                                                 AS total_minor,
               sum(t.amount_minor) FILTER (WHERE t.status IN ('POSTED','PENDING')) AS in_flight_minor,
               sum(t.amount_minor) FILTER (WHERE t.status = 'SETTLED')             AS settled_unreconciled_minor,
               sum(t.amount_minor) FILTER (WHERE t.status = 'RECONCILED')          AS reconciled_minor,
               sum(t.amount_minor) FILTER (WHERE t.status = 'REVERSED')            AS reversed_minor,
               count(*) FILTER (WHERE t.status = 'FAILED')                         AS failed_count
          FROM transfer t GROUP BY t.created_at::date) d
  LEFT JOIN (SELECT t2.created_at::date AS business_date, count(*) AS open_breaks
               FROM recon_break rb JOIN transfer t2 USING (transfer_id)
              WHERE rb.state <> 'RESOLVED' GROUP BY t2.created_at::date) b
         USING (business_date);
