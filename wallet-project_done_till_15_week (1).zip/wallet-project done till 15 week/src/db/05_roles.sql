-- Database roles that mirror the write-path rules of the source-of-truth table.
-- NOLOGIN roles: the services connect with their own login role and are granted membership.
-- Posting, audit and reconciliation functions are SECURITY DEFINER, so a service can use them
-- without holding write access to the tables behind them.
SET search_path = fw, public;

DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['fw_txn','fw_recon','fw_notify','fw_relay','fw_report'] LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('CREATE ROLE %I NOLOGIN', r);
    END IF;
  END LOOP;
END $$;

REVOKE ALL ON ALL TABLES    IN SCHEMA fw FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA fw FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA fw FROM PUBLIC;
GRANT USAGE ON SCHEMA fw TO fw_txn, fw_recon, fw_notify, fw_relay, fw_report;

-- Transaction Service: owns transfer state, idempotency, screening results, cases, reversals.
-- It has no direct write access to ledger tables; it posts only through ledger_post().
GRANT SELECT ON ALL TABLES IN SCHEMA fw TO fw_txn;
-- identity data: only what the transfer flow needs (tier and status), not name, mobile or national id token
REVOKE SELECT ON customer, kyc_decision FROM fw_txn;
GRANT SELECT (customer_id, customer_ref, kyc_tier, status) ON customer TO fw_txn;
GRANT INSERT, UPDATE ON transfer, reversal_request, compliance_case TO fw_txn;
GRANT INSERT ON idempotency_record, screening_decision, case_decision, rail_message_log TO fw_txn;
GRANT UPDATE (state, response_status, response_body, transfer_id) ON idempotency_record TO fw_txn;
GRANT USAGE ON SEQUENCE transfer_ref_seq TO fw_txn;
GRANT EXECUTE ON FUNCTION ledger_post(uuid, journal_type), audit(text, text, text, text, text, text, uuid, jsonb) TO fw_txn;

-- Reconciliation Service: reads rail data, imports statements, runs reconciliation through its functions.
GRANT SELECT ON rail_statement_line, recon_run, recon_match, recon_break, break_policy TO fw_recon;
GRANT INSERT ON rail_statement_line TO fw_recon;
GRANT SELECT ON v_open_breaks, v_settlement_report, v_transfer_lineage TO fw_recon;
GRANT EXECUTE ON FUNCTION run_reconciliation(date, text, interval),
                          resolve_break(uuid, text, text, uuid, uuid),
                          audit(text, text, text, text, text, text, uuid, jsonb),
                          verify_audit_chain() TO fw_recon;

-- Notification Service: reads events, tracks what it has processed, sees only contact details.
GRANT SELECT ON outbox_event, consent_record TO fw_notify;
GRANT SELECT (customer_id, customer_ref, mobile_msisdn) ON customer TO fw_notify;
GRANT INSERT ON inbox_event, dead_letter_event TO fw_notify;

-- Outbox relay: may only mark events as published.
GRANT SELECT ON outbox_event TO fw_relay;
GRANT UPDATE (published_at, publish_attempts) ON outbox_event TO fw_relay;

-- Reporting: views only, no table access.
GRANT SELECT ON v_settlement_report, v_trial_balance, v_open_breaks, v_transfer_lineage,
                v_balance_projection_check TO fw_report;
GRANT EXECUTE ON FUNCTION verify_audit_chain() TO fw_report;
