-- Week 13 additions (prototype, resilience and security/observability gates).
-- Apply after 05_roles.sql. Adds the manual exception queue, the notification log written by the
-- notification consumer, an operations health view for the dashboard and the grants for both.
SET search_path = fw, public;

-- ---------------------------------------------------------------------------
-- Manual exception queue (the "dead-letter" end of automated recovery)
-- ---------------------------------------------------------------------------
CREATE TABLE ops_exception (
  exception_id  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id   uuid REFERENCES transfer(transfer_id),
  kind          text NOT NULL CHECK (kind IN
                  ('RECOVERY_EXHAUSTED',          -- status enquiries used up, outcome still unknown
                   'RAIL_OUTCOME_CONFLICT',       -- rail answer contradicts a final internal state
                   'POSTING_FAILED')),            -- rail answered but our posting failed
  owner_role    text NOT NULL,
  state         text NOT NULL DEFAULT 'OPEN' CHECK (state IN ('OPEN','RESOLVED')),
  detail        text NOT NULL,
  correlation_id uuid,
  opened_at     timestamptz NOT NULL DEFAULT now(),
  due_at        timestamptz NOT NULL DEFAULT now() + interval '4 hours',
  resolved_by   text,
  resolved_at   timestamptz,
  CHECK (state <> 'RESOLVED' OR (resolved_by IS NOT NULL AND resolved_at IS NOT NULL))
);
-- one open exception of each kind per transfer, so a worker loop cannot flood the queue
CREATE UNIQUE INDEX uq_open_ops_exception ON ops_exception (transfer_id, kind) WHERE state = 'OPEN';

-- ---------------------------------------------------------------------------
-- Notification log: the notification consumer's only side effect. Holds no financial truth.
-- ---------------------------------------------------------------------------
CREATE TABLE notification_log (
  notification_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  event_id        uuid NOT NULL UNIQUE,
  transfer_id     uuid NOT NULL,                 -- by value, not a foreign key (consumer never blocks a transfer)
  customer_ref    text NOT NULL,
  sequence        integer NOT NULL,
  status          text NOT NULL,
  outcome         text NOT NULL CHECK (outcome IN ('SENT','SUPPRESSED_NO_CONSENT','SKIPPED_STALE','NOT_NOTIFIABLE')),
  channel         text NOT NULL DEFAULT 'SMS_MOCK',
  masked_msisdn   text,
  message         text,
  correlation_id  uuid,
  created_at      timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX ix_notification_transfer ON notification_log (transfer_id, sequence);

-- ---------------------------------------------------------------------------
-- Operations health: one row used by the dashboard and the metrics endpoint
-- ---------------------------------------------------------------------------
CREATE VIEW v_ops_health AS
WITH bal AS (
  SELECT a.code, coalesce(b.balance_minor, 0) AS bal
    FROM ledger_account a LEFT JOIN account_balance b USING (account_id)),
settle AS (
  SELECT extract(epoch FROM (s.changed_at - i.changed_at)) AS secs
    FROM transfer_state_history s
    JOIN transfer_state_history i ON i.transfer_id = s.transfer_id AND i.sequence = 1
   WHERE s.to_status = 'SETTLED' AND s.changed_at > now() - interval '24 hours')
SELECT
  (SELECT coalesce(jsonb_object_agg(status, n), '{}'::jsonb)
     FROM (SELECT status::text, count(*) AS n FROM transfer GROUP BY status) x)          AS transfers_by_status,
  (SELECT count(*) FROM transfer WHERE status = 'PENDING')                               AS pending_count,
  (SELECT coalesce(max(extract(epoch FROM now() - updated_at)), 0)::int
     FROM transfer WHERE status = 'PENDING')                                             AS pending_oldest_seconds,
  (SELECT count(*) FROM transfer WHERE status = 'POSTED'
      AND updated_at < now() - interval '60 seconds')                                    AS posted_stuck_count,
  (SELECT count(*) FROM outbox_event WHERE published_at IS NULL)                         AS outbox_unpublished,
  (SELECT coalesce(max(extract(epoch FROM now() - created_at)), 0)::int
     FROM outbox_event WHERE published_at IS NULL)                                       AS outbox_oldest_seconds,
  (SELECT count(*) FROM dead_letter_event WHERE state = 'OPEN')                          AS dlq_open,
  (SELECT count(*) FROM recon_break WHERE state <> 'RESOLVED')                           AS open_breaks,
  (SELECT count(*) FROM recon_break WHERE state <> 'RESOLVED' AND due_at < now())        AS overdue_breaks,
  (SELECT count(*) FROM compliance_case WHERE state = 'OPEN')                            AS open_cases,
  (SELECT count(*) FROM compliance_case WHERE state = 'OPEN' AND due_at < now())         AS overdue_cases,
  (SELECT count(*) FROM ops_exception WHERE state = 'OPEN')                              AS open_exceptions,
  (SELECT count(*) FROM audit_log WHERE outcome = 'DENIED')                              AS audit_denials,
  (SELECT sum(debit_total_minor) = sum(credit_total_minor) FROM v_trial_balance)         AS trial_balance_ok,
  (SELECT count(*) = 0 FROM v_balance_projection_check)                                  AS projection_ok,
  ((SELECT bal FROM bal WHERE code = '1100') =
   (SELECT coalesce(sum(bal), 0) FROM bal WHERE code LIKE 'W-CUST-%') +
   (SELECT bal FROM bal WHERE code = '2200'))                                            AS float_invariant_ok,
  (SELECT count(*) FROM settle)                                                          AS settled_24h,
  (SELECT coalesce(percentile_cont(0.95) WITHIN GROUP (ORDER BY secs), 0)::numeric(10,3)
     FROM settle)                                                                        AS settle_p95_seconds_24h;

-- ---------------------------------------------------------------------------
-- Grants (same least-privilege pattern as 05_roles.sql)
-- ---------------------------------------------------------------------------
REVOKE ALL ON ops_exception, notification_log, v_ops_health FROM PUBLIC;

-- Fix found by the Week 13 integration tests: 05_roles.sql revokes every function from PUBLIC, but the
-- maker-checker and officer triggers call assert_role() as the session role. Without this grant a reversal
-- request or a compliance decision only worked for a superuser.
GRANT EXECUTE ON FUNCTION assert_role(uuid, text) TO fw_txn;

-- Transaction Service (and its recovery worker) raises exceptions and reads them.
GRANT SELECT, INSERT ON ops_exception TO fw_txn;
GRANT UPDATE (state, resolved_by, resolved_at) ON ops_exception TO fw_txn;
GRANT SELECT ON v_ops_health TO fw_txn;

-- Notification consumer: writes its own log, nothing else.
GRANT SELECT, INSERT ON notification_log TO fw_notify;

-- Reconciliation and reporting may read the health view and the exception queue.
GRANT SELECT ON v_ops_health, ops_exception TO fw_recon;
GRANT SELECT ON v_ops_health TO fw_report;
