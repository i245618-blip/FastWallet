-- Week 12 demonstration: builds the reconciliation scenarios, runs reconciliation, shows the reports,
-- then recovers one break and reconciles again. Run after the schema, reference data, seed and helpers.
\set ON_ERROR_STOP on
\pset footer off
SET search_path = fw, public;

\echo '=== 1. Scenario setup (synthetic transfers and a synthetic rail statement)'
\o /dev/null
SELECT demo_make_transfer(4, 100000, 'SETTLED')      AS ref_ok       \gset
SELECT demo_make_transfer(4, 110000, 'PENDING')      AS ref_status   \gset
SELECT demo_make_transfer(4, 120000, 'SETTLED')      AS ref_amount   \gset
SELECT demo_make_transfer(4, 130000, 'SETTLED')      AS ref_dup      \gset
SELECT demo_make_transfer(4, 140000, 'SETTLED')      AS ref_unint    \gset
SELECT demo_make_transfer(4, 150000, 'REVERSED_PRE') AS ref_rej      \gset
SELECT demo_make_transfer(4, 160000, 'RETURNED')     AS ref_ret      \gset
SELECT demo_make_transfer(4, 170000, 'SETTLED')      AS ref_lateret  \gset
SELECT demo_make_transfer(4, 180000, 'PENDING')      AS ref_stuck    \gset

SELECT demo_statement_line(:'ref_ok',      100000, 'EXECUTED');
SELECT demo_statement_line(:'ref_status',  110000, 'EXECUTED');
SELECT demo_statement_line(:'ref_amount',  119000, 'EXECUTED');
SELECT demo_statement_line(:'ref_dup',     130000, 'EXECUTED');
SELECT demo_statement_line(:'ref_dup',     130000, 'EXECUTED');
SELECT demo_statement_line(:'ref_rej',     150000, 'REJECTED');
SELECT demo_statement_line(:'ref_ret',     160000, 'EXECUTED');
SELECT demo_statement_line(:'ref_ret',     160000, 'RETURNED');
SELECT demo_statement_line(:'ref_lateret', 170000, 'EXECUTED');
SELECT demo_statement_line(:'ref_lateret', 170000, 'RETURNED');
SELECT demo_statement_line('FW-20990101-000001', 999000, 'EXECUTED');
\o

\echo
\echo '=== 2. Transfer lineage (status, journals, state changes, events)'
SELECT transaction_reference, status, amount_minor, journals, state_changes, events
  FROM v_transfer_lineage ORDER BY transaction_reference;

\echo
\echo '=== 3. First reconciliation run'
SELECT run_reconciliation(current_date, 'demo-run', interval '0 seconds') AS run_id \gset
SELECT matched_count, new_break_count FROM recon_run WHERE run_id = :'run_id';

\echo
\echo '--- exception queue'
SELECT break_type, owner_role, state, transaction_reference, rail_request_id,
       internal_amount_minor AS internal_minor, external_amount_minor AS external_minor, detail
  FROM v_open_breaks ORDER BY break_type, transaction_reference;

\echo
\echo '--- matched items'
SELECT t.transaction_reference, m.matched_status, t.status AS internal_status
  FROM recon_match m JOIN transfer t USING (transfer_id) ORDER BY 1;

\echo
\echo '=== 4. Recovery of one break (status mismatch: rail executed, we still show PENDING)'
SET fw.actor = 'recovery.bot';
\o /dev/null
SELECT ledger_post(transfer_id, 'TRANSFER_SETTLE') FROM transfer WHERE transaction_reference = :'ref_status';
UPDATE transfer SET status = 'SETTLED', rail_reference = 'RAIL-SYN-RECOVERED', status_reason = 'ENQUIRY_EXECUTED'
 WHERE transaction_reference = :'ref_status';
SELECT resolve_break(break_id, 'MATCHED_LATE', 'status enquiry confirmed execution, settlement posted',
                     'd0000000-0000-0000-0000-000000000001')
  FROM recon_break b JOIN transfer t USING (transfer_id)
 WHERE t.transaction_reference = :'ref_status' AND b.break_type = 'STATUS_MISMATCH';

\o
\echo
\echo '=== 5. Second reconciliation run (re-run is safe, recovered item now reconciles)'
SELECT run_reconciliation(current_date, 'demo-run-2', interval '0 seconds') AS run2 \gset
SELECT matched_count, new_break_count FROM recon_run WHERE run_id = :'run2';
SELECT transaction_reference, status FROM transfer WHERE transaction_reference IN (:'ref_ok', :'ref_status') ORDER BY 1;
SELECT break_type, state, resolution_code, count(*) FROM recon_break GROUP BY 1,2,3 ORDER BY 1,2;

\echo
\echo '=== 6. Ledger checks'
\echo '--- trial balance (debits must equal credits)'
SELECT code, name, debit_total_minor, credit_total_minor FROM v_trial_balance
 WHERE debit_total_minor + credit_total_minor > 0 ORDER BY code;
SELECT sum(debit_total_minor) AS total_debits, sum(credit_total_minor) AS total_credits,
       sum(debit_total_minor) = sum(credit_total_minor) AS balanced FROM v_trial_balance;
\echo '--- balance projection vs recomputed from entries (expect no rows)'
SELECT * FROM v_balance_projection_check;
\echo '--- float check: settlement float must equal wallets + in-transit'
SELECT (SELECT balance_minor FROM account_balance b JOIN ledger_account a USING (account_id) WHERE a.code='1100') AS float_minor,
       (SELECT sum(balance_minor) FROM account_balance b JOIN ledger_account a USING (account_id)
         WHERE a.code LIKE 'W-CUST-%' OR a.code='2200') AS wallets_plus_in_transit_minor;

\echo
\echo '=== 7. Finance settlement and control report'
SELECT business_date, transfers, total_minor, in_flight_minor, settled_unreconciled_minor,
       reconciled_minor, reversed_minor, failed_count, open_breaks FROM v_settlement_report;

\echo
\echo '=== 8. Audit chain'
\o /dev/null
SELECT audit('recon-service','system_recovery','RECON_RUN','recon_run', :'run_id','ALLOWED');
SELECT audit('ops.demo1','ops_analyst','BREAK_RESOLVED','recon_break','demo','ALLOWED');
SELECT audit('cust-0003','customer','REVERSAL_APPROVE','reversal_request','demo','DENIED');
\o
SELECT chain_ok, first_bad_id FROM verify_audit_chain();
