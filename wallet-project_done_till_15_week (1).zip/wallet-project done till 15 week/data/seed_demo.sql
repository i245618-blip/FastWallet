-- Synthetic demo data. Every name, number and identifier below is invented.
SET search_path = fw, public;

INSERT INTO app_user (user_id, username, role) VALUES
 ('d0000000-0000-0000-0000-000000000001','ops.demo1','ops_analyst'),
 ('d0000000-0000-0000-0000-000000000002','ops.demo2','ops_analyst'),
 ('d0000000-0000-0000-0000-000000000003','fin.demo1','finance_controller'),
 ('d0000000-0000-0000-0000-000000000004','fin.demo2','finance_controller'),
 ('d0000000-0000-0000-0000-000000000005','co.demo1','compliance_officer'),
 ('d0000000-0000-0000-0000-000000000006','recovery.bot','system_recovery');

INSERT INTO customer (customer_id, customer_ref, full_name, mobile_msisdn, national_id_token, kyc_tier)
SELECT ('c0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
       'CUST-' || lpad(n::text, 4, '0'),
       (ARRAY['Ayesha Demo','Bilal Sample','Chand Test','Dania Mock','Eman Synthetic','Farhan Fake'])[n],
       '0300000000' || n,
       encode(sha256(convert_to('synthetic-national-id-' || n, 'UTF8')), 'hex'),
       (ARRAY[1,1,2,2,0,2])[n]::smallint
  FROM generate_series(1, 6) n;

INSERT INTO consent_record (customer_id, purpose, notice_version)
SELECT c.customer_id, p.purpose, 'notice-2026-09'
  FROM customer c CROSS JOIN (VALUES ('KYC_VERIFICATION'),('TRANSACTION_PROCESSING'),('SERVICE_NOTIFICATIONS')) p(purpose);
-- one customer has also agreed to automated assistance, one has withdrawn notifications
INSERT INTO consent_record (customer_id, purpose, notice_version)
  VALUES ('c0000000-0000-0000-0000-000000000003', 'AUTOMATED_ASSISTANCE', 'notice-2026-09');
UPDATE consent_record SET withdrawn_at = now()
 WHERE customer_id = 'c0000000-0000-0000-0000-000000000002' AND purpose = 'SERVICE_NOTIFICATIONS';

INSERT INTO kyc_decision (customer_id, method, result, tier_granted, watchlist_prescreen, evidence, decided_by)
SELECT customer_id,
       CASE kyc_tier WHEN 0 THEN 'OTP_CALLBACK' WHEN 1 THEN 'BIOMETRIC_SIMULATED' ELSE 'MANUAL_REVIEW' END,
       'PASSED', kyc_tier, 'CLEAR',
       jsonb_build_object('otp_verified', true, 'prescreen_list_version', 'synthetic-2026-10',
                          'document_check', CASE WHEN kyc_tier = 2 THEN 'synthetic-docs-ok' ELSE 'not-required' END),
       CASE kyc_tier WHEN 2 THEN 'co.demo1' ELSE 'kyc-service' END
  FROM customer;

INSERT INTO ledger_account (account_id, code, name, account_type, normal_side)
SELECT ('a0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
       'W-CUST-' || lpad(n::text, 4, '0'), 'Wallet liability CUST-' || lpad(n::text, 4, '0'),
       'LIABILITY', 'CREDIT'
  FROM generate_series(1, 6) n;

-- wallets 1-5 were opened 90 days ago; wallet 6 was opened today, so rule R08 (new wallet, high value) applies
INSERT INTO wallet (wallet_id, customer_id, ledger_account_id, opened_at)
SELECT ('b0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
       ('c0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
       ('a0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
       CASE WHEN n = 6 THEN now() ELSE now() - interval '90 days' END
  FROM generate_series(1, 6) n;

-- opening balances in paisa (Rs 20,000 / 10,000 / 150,000 / 500,000 / 5,000 / 40,000)
SELECT fund_wallet(('b0000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid,
                   (ARRAY[2000000, 1000000, 15000000, 50000000, 500000, 4000000])[n]::bigint,
                   'SEED-FUND-' || lpad(n::text, 4, '0'))
  FROM generate_series(1, 6) n;

INSERT INTO watchlist_entry (full_name) VALUES ('Sample Blocked Person'), ('Test Designated Entity');
