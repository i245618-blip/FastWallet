-- Helper used by demos and tests: drives a transfer through valid transitions with the correct postings.
-- target: INITIATED, AUTHORISED, POSTED, PENDING, SETTLED, REVERSED_PRE (rail rejected), RETURNED (after settlement)
SET search_path = fw, public;

CREATE OR REPLACE FUNCTION demo_make_transfer(p_wallet_n int, p_amount_minor bigint, p_target text)
RETURNS text LANGUAGE plpgsql SET search_path = fw, public AS $$
DECLARE v_id uuid; v_ref text;
BEGIN
  PERFORM set_config('fw.actor', 'demo-driver', true);
  INSERT INTO transfer (client_id, source_wallet_id, beneficiary_scheme, beneficiary_identifier,
                        beneficiary_name, amount_minor, purpose, correlation_id)
  VALUES ('demo-app', ('b0000000-0000-0000-0000-' || lpad(p_wallet_n::text, 12, '0'))::uuid,
          'IBAN', 'PK00FAKE00000000000000' || lpad(p_wallet_n::text, 2, '0'), 'Synthetic Beneficiary',
          p_amount_minor, 'OTHER', gen_random_uuid())
  RETURNING transfer_id, transaction_reference INTO v_id, v_ref;
  IF p_target = 'INITIATED' THEN RETURN v_ref; END IF;

  UPDATE transfer SET status = 'AUTHORISED' WHERE transfer_id = v_id;
  IF p_target = 'AUTHORISED' THEN RETURN v_ref; END IF;

  PERFORM ledger_post(v_id, 'TRANSFER_POST');
  UPDATE transfer SET status = 'POSTED' WHERE transfer_id = v_id;
  IF p_target = 'POSTED' THEN RETURN v_ref; END IF;

  IF p_target = 'PENDING' THEN
    UPDATE transfer SET status = 'PENDING', status_reason = 'RAIL_TIMEOUT' WHERE transfer_id = v_id;
    RETURN v_ref;
  END IF;
  IF p_target = 'REVERSED_PRE' THEN
    PERFORM ledger_post(v_id, 'TRANSFER_REVERSE');
    UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_REJECTED' WHERE transfer_id = v_id;
    RETURN v_ref;
  END IF;

  PERFORM ledger_post(v_id, 'TRANSFER_SETTLE');
  UPDATE transfer SET status = 'SETTLED', rail_reference = 'RAIL-SYN-' || right(v_ref, 6) WHERE transfer_id = v_id;
  IF p_target = 'SETTLED' THEN RETURN v_ref; END IF;

  IF p_target = 'RETURNED' THEN
    PERFORM ledger_post(v_id, 'TRANSFER_RETURN');
    UPDATE transfer SET status = 'REVERSED', status_reason = 'RAIL_RETURN' WHERE transfer_id = v_id;
    RETURN v_ref;
  END IF;
  RAISE EXCEPTION 'unknown target %', p_target;
END $$;

-- helper to add a synthetic statement line
CREATE OR REPLACE FUNCTION demo_statement_line(p_ref text, p_amount_minor bigint, p_status text,
                                               p_date date DEFAULT current_date) RETURNS void
LANGUAGE sql SET search_path = fw, public AS $$
  INSERT INTO rail_statement_line (statement_date, rail_request_id, rail_reference, amount_minor, rail_status, source_file)
  VALUES (p_date, p_ref, 'RAIL-SYN-' || right(p_ref, 6), p_amount_minor, p_status, 'synthetic-statement.csv');
$$;
